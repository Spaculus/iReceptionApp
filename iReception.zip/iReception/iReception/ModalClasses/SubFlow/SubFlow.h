//
//  SubFlow.h
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SubFlow : NSObject

@property (strong, nonatomic) NSString *subFlow_ID;
@property (strong, nonatomic) NSString *subFlow_childPID;
@property (strong, nonatomic) NSString *subFlow_created;
@property (strong, nonatomic) NSString *subFlow_design_key;
@property (strong, nonatomic) NSString *subFlow_entrykey;
@property (strong, nonatomic) NSString *subFlow_flowPID;
@property (strong, nonatomic) NSString *subFlow_imagePID;
@property (strong, nonatomic) NSString *subFlow_itemname;
@property (strong, nonatomic) NSString *subFlow_pID;
@property (strong, nonatomic) NSString *subFlow_page_headline;
@property (strong, nonatomic) NSString *subFlow_page_subtext;
@property (strong, nonatomic) NSString *subFlow_root;
@property (strong, nonatomic) NSString *subFlow_sectionPID;
@property (strong, nonatomic) NSString *subFlow_seq;
@property (strong, nonatomic) NSString *subFlow_startflag;
@property (strong, nonatomic) NSString *subFlow_startflag_status;
@property (strong, nonatomic) NSString *subFlow_startname;
@property (strong, nonatomic) NSString *subFlow_targetPID;
@property (strong, nonatomic) NSString *subFlow_type;
@property (strong, nonatomic) NSString *subFlow_imageName;
@property (strong, nonatomic) NSString *subFlow_issub;

- (id)initWithDictionary:(NSDictionary *)dict;
@end
/*
{
    Result =     (
                  {
                      ID = 31;
                      childPID = "<null>";
                      created = 1151493983;
                      "design_key" = "<null>";
                      entrykey = ee565;
                      flowPID = 0fb5c59213;
                      imagePID = "";
                      itemname = Start;
                      pID = d0b125b2d4;
                      "page_headline" = "What is your doing here ??";
                      "page_subtext" = "<null>";
                      root = Y;
                      sectionPID = "<null>";
                      seq = 1;
                      startflag = Y;
                      "startflag_status" = Aktiv;
                      startname = Start;
                      targetPID = "<null>";
                      type = Button;
                  },
                  {
                      ID = 34;
                      childPID = d0b125b2d4;
                      created = 1152088117;
                      "design_key" = "<null>";
                      entrykey = a6742;
                      flowPID = 0fb5c59213;
                      imagePID = "";
                      itemname = "Announce meeting";
                      pID = 358846873d;
                      "page_headline" = "We will start our new flow from here.";
                      "page_subtext" = "<null>";
                      root = "<null>";
                      sectionPID = "<null>";
                      seq = 3;
                      startflag = Y;
                      "startflag_status" = Aktiv;
                      startname = "Next Flow";
                      targetPID = "<null>";
                      type = Button;
                  }
                  );
    Status = Success;
}
*/
