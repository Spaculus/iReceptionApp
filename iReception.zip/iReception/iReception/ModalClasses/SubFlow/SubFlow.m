//
//  SubFlow.m
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "SubFlow.h"

@implementation SubFlow
- (id)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self!=nil) {
        self.subFlow_ID = [CommonUtils getNotNullString:[dict valueForKey:@"ID"]];
        self.subFlow_childPID = [CommonUtils getNotNullString:[dict valueForKey:@"childPID"]];
        self.subFlow_created = [CommonUtils getNotNullString:[dict valueForKey:@"created"]];
        self.subFlow_design_key = [CommonUtils getNotNullString:[dict valueForKey:@"design_key"]];
        self.subFlow_entrykey = [CommonUtils getNotNullString:[dict valueForKey:@"entrykey"]];
        self.subFlow_flowPID = [CommonUtils getNotNullString:[dict valueForKey:@"flowPID"]];
        self.subFlow_imagePID = [CommonUtils getNotNullString:[dict valueForKey:@"imagePID"]];
        self.subFlow_imageName = [CommonUtils getNotNullString:[dict valueForKey:@"imageName"]];
        self.subFlow_itemname = [CommonUtils getNotNullString:[dict valueForKey:@"itemname"]];
        self.subFlow_pID = [CommonUtils getNotNullString:[dict valueForKey:@"pID"]];
        self.subFlow_page_headline = [CommonUtils getNotNullString:[dict valueForKey:@"page_headline"]];
        self.subFlow_page_subtext = [CommonUtils getNotNullString:[dict valueForKey:@"page_subtext"]];
        self.subFlow_root = [CommonUtils getNotNullString:[dict valueForKey:@"root"]];
        self.subFlow_sectionPID = [CommonUtils getNotNullString:[dict valueForKey:@"sectionPID"]];
        self.subFlow_seq = [CommonUtils getNotNullString:[dict valueForKey:@"seq"]];
        self.subFlow_startflag = [CommonUtils getNotNullString:[dict valueForKey:@"startflag"]];
        self.subFlow_startflag_status = [CommonUtils getNotNullString:[dict valueForKey:@"startflag_status"]];
        self.subFlow_startname = [CommonUtils getNotNullString:[dict valueForKey:@"startname"]];
        self.subFlow_targetPID = [CommonUtils getNotNullString:[dict valueForKey:@"targetPID"]];
        self.subFlow_type = [CommonUtils getNotNullString:[dict valueForKey:@"type"]];
        self.subFlow_issub = [CommonUtils getNotNullString:[dict valueForKey:@"issub"]];
        
        
        return self;
    }
    return nil;
}

@end
/*
 ID = 31;
 childPID = "<null>";
 created = 1151493983;
 "design_key" = "<null>";
 entrykey = ee565;
 flowPID = 0fb5c59213;
 imagePID = "";
 itemname = Start;
 pID = d0b125b2d4;
 "page_headline" = "What is your doing here ??";
 "page_subtext" = "<null>";
 root = Y;
 sectionPID = "<null>";
 seq = 1;
 startflag = Y;
 "startflag_status" = Aktiv;
 startname = Start;
 targetPID = "<null>";
 type = Button;
 
 
 
 ID = 47;
 childPID = d0b125b2d4;
 created = 1152863245;
 "design_key" = "<null>";
 entrykey = "<null>";
 flowPID = 0fb5c59213;
 imagePID = "";
 itemname = "Spaculus Pvt";
 pID = af231231d2;
 "page_headline" = "<null>";
 "page_subtext" = "<null>";
 root = "<null>";
 sectionPID = "<null>";
 seq = 6;
 startflag = N;
 "startflag_status" = Aktiv;
 startname = "";
 targetPID = "<null>";
 type = Button;
 
 
 */