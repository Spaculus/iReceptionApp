//
//  Modal.h
//  iReception
//
//  Created by spaculus on 7/12/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#ifndef Modal_h
#define Modal_h


#import "User.h"
#import "Flow.h"
#import "SubFlow.h"

#import "Design.h"
#import "DesignProperty.h"

#import "UserProperty.h"
#import "UserPropertyDetail.h"

#endif /* Modal_h */
