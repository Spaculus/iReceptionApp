//
//  Flow.h
//  iReception
//
//  Created by spaculus on 7/13/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Flow : NSObject

@property (strong, nonatomic) NSString *flow_ID;
@property (strong, nonatomic) NSString *flow_created;
@property (strong, nonatomic) NSString *flow_custPID;
@property (strong, nonatomic) NSString *flow_description;
@property (strong, nonatomic) NSString *flow_elem_position;
@property (strong, nonatomic) NSString *flow_modified;
@property (strong, nonatomic) NSString *flow_name;
@property (strong, nonatomic) NSString *flow_pID;
@property (strong, nonatomic) NSString *flow_status;
@property (strong, nonatomic) NSString *flow_flowCount;

-(id)initWithDictionary:(NSDictionary *)dict;

@end

/*{
  = 8;
  = 1151493983;
  = d8e2743ec8;
  = "main entry";
 "" = "<null>";
  = 1152178860;
  = reception;
  = 0fb5c59213;
  = Aktiv;*/