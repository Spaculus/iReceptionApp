//
//  Flow.m
//  iReception
//
//  Created by spaculus on 7/13/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "Flow.h"

@implementation Flow

- (id)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self!=nil) {
        self.flow_ID = [CommonUtils getNotNullString:[dict valueForKey:@"ID"]];
        self.flow_created = [CommonUtils getNotNullString:[dict valueForKey:@"created"]];
        self.flow_custPID = [CommonUtils getNotNullString:[dict valueForKey:@"custPID"]];
        self.flow_description = [CommonUtils getNotNullString:[dict valueForKey:@"description"]];
        self.flow_elem_position = [CommonUtils getNotNullString:[dict valueForKey:@"elem_position"]];
        self.flow_modified = [CommonUtils getNotNullString:[dict valueForKey:@"modified"]];
        self.flow_name = [CommonUtils getNotNullString:[dict valueForKey:@"name"]];
        self.flow_pID = [CommonUtils getNotNullString:[dict valueForKey:@"pID"]];
        self.flow_flowCount = [CommonUtils getNotNullString:[dict valueForKey:@"flowCount"]];
        self.flow_status = [CommonUtils getNotNullString:[dict valueForKey:@"status"]];
        
        return self;
    }
    return nil;
}


@end

/*
 ID = 8;
 created = 1151493983;
 custPID = d8e2743ec8;
 description = "main entry";
 "elem_position" = "<null>";
 modified = 1152178860;
 name = reception;
 pID = 0fb5c59213;
 status = Aktiv;
 */