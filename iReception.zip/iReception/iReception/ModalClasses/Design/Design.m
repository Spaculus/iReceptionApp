//
//  Design.m
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "Design.h"

@implementation Design
- (id)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self!=nil) {
        
        self.d_ID = [CommonUtils getNotNullString:[dict valueForKey:@"ID"]];
        self.d_created = [CommonUtils getNotNullString:[dict valueForKey:@"created"]];
        self.d_custPID = [CommonUtils getNotNullString:[dict valueForKey:@"custPID"]];
        self.d_modified = [CommonUtils getNotNullString:[dict valueForKey:@"modified"]];
        self.d_name = [CommonUtils getNotNullString:[dict valueForKey:@"name"]];
        self.d_pID = [CommonUtils getNotNullString:[dict valueForKey:@"pID"]];
        self.d_status = [CommonUtils getNotNullString:[dict valueForKey:@"status"]];
        self.aryFlowDesignProperty = [self getDesignProperties:[dict valueForKey:@"FlowDesignProperty"]];
        
        return self;
    }
    return nil;
}

- (NSArray *) getDesignProperties:(NSArray *)aryProperties {
    NSMutableArray *aryProps = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in aryProperties) {
     
        DesignProperty *designProperty = [[DesignProperty alloc] initWithDictionary:dict];
        
        [aryProps addObject:designProperty];
        
    }
    
    return aryProps;
}

/*
 FlowDesignProperty
 ID = 6;
 created = 1151494200;
 custPID = d8e2743ec8;
 modified = 1151494200;
 name = VictorDesign;
 pID = b2ece9dd89;
 status = OK;
 */

@end
