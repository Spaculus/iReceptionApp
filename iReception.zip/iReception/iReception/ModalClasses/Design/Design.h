//
//  Design.h
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Design : NSObject

@property (strong, nonatomic) NSArray *aryFlowDesignProperty;
@property (strong, nonatomic) NSString *d_ID;
@property (strong, nonatomic) NSString *d_created;
@property (strong, nonatomic) NSString *d_custPID;
@property (strong, nonatomic) NSString *d_modified;
@property (strong, nonatomic) NSString *d_name;
@property (strong, nonatomic) NSString *d_pID;
@property (strong, nonatomic) NSString *d_status;

- (id)initWithDictionary:(NSDictionary *)dict;

@end

/*Design =     (
 {
 FlowDesignProperty =             (
 {
 ImageName = "<null>";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-background-color";
 value = "rgba(227,236,237,1)";
 },
 {
 ImageName = "1152869694.jpg";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-background-image";
 value = 812e0962c6;
 },
 {
 ImageName = "<null>";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-background-image-placement";
 value = "center center";
 },
 {
 ImageName = "<null>";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-background-layouttype";
 value = color;
 },
 {
 ImageName = "<null>";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-custom-css";
 value = HELLO;
 },
 {
 ImageName = "1152869506.png";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-header-homebutton";
 value = 3a2b220dfd;
 },
 {
 ImageName = "<null>";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-header-topimage";
 value = "";
 }
 );
 ID = 6;
 created = 1151494200;
 custPID = d8e2743ec8;
 modified = 1151494200;
 name = VictorDesign;
 pID = b2ece9dd89;
 status = OK;
 }
 );*/