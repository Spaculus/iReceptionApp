//
//  User.m
//  iReception
//
//  Created by spaculus on 7/12/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "User.h"

@implementation User

- (id) initWithCustomerID:(NSString *)custPID moduleName:(NSString *)module pinCode:(NSString *)value {
    self = [super init];
    if (self != nil) {
        self.customerID = custPID;
        self.flowName = module;
        self.pinCode = value;
        return self;
    }
    return  nil;
}

@end
