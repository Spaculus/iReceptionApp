//
//  User.h
//  iReception
//
//  Created by spaculus on 7/12/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (strong, nonatomic) NSString *pinCode;
@property (strong, nonatomic) NSString *flowName;
@property (strong, nonatomic) NSString *customerID;

- (id) initWithCustomerID:(NSString *)custPID moduleName:(NSString *)module pinCode:(NSString *)value;


@end


/*
 ID = 117;
 custPID = d8e2743ec8;
 module = reception;
 prop = "module-setup-logonkey";
 type = module;
 value = f03d0;
 */
