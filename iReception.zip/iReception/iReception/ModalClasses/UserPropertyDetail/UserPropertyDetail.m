//
//  UserPropertyDetail.m
//  iReception
//
//  Created by spaculus on 7/20/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "UserPropertyDetail.h"

@implementation UserPropertyDetail
- (id)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self!=nil) {
        
        self.upd_ID = [CommonUtils getNotNullString:[dict valueForKey:@"ID"]];
        self.upd_created = [CommonUtils getNotNullString:[dict valueForKey:@"check_unplanned"]];
        self.upd_created = [CommonUtils getNotNullString:[dict valueForKey:@"created"]];
        self.upd_customerPID = [CommonUtils getNotNullString:[dict valueForKey:@"customerPID"]];
        self.upd_listname = [CommonUtils getNotNullString:[dict valueForKey:@"listname"]];
        self.upd_pID = [CommonUtils getNotNullString:[dict valueForKey:@"pID"]];
        self.upd_page_headline= [CommonUtils getNotNullString:[dict valueForKey:@"page_headline"]];
        self.upd_page_subtext = [CommonUtils getNotNullString:[dict valueForKey:@"page_subtext"]];
        self.upd_sort_by = [CommonUtils getNotNullString:[dict valueForKey:@"sort_by"]];
        
        self.aryUserProperties = [self getUserProperties:[dict valueForKey:@"UsersProperty"]];
        
        
        return self;
    }
    return nil;
}

- (NSArray *) getUserProperties:(NSArray *)aryProperties {
    NSMutableArray *aryProps = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in aryProperties) {
        UserProperty *userProperty = [[UserProperty alloc] initWithDictionary:dict];
        [aryProps addObject:userProperty];
        
    }
    
    return aryProps;
}

@end

/*
 "check_unplanned" = N;
 created = 1152088358;
 customerPID = d8e2743ec8;
 listname = "List of Companies";
 pID = f3cbd5e69c; /////////////////////////// TARGET PID FOR GET_FLOW_END_USER WS PARAM
 "page_headline" = "Find your company";
 "page_subtext" = "<null>";
 "sort_by" = byAlphabet;
 */