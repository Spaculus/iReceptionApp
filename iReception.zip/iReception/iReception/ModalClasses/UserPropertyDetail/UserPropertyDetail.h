//
//  UserPropertyDetail.h
//  iReception
//
//  Created by spaculus on 7/20/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserPropertyDetail : NSObject

@property (strong, nonatomic) NSString * upd_ID;
@property (strong, nonatomic) NSString * upd_check_unplanned;
@property (strong, nonatomic) NSString * upd_created;
@property (strong, nonatomic) NSString * upd_customerPID;
@property (strong, nonatomic) NSString * upd_listname;

@property (strong, nonatomic) NSString * upd_pID;
@property (strong, nonatomic) NSString * upd_page_headline;
@property (strong, nonatomic) NSString * upd_page_subtext;
@property (strong, nonatomic) NSString * upd_sort_by;

@property (strong, nonatomic) NSArray * aryUserProperties;

- (id)initWithDictionary:(NSDictionary *)dict;

@end
