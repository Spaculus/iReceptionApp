//
//  UserProperty.m
//  iReception
//
//  Created by spaculus on 7/20/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "UserProperty.h"

@implementation UserProperty
- (id)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self!=nil) {
        
        self.up_ID = [CommonUtils getNotNullString:[dict valueForKey:@"ID"]];
        self.up_admin = [CommonUtils getNotNullString:[dict valueForKey:@"admin"]];
        self.up_created = [CommonUtils getNotNullString:[dict valueForKey:@"created"]];
        self.up_customerPID = [CommonUtils getNotNullString:[dict valueForKey:@"customerPID"]];
        self.up_email = [CommonUtils getNotNullString:[dict valueForKey:@"email"]];
        self.up_name = [CommonUtils getNotNullString:[dict valueForKey:@"name"]];
        self.up_pID = [CommonUtils getNotNullString:[dict valueForKey:@"pID"]];
        self.up_phone = [CommonUtils getNotNullString:[dict valueForKey:@"phone"]];
        self.up_pincode = [CommonUtils getNotNullString:[dict valueForKey:@"pincode"]];
        self.up_reset_pincode = [CommonUtils getNotNullString:[dict valueForKey:@"reset_pincode"]];
        self.up_status = [CommonUtils getNotNullString:[dict valueForKey:@"status"]];
        self.up_systemuser = [CommonUtils getNotNullString:[dict valueForKey:@"systemuser"]];
        self.up_username = [CommonUtils getNotNullString:[dict valueForKey:@"username"]];
        self.up_formAction = [CommonUtils getNotNullString:[dict valueForKey:@"formAction"]];
        self.up_message = [CommonUtils getNotNullString:[dict valueForKey:@"message"]];
        self.up_issub = [CommonUtils getNotNullString:[dict valueForKey:@"issub"]];
        return self;
    }
    return nil;
}

@end

/*
 ID = 253;
 admin = N;
 created = 1152088445;
 customerPID = d8e2743ec8;
 email = "hi@spaculus.com";
 name = Spaculus;
 pID = 1768e03c11; //////////////////////// USER PID PARAM FOR GET_FLOW_END_USER WS
 phone = 45454545;
 pincode = 92f2eca62b6d7b76d1b7e5d117a9387bd31b3665506751afd9f906b8f2e1a8e7;
 "reset_pincode" = Y;
 status = Aktiv;
 systemuser = N;
 username = spa;
 "formAction":"default",
 "message":""
 */

/*
ID = 247;
admin = N;
created = 1151755688;
customerPID = d8e2743ec8;
email = "martin.kristensen@fifonetwork.com";
name = "Martin Kristensen";
pID = 11d8953b8d;
phone = 61301777;
pincode = 5616b00748424b555643e35b623f2e82430dc57e936b0da684c5e64b295f00b8;
"reset_pincode" = Y;
status = Aktiv;
systemuser = N;
username = mgg;
 */
