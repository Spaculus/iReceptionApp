//
//  UserProperty.h
//  iReception
//
//  Created by spaculus on 7/20/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserProperty : NSObject

@property (strong, nonatomic) NSString * up_ID;
@property (strong, nonatomic) NSString * up_admin;
@property (strong, nonatomic) NSString * up_created;
@property (strong, nonatomic) NSString * up_customerPID;
@property (strong, nonatomic) NSString * up_email;
@property (strong, nonatomic) NSString * up_name;
@property (strong, nonatomic) NSString * up_pID;
@property (strong, nonatomic) NSString * up_phone;
@property (strong, nonatomic) NSString * up_pincode;
@property (strong, nonatomic) NSString * up_reset_pincode;
@property (strong, nonatomic) NSString * up_status;
@property (strong, nonatomic) NSString * up_systemuser;
@property (strong, nonatomic) NSString * up_username;
@property (strong, nonatomic) NSString * up_formAction;
@property (strong, nonatomic) NSString * up_message;
@property (strong, nonatomic) NSString * up_issub;

- (id)initWithDictionary:(NSDictionary *)dict;

/*
 ID = 253;
 admin = N;
 created = 1152088445;
 customerPID = d8e2743ec8;
 email = "hi@spaculus.com";
 name = Spaculus;
 pID = 1768e03c11;
 phone = 45454545;
 pincode = 92f2eca62b6d7b76d1b7e5d117a9387bd31b3665506751afd9f906b8f2e1a8e7;
 "reset_pincode" = Y;
 status = Aktiv;
 systemuser = N;
 username = spa;
 */

@end
