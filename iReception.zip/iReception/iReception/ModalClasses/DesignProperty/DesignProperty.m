//
//  DesignProperty.m
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "DesignProperty.h"

@implementation DesignProperty
- (id)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self!=nil) {
        
        self.dp_ImageName = [CommonUtils getNotNullString:[dict valueForKey:@"ImageName"]];
        self.dp_flow_designPID = [CommonUtils getNotNullString:[dict valueForKey:@"flow_designPID"]];
        self.dp_prop = [CommonUtils getNotNullString:[dict valueForKey:@"prop"]];
        self.dp_value = [CommonUtils getNotNullString:[dict valueForKey:@"value"]];
        
        return self;
    }
    return nil;
}

@end

/*
 ImageName = "<null>";
 "flow_designPID" = b2ece9dd89;
 prop = "setting-background-color";
 value = "rgba(227,236,237,1)";
 */