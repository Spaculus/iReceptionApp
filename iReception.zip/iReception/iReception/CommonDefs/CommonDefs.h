//
//  CommonDefs.h
//  AmericanDiveBars
//
//  Created by spaculus on 8/27/15.
//  Copyright (c) 2015 spaculus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonDefs : NSObject


#pragma mark - WEBSERVICE URL

//#define WEBSERVICE_URL @"http://192.168.1.112:9191/api/values/"
#define WEBSERVICE_URL @"http://app.iadmin.dk/api/values/"
#define BG_IMAGE_URL   @"http://www.iadmin.dk/log/upload/"
//http://iadmin.dk/log/upload/
#pragma mark - WEBSERVICE METHODS

#define LOGIN_DETAILS                          @"GetLogin"
#define GET_FLOW_LIST                          @"GetFlow"
#define GET_FLOW_STRUCTURE_WITH_PARENT_ID      @"GetFlowStructureById"
#define GET_FLOW_END_USER                      @"GetFlowEndUsers"
#define GET_FLOW_ENTRY_KEY                     @"GetFlowEntryKey"
#define GET_FLOW_STRUCTURE_WITH_PARENT_ID      @"GetFlowStructureById"
#define GET_FLOW_END_USER_LIST                 @"GetFlowEndUsersList"
#define GET_FLOW_END_USER                      @"GetFlowEndUsers"
#define SEND_NOTIFICATION                      @"SendNotification"
#define SIGN_UP                                @"Signup"

#pragma mark - ALERT TITLE

//-----------------------------

#define AlertTitle @"iReception"

#pragma mark - CORNER RADIUS FOR TEXTFIELD

#define iPadCornerRadius 25.0
#define iPhoneCornerRadius 20.0

#pragma mark - ERROR MESSAGES

#define ERR_COMMON @"Something went wrong, please try again later."
#define MSG_NO_INTERNET_CONNECTION @"No Internet Connection. Please Try Again"
#define MSG_SERVER_NOT_REACHABLE @"Server not reachable. Please try again."

#pragma mark - DESIGN PROPERTY CONSTANTS

#define DP_BG_COLOR             @"setting-background-color"
#define DP_BG_IMAGE             @"setting-background-image"
#define DP_BG_IMAGE_PLACEMENT   @"setting-background-image-placement"
#define DP_BG_TYPE              @"setting-background-layouttype"
#define DP_CSS                  @"setting-custom-css"
#define DP_HOME_BUTTON          @"setting-header-homebutton"
#define DP_TOP_IMAGE            @"setting-header-topimage"

#define DP_TAG_BG_COLOR             0
#define DP_TAG_BG_IMAGE             1
#define DP_TAG_BG_IMAGE_PLACEMENT   2
#define DP_TAG_BG_TYPE              3
#define DP_TAG_CSS                  4
#define DP_TAG_HOME_BUTTON          5
#define DP_TAG_TOP_IMAGE            6

#pragma mark -

#define DISPLAY_NO_INTERNET_CONNECTION @"DisplayNoInternetConnection"
#define DISPLAY_NO_INTERNET_CONNECTION_LOGIN @"DisplayNoInternetConnection_Login"
#define DISPLAY_NO_INTERNET_CONNECTION_FLOW @"DisplayNoInternetConnection_Flow"
#define DISPLAY_NO_INTERNET_CONNECTION_SUB_FLOW @"DisplayNoInternetConnection_Sub_Flow"

@end

