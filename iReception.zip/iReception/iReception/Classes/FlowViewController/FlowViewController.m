//
//  FlowViewController.m
//  iReception
//
//  Created by spaculus on 7/7/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "FlowViewController.h"
#import "FlowDetailScreenViewController.h"
#import "HomeViewController.h"
#import "NoInternetConnection.h"

#import "FlowOnlyCell.h"
#import "FlowWithHeaderCell.h"

static NSString * const FlowOnlyCellIdentifier = @"FlowOnlyCell";
static NSString * const FlowWithHeaderCellIdentifier = @"FlowWithHeaderCell";

@interface FlowViewController () <UITableViewDataSource, UITableViewDelegate,NoInternetConnectionDelegate> {
    NSMutableArray *aryList;
    
    BOOL isWS;
    NSString *webserviceMethodName;
    NoInternetConnection *noInternetConnectionView;
    
    NSTimer *noInternetTimer;
}
@property (strong, nonatomic) IBOutlet UILabel *lblFlowTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblFlowNameTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblDescTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblNoOfFlowStartTItle;

@property (strong, nonatomic) IBOutlet UITableView *tblView;
@property (nonatomic, strong) NSMutableData *responseData;
@property (nonatomic, strong) NSURLConnection *connectionLogin;

@end

@implementation FlowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    
    [self initData];
    webserviceMethodName = @"getFlowList";
    [CommonUtils callWebservice:@selector(getFlowList) forTarget:self];
    // Do any additional setup after loading the view from its nib.
}

-(void)initData {
   aryList = [[NSMutableArray alloc]  init];
    
    
   
    
    self.lblFlowTitle.text = @"Vælg et flow ?";
    self.lblFlowNameTitle.text = @"Flow navn";
    self.lblDescTitle.text = @"Beskrivelse";
    self.lblNoOfFlowStartTItle.text = @"Antal flowstart";
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    
    noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];

    
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayNoInternetConnection) name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
    /*if (isWS) {
        [self registerCell];
        [self.tblView reloadData];
    }*/
}


- (void)checkInterNet {
    if ([CommonUtils connected]) {
        
        if([noInternetTimer isValid])
        {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
            
        }
        
        noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
        
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}/*{
    if ([CommonUtils connected]) {
        
//        if([noInternetTimer isValid])
//        {
//            [noInternetTimer invalidate];
//            noInternetTimer = nil;
//        }
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}*/

#pragma mark NO INTERNET CONNECTION VIEW
- (void)displayNoInternetConnection {
    NoInternetConnection *noInternetView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:NO];
    noInternetView.delegate = self;
    
}

- (void)dismissMessageNoInternetConnection:(NoInternetConnection *)noInternetConnection {
    [self callWebserviceAfterInternetConnectionAvailable];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
    if (noInternetConnectionView!=nil){
        noInternetConnectionView = nil;
    }
}

- (void) callWebserviceAfterInternetConnectionAvailable {
    if ([webserviceMethodName isEqualToString:@"getFlowList"]) {
        [CommonUtils callWebservice:@selector(getFlowList) forTarget:self];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableview Delegates

-(void)registerCell
{
    //[self.tblView registerNib:[UINib nibWithNibName:@"FlowWithHeaderCell" bundle:nil] forCellReuseIdentifier:FlowWithHeaderCellIdentifier];
    [self.tblView registerNib:[UINib nibWithNibName:@"FlowOnlyCell" bundle:nil] forCellReuseIdentifier:FlowOnlyCellIdentifier];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [CommonUtils getArrayCountFromArray:aryList];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self FlowOnlyCellAtIndexPath:indexPath];
    /*if (indexPath.row == 0) {
        //return [self FlowWithHeaderCellAtIndexPath:indexPath];
    }
    else {
        return [self FlowOnlyCellAtIndexPath:indexPath];
    }*/
}

#pragma mark FlowWithHeaderCell Cell Configuration
- (FlowWithHeaderCell *)FlowWithHeaderCellAtIndexPath:(NSIndexPath *)indexPath
{
    static FlowWithHeaderCell *cell = nil;
    cell = [self.tblView dequeueReusableCellWithIdentifier:FlowWithHeaderCellIdentifier];
    [self configureFlowWithHeaderCell:cell atIndexPath:indexPath];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
- (void)configureFlowWithHeaderCell:(FlowWithHeaderCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    //cell.lblTitle.text = @"haukhdfjkaskdjh fkasdf kaskdfkhaskdfh jkahsfk kajshdfjkhasdjkfh kashdf khkasdh fkjasdfh klhasdlflkasdhfklhasdkfjhaklsdhfkjahsdkfjhaksjdhfkhasdkfhkasdhfkjlsahdfjklh sakdjhf kjsdh fkjhasdfh alksdfhklashdfklhasd fhaksd hkhsa dfkh sadhf lsadhfjlkash dfjklhaskdjfh khsad fhaksdhf khasdfkhasdkf klash dfklha sdfkjh askljdfh kjlahsdfjklh askldjfhkashdfk hasdlkfh aklsdhf klash df EOL JEKIL";
    
    // cell.lblDesc.text = @"haukhdfjkaskdjh fkasdf kaskdfkhaskdfh jkahsfk kajshdfjkhasdjkfh kashdf khkasdh fkjasdfh klhasdlflkasdhfklhasdkfjhaklsdhfkjahsdkfjhaksjdhfkhasdkfhkasdhfkjlsahdfjklh sakdjhf kjsdh fkjhasdfh alksdfhklashdfklhasd fhaksd hkhsa dfkh sadhf lsadhfjlkash dfjklhaskdjfh khsad fhaksdhf khasdfkhasdkf klash dfklha sdfkjh askljdfh kjlahsdfjklh askldjfhkashdfk hasdlkfh aklsdhf klash df  haukhdfjkaskdjh fkasdf kaskdfkhaskdfh jkahsfk kajshdfjkhasdjkfh kashdf khkasdh fkjasdfh klhasdlflkasdhfklhasdkfjhaklsdhfkjahsdkfjhaksjdhfkhasdkfhkasdhfkjlsahdfjklh sakdjhf kjsdh fkjhasdfh alksdfhklashdfklhasd fhaksd hkhsa dfkh sadhf lsadhfjlkash dfjklhaskdjfh khsad fhaksdhf khasdfkhasdkf klash dfklha sdfkjh askljdfh kjlahsdfjklh askldjfhkashdfk hasdlkfh aklsdhf klash df EOL TJ";
}

#pragma mark FlowOnlyCell Cell Configuration
- (FlowOnlyCell *)FlowOnlyCellAtIndexPath:(NSIndexPath *)indexPath
{
    static FlowOnlyCell *cell = nil;
    cell = [self.tblView dequeueReusableCellWithIdentifier:FlowOnlyCellIdentifier];
    [self configureFlowOnlyCell:cell atIndexPath:indexPath];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
- (void)configureFlowOnlyCell:(FlowOnlyCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == [aryList count]-1) {
        cell.lblLineBottom.hidden = NO;
    }
    else {
        cell.lblLineBottom.hidden = YES;
    }
    
    Flow *flow = [aryList objectAtIndex:indexPath.row];
    cell.lblFlowName.text = [flow flow_name];
    cell.lblDesc.text = [flow flow_description];
    cell.lblFlowNumber.text = [flow flow_flowCount];
    
    cell.btnStartReception.tag = indexPath.row;
    [cell.btnStartReception addTarget:self action:@selector(onClickButtonStartReception:) forControlEvents:UIControlEventTouchUpInside];
}

- (void) onClickButtonStartReception: (UIButton *)btnStartreception {
    
    Flow *flow = [aryList objectAtIndex:btnStartreception.tag];
    
    FlowDetailScreenViewController *flowDetail = [[FlowDetailScreenViewController alloc] initWithNibName:@"FlowDetailScreenViewController" bundle:nil];
    flowDetail.flow = flow;
    [self.navigationController pushViewController:flowDetail animated:YES];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat cellHeight = [self heightForFlowOnlyCellAtIndexPath:indexPath];
    return cellHeight;
    /*if (indexPath.row) {
        CGFloat cellHeight = [self heightForFlowWithHeaderCellAtIndexPath:indexPath];
        return cellHeight;
    }
    else {
        CGFloat cellHeight = [self heightForFlowOnlyCellAtIndexPath:indexPath];
        return cellHeight;
    }*/
    
}
#pragma mark NewsCell Cell With Height Configuration
- (CGFloat)heightForFlowWithHeaderCellAtIndexPath:(NSIndexPath *)indexPath
{
    static FlowWithHeaderCell *sizingCell = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sizingCell = [self.tblView dequeueReusableCellWithIdentifier:FlowWithHeaderCellIdentifier];
    });
    
    [self configureFlowWithHeaderCell:sizingCell atIndexPath:indexPath];
    return [self calculateHeightForConfiguredSizingCell:sizingCell];
}
- (CGFloat)heightForFlowOnlyCellAtIndexPath:(NSIndexPath *)indexPath
{
    static FlowOnlyCell *sizingCell = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sizingCell = [self.tblView dequeueReusableCellWithIdentifier:FlowOnlyCellIdentifier];
    });
    
    [self configureFlowOnlyCell:sizingCell atIndexPath:indexPath];
    return [self calculateHeightForConfiguredSizingCell:sizingCell];
}
#pragma mark Calculate Height for Cell

- (CGFloat)calculateHeightForConfiguredSizingCell:(UITableViewCell *)sizingCell
{
    sizingCell.bounds = CGRectMake(0.0f, 0.0f, CGRectGetWidth(self.tblView.frame), CGRectGetHeight(sizingCell.bounds));
    [sizingCell setNeedsLayout];
    [sizingCell layoutIfNeeded];
    
    CGSize size = [sizingCell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
    return size.height + 1.0f; // Add 1.0f for the cell separator height
}
#pragma mark Estmated Height For Row
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }

    Flow *flow = [aryList objectAtIndex:indexPath.row];
    
    FlowDetailScreenViewController *flowDetail = [[FlowDetailScreenViewController alloc] initWithNibName:@"FlowDetailScreenViewController" bundle:nil];
    flowDetail.flow = flow;
    [self.navigationController pushViewController:flowDetail animated:YES];
}


#pragma mark Webservice Requests
-(void)getFlowList
{
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_LIST];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"customerPID=%@",[[CommonUtils getLoginDetails] customerID]];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionLogin = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionLogin )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}
#pragma mark Webservice Response
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [self.responseData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.responseData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connectionDidFinishLoading");
    
    NSString *stringResponse = [[NSString alloc]initWithData:self.responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Response : %@",stringResponse);
    
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
    
    NSError *jsonParsingError = nil;
    NSDictionary *tempDict = [NSJSONSerialization JSONObjectWithData:self.responseData options:0 error:&jsonParsingError];
    
    if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
        
        NSArray *aryFlowList = [tempDict valueForKey:@"Result"];
        aryList = [self getArratListForFlow:aryFlowList];
        
        [self registerCell];
        [self.tblView reloadData];
        
    }
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
}

#pragma mark - Parse Web service Response
- (NSMutableArray *)getArratListForFlow:(NSArray *)aryFlowList {
    NSMutableArray *aryFlows = [[NSMutableArray alloc] init];
    if ([aryFlows count]!=0) {
        [aryFlows removeAllObjects];
    }
    
    for (NSDictionary *dict in aryFlowList) {
        Flow *flow = [[Flow alloc] initWithDictionary:dict];
        if ([flow.flow_flowCount intValue]!=0) {
            [aryFlows addObject:flow];
        }
        
    }
    
    return aryFlows;
}





#pragma mark - Status Bar
//-(BOOL)prefersStatusBarHidden{
//    return YES;
//}

#pragma mark willRotateToAnimation
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [self.tblView reloadData];
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
     }completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}


@end
