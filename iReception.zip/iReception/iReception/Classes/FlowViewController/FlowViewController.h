//
//  FlowViewController.h
//  iReception
//
//  Created by spaculus on 7/7/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowViewController : UIViewController

@end
