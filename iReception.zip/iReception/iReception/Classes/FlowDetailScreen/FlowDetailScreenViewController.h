//
//  FlowDetailScreenViewController.h
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowDetailScreenViewController : UIViewController
@property (strong, nonatomic) Flow *flow;
@end
