//
//  FlowDetailScreenViewController.m
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "FlowDetailScreenViewController.h"
#import "FlowStartViewController.h"
#import "HomeViewController.h"
#import "FlowDetailCell.h"
#import "NoInternetConnection.h"

@interface FlowDetailScreenViewController () <UITableViewDataSource, UITableViewDelegate, NoInternetConnectionDelegate> {
    NSMutableArray *aryList;
    NSInteger row;
    SubFlow *subFlow;
    NSString *webserviceMethodName;
    NoInternetConnection *noInternetConnectionView;
    
    NSTimer *noInternetTimer;
}

@property (strong, nonatomic) IBOutlet UILabel *lblFlowTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblFlowNameTitle;


@property (strong, nonatomic) IBOutlet UIButton *btnStartiReception;
@property (strong, nonatomic) IBOutlet UITableView *tblView;
@property (nonatomic, strong) NSMutableData *responseData;
@property (nonatomic, strong) NSURLConnection *connectionFlowDetail;


@property (strong, nonatomic) IBOutlet UIButton *btnBack;
- (IBAction)onButtonBackClicked:(id)sender;
@end

@implementation FlowDetailScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    
    [self initData];
    webserviceMethodName = @"getFlowList";
    [CommonUtils callWebservice:@selector(getFlowList) forTarget:self];
    // Do any additional setup after loading the view from its nib.
}

-(void)initData {
    row = -1;
    subFlow = nil;
    aryList = [[NSMutableArray alloc]  init];
    [self.btnStartiReception setEnabled:NO];
    
    if ([CommonUtils isEnglishLanguage]) {
        self.lblFlowTitle.text = @"Choose a starting point ?";
        self.lblFlowNameTitle.text = @"Starting Point name";
    }
    else {
        self.lblFlowTitle.text = @"Vælg et startpunkt ?";
        self.lblFlowNameTitle.text = @"Startpunkt";// @"startpunkt navn";
    }
    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    
    noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
    
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayNoInternetConnection) name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
}



- (void)checkInterNet {
    if ([CommonUtils connected]) {
        
        if([noInternetTimer isValid])
        {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
            
        }
        
        noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
        
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}/*{
    if ([CommonUtils connected]) {
        
//        if([noInternetTimer isValid])
//        {
//            [noInternetTimer invalidate];
//            noInternetTimer = nil;
//        }
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}
*/

#pragma mark NO INTERNET CONNECTION VIEW
- (void)displayNoInternetConnection {
    NoInternetConnection *noInternetView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:NO];
    noInternetView.delegate = self;
    
}

- (void)dismissMessageNoInternetConnection:(NoInternetConnection *)noInternetConnection {
    [self callWebserviceAfterInternetConnectionAvailable];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
    if (noInternetConnectionView!=nil){
        noInternetConnectionView = nil;
    }
}

- (void) callWebserviceAfterInternetConnectionAvailable {
    if ([webserviceMethodName isEqualToString:@"getFlowList"]) {
        [CommonUtils callWebservice:@selector(getFlowList) forTarget:self];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableview Delegates


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [CommonUtils getArrayCountFromArray:aryList];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *menuIdentifier = @"FlowDetailCell";
    FlowDetailCell *cell = (FlowDetailCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"FlowDetailCell" owner:self options:nil];
        if([CommonUtils isiPad])
        {
            cell = [nib objectAtIndex:0];
        }
        else
        {
            cell = [nib objectAtIndex:0];
        }
    }
    
//    if (indexPath.row == row) {
//        cell.lblBG.backgroundColor = [UIColor colorWithRed:241.0/255.0 green:252.0/255.0 blue:240.0/255.0 alpha:1.0];
//    }
//    else {
//        cell.lblBG.backgroundColor = [UIColor whiteColor];
//    }
    
    if (indexPath.row == [aryList count]-1) {
        cell.lblLineBottom.hidden = NO;
    }
    else {
        cell.lblLineBottom.hidden = YES;
    }
    
    cell.lblFlowName.text = [[aryList objectAtIndex:indexPath.row] subFlow_startname];
    
    cell.btnChoose.tag = indexPath.row;
    //[cell.btnChoose setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
    //[cell.btnChoose setBackgroundImage:[UIImage imageNamed:@"btn_hover"] forState:UIControlStateHighlighted];

    [cell.btnChoose addTarget:self action:@selector(onClickButtonChoose:) forControlEvents:UIControlEventTouchUpInside];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void) onClickButtonChoose: (UIButton *)btnChoose {
    
}

- (IBAction) onClickButtonStartReception: (UIButton *)btnStartreception {
    /*[[NSUserDefaults standardUserDefaults] setValue:@"2" forKey:@"LoggedIn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:subFlow.subFlow_flowPID forKey:@"root_flowPID"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    [[NSUserDefaults standardUserDefaults] setValue:subFlow.subFlow_pID forKey:@"root_childPID"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    [[NSUserDefaults standardUserDefaults] setValue:subFlow.subFlow_page_headline forKey:@"root_headline"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    HomeViewController *home = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    home.subFlow = subFlow;
    if (subFlow.subFlow_targetPID.length !=0) {
        home.isChild = NO;
        home.isTarget = YES;
        home.isTargetElement = YES;
    }
    else {
        home.isChild = YES;
        home.isTarget = NO;
        home.isTargetElement = NO;
    }
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:home];
    appDel.window.rootViewController = nav;
    
    [UIView transitionWithView:appDel.window
                      duration:0.3
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:nil
                    completion:nil];*/
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

#pragma mark Estmated Height For Row
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    row = indexPath.row;
    subFlow = [aryList objectAtIndex:row];
    self.btnStartiReception.enabled = YES;
    [self.tblView reloadData];
    
    FlowStartViewController *flowStart = [[FlowStartViewController alloc] initWithNibName:@"FlowStartViewController" bundle:nil];
    flowStart.subFlow = subFlow;
    [self.navigationController pushViewController:flowStart animated:YES];
}

#pragma mark Webservice Requests
-(void)getFlowList
{
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_ENTRY_KEY];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"flowPID=%@",[self.flow flow_pID]];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionFlowDetail = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionFlowDetail )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}
#pragma mark Webservice Response
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [self.responseData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.responseData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connectionDidFinishLoading");
    
    NSString *stringResponse = [[NSString alloc]initWithData:self.responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Response : %@",stringResponse);
    
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
    
    NSError *jsonParsingError = nil;
    NSDictionary *tempDict = [NSJSONSerialization JSONObjectWithData:self.responseData options:0 error:&jsonParsingError];
    
    if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
        
        NSArray *aryFlowList = [tempDict valueForKey:@"Result"];
        aryList = [self getArratListForFlow:aryFlowList];
        
        [self.tblView reloadData];
        
    }
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
}

#pragma mark - Parse Web service Response
- (NSMutableArray *)getArratListForFlow:(NSArray *)aryFlowList {
    NSMutableArray *aryFlows = [[NSMutableArray alloc] init];
    if ([aryFlows count]!=0) {
        [aryFlows removeAllObjects];
    }
    
    for (NSDictionary *dict in aryFlowList) {
        SubFlow *subFlow_ = [[SubFlow alloc] initWithDictionary:dict];
        [aryFlows addObject:subFlow_];
    }
    
    return aryFlows;
}





#pragma mark - Status Bar
//-(BOOL)prefersStatusBarHidden{
//    return YES;
//}

#pragma mark willRotateToAnimation
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [self.tblView reloadData];
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
     }completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

- (IBAction)onButtonBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end

