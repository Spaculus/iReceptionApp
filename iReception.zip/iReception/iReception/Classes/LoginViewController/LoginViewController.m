//
//  LoginViewController.m
//  iReception
//
//  Created by spaculus on 7/5/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "LoginViewController.h"
#import "SignUpViewController.h"
#import "FlowViewController.h"

#import "LoginCell.h"

#import "NoInternetConnection.h"



@interface LoginViewController () <UITableViewDataSource, UITableViewDelegate,LoginCellDelegate,NoInternetConnectionDelegate> {
    NSString *passCode;
    NSString *webserviceMethodName;
    
    NoInternetConnection *noInternetConnectionView;
    
    NSTimer *noInternetTimer;
}
@property (strong, nonatomic) IBOutlet UITableView *tblView;
@property (nonatomic, strong) NSMutableData *responseData;
@property (nonatomic, strong) NSURLConnection *connectionLogin;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    
    [self initData];
    
    // Do any additional setup after loading the view from its nib.
}

-(void)initData {
    passCode = [CommonUtils getNotNullString:passCode];
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayNoInternetConnection) name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    
    noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableview Delegates
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 354;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *menuIdentifier = @"LoginCell";
    LoginCell *cell = (LoginCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"LoginCell" owner:self options:nil];
        if([CommonUtils isiPad])
        {
            cell = [nib objectAtIndex:0];
        }
        else
        {
            cell = [nib objectAtIndex:0];
        }
    }
    
    cell.delegate = self;
    
    [cell.btnSignIn addTarget:self action:@selector(onClickSignIn) forControlEvents:UIControlEventTouchUpInside];
    //[cell.btnSignUp addTarget:self action:@selector(onClickSignUp) forControlEvents:UIControlEventTouchUpInside];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


-(void)didFinishEditingWithLoginCell:(LoginCell *)cell text:(NSString *)aText {
    NSLog(@"Text = %@",aText);
    passCode = [CommonUtils getNotNullString:aText];
}

-(void)onClickSignUp {
    NSLog(@"SignUp");
    SignUpViewController *signUp = [[SignUpViewController alloc] initWithNibName:@"SignUpViewController" bundle:nil];
    [self.navigationController pushViewController:signUp animated:YES];
}

-(void)onClickSignIn {
    NSLog(@"Text = %@",passCode);
    if (passCode.length == 5) {
        webserviceMethodName = @"loginService";
        [CommonUtils callWebservice:@selector(loginService) forTarget:self];
    }
    else {
        if (passCode.length == 0) {
            ShowAlert(AlertTitle, @"Please enter valid logon key!");
        }
        else {
            ShowAlert(AlertTitle, @"Invalid Code!");
        }
    }
}

- (void)checkInterNet {
    if ([CommonUtils connected]) {
        
        if([noInternetTimer isValid])
        {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
            
        }
        
        noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
        
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}/*{
    if ([CommonUtils connected]) {
        
//        if([noInternetTimer isValid])
//        {
//            [noInternetTimer invalidate];
//            noInternetTimer = nil;
//        }
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
        
    }
}*/

#pragma mark NO INTERNET CONNECTION VIEW
- (void)displayNoInternetConnection {
    NoInternetConnection *noInternetView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:NO];
    noInternetView.delegate = self;
    
}

- (void)dismissMessageNoInternetConnection:(NoInternetConnection *)noInternetConnection {
    [self callWebserviceAfterInternetConnectionAvailable];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
    if (noInternetConnectionView!=nil){
        noInternetConnectionView = nil;
    }
}

- (void) callWebserviceAfterInternetConnectionAvailable {
    if ([webserviceMethodName isEqualToString:@"loginService"]) {
        [CommonUtils callWebservice:@selector(loginService) forTarget:self];
    }
}



#pragma mark Webservice Requests
-(void)loginService
{
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,LOGIN_DETAILS];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"logonkey=%@",passCode];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionLogin = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionLogin )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}
#pragma mark Webservice Response
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [self.responseData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.responseData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connectionDidFinishLoading");
    
    NSString *stringResponse = [[NSString alloc]initWithData:self.responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Response : %@",stringResponse);
    
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
    
    NSError *jsonParsingError = nil;
    NSDictionary *tempDict = [NSJSONSerialization JSONObjectWithData:self.responseData options:0 error:&jsonParsingError];
    
    if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
        
        NSDictionary *dictDetail = [[tempDict valueForKey:@"Result"] objectAtIndex:0];
        
        [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"TimePeriod"] objectAtIndex:0] valueForKey:@"value"] forKey:@"resetAfterAlert"];
        [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"TimePeriod"] objectAtIndex:1] valueForKey:@"value"] forKey:@"resetForAlert"];
        [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"TimePeriod"] objectAtIndex:2] valueForKey:@"value"] forKey:@"resetForChild"];
        
        if ([[tempDict valueForKey:@"CalendarProperty"] count]!=0) {
            [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"CalendarProperty"] objectAtIndex:0] valueForKey:@"value"] forKey:@"ics_available"];
            [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"CalendarProperty"] objectAtIndex:1] valueForKey:@"value"] forKey:@"timeAfter"];
            [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"CalendarProperty"] objectAtIndex:2] valueForKey:@"value"] forKey:@"timeBefore"];
            
            [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"CalendarProperty"] objectAtIndex:0] valueForKey:@"value"] forKey:@"ics_available_INIT"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"CalendarProperty"] objectAtIndex:1] valueForKey:@"value"] forKey:@"timeAfter_INIT"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"CalendarProperty"] objectAtIndex:2] valueForKey:@"value"] forKey:@"timeBefore_INIT"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        else {
//            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"resetAfterAlert"];
//            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"resetForAlert"];
//            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"resetForChild"];
        }
        
        
        [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"TimePeriod"] objectAtIndex:0] valueForKey:@"value"] forKey:@"resetAfterAlert_INIT"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"TimePeriod"] objectAtIndex:1] valueForKey:@"value"] forKey:@"resetForAlert_INIT"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setValue:[[[tempDict valueForKey:@"TimePeriod"] objectAtIndex:2] valueForKey:@"value"] forKey:@"resetForChild_INIT"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
       
        
        [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"LoggedIn"];
        
        [[NSUserDefaults standardUserDefaults] setValue:[CommonUtils getNotNullString:[dictDetail valueForKey:@"custPID"]] forKey:@"custID"];
        [[NSUserDefaults standardUserDefaults] setValue:[CommonUtils getNotNullString:[dictDetail valueForKey:@"module"]] forKey:@"flowname"];
        [[NSUserDefaults standardUserDefaults] setValue:[CommonUtils getNotNullString:[dictDetail valueForKey:@"value"]] forKey:@"pincode"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        if([noInternetTimer isValid])
        {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
            
        }
        
        FlowViewController *flow = [[FlowViewController alloc]  initWithNibName:@"FlowViewController" bundle:nil];
        [self.navigationController pushViewController:flow animated:YES];
        
    }
    else {
        NSString *errorMessage = [CommonUtils getNotNullString:[tempDict valueForKey:@"Result"]];
        if ([errorMessage length]!=0) {
            NSString *message = [NSString stringWithFormat:@"%@!",errorMessage];
            ShowAlert(AlertTitle, message);
        }
        else {
            ShowAlert(AlertTitle, [NSString stringWithFormat:@"Please enter valid logon key!"]);
        }
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"Fail =  %@",[error description]);
}

#pragma mark - Status Bar
//-(BOOL)prefersStatusBarHidden{
//    return YES;
//}

#pragma mark - willRotateToAnimation
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [self.tblView reloadData];
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
     }completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

@end
