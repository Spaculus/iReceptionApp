//
//  HomeViewController.m
//  iReception
//
//  Created by spaculus on 7/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "HomeViewController.h"
#import "LoginViewController.h"
#import "GridCell.h"
#import "EventCell.h"

#import "StandardForm.h"
#import "ContactForm.h"
#import "MessageForm.h"
#import "ThankYouForm.h"
#import "ThankYouContactForm.h"
#import "NoInternetConnection.h"

#import "MXLCalendarManager.h"


#define KEY_topleft         @"top left"
#define KEY_topcenter       @"top center"
#define KEY_topright        @"top right"
#define KEY_centerleft      @"center left"
#define KEY_centercenter    @"center center"
#define KEY_centerright     @"center right"
#define KEY_bottomleft      @"bottom left"
#define KEY_bottomcenter    @"bottom center"
#define KEY_bottomright     @"bottom right"

static NSString * const EventCellIdentifier = @"EventCell";
@interface HomeViewController () <UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDelegate,UITableViewDataSource,ContactFormDelegate,StandardFormDelegate,MessageFormDelegate,ThankYouFormDelegate,ThankYouContactFormDelegate,NoInternetConnectionDelegate> {
    NSMutableArray *aryList;
    Design *design;
    SubFlow *subFlow_ForChild;
    UserProperty *userProperty;
    UserPropertyDetail *propDetail;
    
    NSString *name;
    NSString *mobileNo;
    NSString *email;
    NSString *msg;
    
    BOOL isStandardType;
    
    NSString *webserviceMethodName;
    
    NSString *ics,*strTimeAfter,*strTimeBefore;
    
    NoInternetConnection *noInternetConnectionView;
    
    NSTimer *noInternetTimer;
    
    MXLCalendar *currentCalendar;
    
    NSMutableDictionary *savedDates;
    
    NSArray *allEvents;
    NSMutableArray *aryEvents;
    
    NSTimer *calTimer;
    
    NSString *rootHeaderTitle;
    
    BOOL isDesignKey;
}
@property (nonatomic, strong) IBOutlet UITableView *tableView;

@property (nonatomic, assign) NSInteger resetAfterAlert;
@property (nonatomic, assign) NSInteger resetForAlert;
@property (nonatomic, assign) NSInteger resetForChild;
@property (nonatomic, strong) NSTimer *resetTimer;

@property (nonatomic, strong) NSMutableData *responseData;
@property (nonatomic, strong) NSURLConnection *connectionGetCategory;
@property (nonatomic, strong) NSURLConnection *connectionGetFlowEndUser;
@property (nonatomic, strong) NSURLConnection *connectionGetFlowEndUserList;
@property (nonatomic, strong) NSURLConnection *connectionSendNotification;

- (IBAction)onBtnHomeClicked:(UIButton *)sender;
- (IBAction)onBtnBackClicked:(UIButton *)sender;
@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isFromRoot = [[NSUserDefaults standardUserDefaults] boolForKey:@"isFromRoot"];
    appDel.levelCount = [[NSUserDefaults standardUserDefaults] integerForKey:@"levelCount"];
    self.isTarget = [[NSUserDefaults standardUserDefaults] boolForKey:@"isTarget"];
    
    [CommonUtils clearBackButtonForNavigationBarAppearance];
    [CommonUtils setLightNavigationBarForAppearanceWithNavigationController:self.navigationController];
    self.navigationController.navigationBarHidden = YES;
    
    self.cv = [self createCollectionView];
    [self.view addSubview:self.cv];
    
    [self setLogOff];
   
    if (self.isFromRoot) {
        
        self.isFromRoot = [[NSUserDefaults standardUserDefaults] boolForKey:@"isFromRoot_INIT"];
        
        appDel.levelCount = [[NSUserDefaults standardUserDefaults] integerForKey:@"levelCount_INIT"];
        
        self.isTarget = [[NSUserDefaults standardUserDefaults] boolForKey:@"isTarget_INIT"];
        
    }
    else {
        ics = [[NSUserDefaults standardUserDefaults] valueForKey:@"ics_available"];
        strTimeAfter = [[NSUserDefaults standardUserDefaults] valueForKey:@"timeAfter"];
        strTimeBefore = [[NSUserDefaults standardUserDefaults] valueForKey:@"timeBefore"];
    }
    
    
    ics = [[NSUserDefaults standardUserDefaults] valueForKey:@"ics_available_INIT"];
    strTimeAfter = [[NSUserDefaults standardUserDefaults] valueForKey:@"timeAfter_INIT"];
    strTimeBefore = [[NSUserDefaults standardUserDefaults] valueForKey:@"timeBefore_INIT"];
    
    if ([ics length]!=0) {
        
        if (self.isFromRoot) {
        }
        else {
            self.eventView.hidden = YES;
        }
    }
    else {
        self.eventView.hidden = YES;
    }
}

- (UILabel *)buildMsgLabel {
    
    CGRect newRect ;//= CGRectMake(0, 143, 1024, 83);
    if ([aryEvents count]!=0) {
        newRect = CGRectMake(0, 143, 557, 83);
    }
    else {
        newRect = CGRectMake(0, 143, 1024, 83);
    }
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.textColor = [UIColor blackColor];
    lbl.text = @"";
    lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:27];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.numberOfLines = 2;
    lbl.lineBreakMode = NSLineBreakByTruncatingTail;
    return lbl;
    
}


- (void)checkInterNet {
    if ([CommonUtils connected]) {
        
        if([noInternetTimer isValid])
        {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
        }
        
         noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}

- (void) initData {
    name = @"";
    mobileNo = @"";
    email = @"";
    msg = @"";
}

- (UICollectionView *) createCollectionView {
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.itemSize = CGSizeMake(262, 145);
    
    flowLayout.minimumInteritemSpacing = 10;
    flowLayout.minimumLineSpacing = 10;
    
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(247, 234, 530, 518) collectionViewLayout:flowLayout];
    collectionView.backgroundColor = [UIColor clearColor];
    
    return collectionView;
}

- (void) setLogOff {
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(imgLongOffPressed:)];
    [longPress setMinimumPressDuration:4.0];
    self.imgLogOff.userInteractionEnabled = YES;
    [self.imgLogOff addGestureRecognizer:longPress];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.lblHeader.text = @"";
    
    NSString *resetAfterAlert = [[NSUserDefaults standardUserDefaults] valueForKey:@"resetAfterAlert_INIT"];
    NSString *resetForAlert = [[NSUserDefaults standardUserDefaults] valueForKey:@"resetForAlert_INIT"];
    NSString *resetForChild = [[NSUserDefaults standardUserDefaults] valueForKey:@"resetForChild_INIT"];
    
    self.resetAfterAlert = [resetAfterAlert integerValue]/1000.0;
    self.resetForAlert = [resetForAlert integerValue]/1000.0;
    self.resetForChild = [resetForChild integerValue]/1000.0;
    
    if ([noInternetTimer isValid]) {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    
    noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
    
    if (aryEvents != nil) {
        [aryEvents removeAllObjects];
        aryEvents = nil;
    }
    
    if ([ics length]!=0) {
        
        if (self.isFromRoot) {
            [self configOutlookCalendarEvents];
            
            if ([calTimer isValid]) {
                [calTimer invalidate];
                calTimer = nil;
            }
            calTimer = [NSTimer scheduledTimerWithTimeInterval:60 target:self selector:@selector(configOutlookCalendarEventsWithTimer) userInfo:nil repeats:YES];
        }
        else {
            self.eventView.hidden = YES;
        }
    }
    else {
        self.eventView.hidden = YES;
    }
    
    self.lblHeader = [self buildMsgLabel];
    [self.view addSubview:self.lblHeader];
    
    
    aryEvents = [[NSMutableArray alloc] init];
    
    [self callWebservice];
    
    NSString *root_design_key_INIT = [[NSUserDefaults standardUserDefaults] valueForKey:@"root_design_key_INIT"];
    if ([root_design_key_INIT length]==0) {
        isDesignKey = NO;
    }
    else {
        isDesignKey = YES;
    }
    
    [self displayInitialUI];
    
    
    [self setBackgroundColor];
    [self setBackgroundImage];
    
    
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
}

- (void) callWebservice {
    if (appDel.levelCount != 0) {
        if (self.isTarget) {
            if (self.isEndElement && self.isTargetElement) {
                webserviceMethodName = @"getFlowEndUser";
                [CommonUtils callWebservice:@selector(getFlowEndUser) forTarget:self];
            }
            else {
                if (self.isFromRoot) {
                    webserviceMethodName = @"getFlowEndUserList_ROOT";
                    [CommonUtils callWebservice:@selector(getFlowEndUserList_ROOT) forTarget:self];
                }
                else {
                    webserviceMethodName = @"getFlowEndUserList";
                    [CommonUtils callWebservice:@selector(getFlowEndUserList) forTarget:self];
                }
                
            }
            
        }
        else {
            webserviceMethodName = @"getFlowStructureListForChild";
            [CommonUtils callWebservice:@selector(getFlowStructureListForChild) forTarget:self];
        }
        
    }
    else {
        if (self.isTarget) {
            webserviceMethodName = @"getFlowEndUserList";
            [CommonUtils callWebservice:@selector(getFlowEndUserList) forTarget:self];
            
        }
        else {
            webserviceMethodName = @"getFlowStructureList";
            [CommonUtils callWebservice:@selector(getFlowStructureList) forTarget:self];
        }
    }
}

#pragma mark NO INTERNET CONNECTION VIEW
- (void)displayNoInternetConnection {
    NoInternetConnection *noInternetView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:NO];
    noInternetView.delegate = self;
    
}

- (void)dismissMessageNoInternetConnection:(NoInternetConnection *)noInternetConnection {
    [self callWebserviceAfterInternetConnectionAvailable];
    if (noInternetConnectionView!=nil){
        noInternetConnectionView = nil;
    }
}

- (void) callWebserviceAfterInternetConnectionAvailable {
    if ([webserviceMethodName isEqualToString:@"getFlowEndUser"]) {
        [CommonUtils callWebservice:@selector(getFlowEndUser) forTarget:self];
    }
    else if ([webserviceMethodName isEqualToString:@"getFlowEndUserList_ROOT"]) {
        [CommonUtils callWebservice:@selector(getFlowEndUserList_ROOT) forTarget:self];
    }
    else if ([webserviceMethodName isEqualToString:@"getFlowEndUserList"]) {
        [CommonUtils callWebservice:@selector(getFlowEndUserList) forTarget:self];
    }
    else if ([webserviceMethodName isEqualToString:@"getFlowStructureListForChild"]) {
        [CommonUtils callWebservice:@selector(getFlowStructureListForChild) forTarget:self];
    }
    else if ([webserviceMethodName isEqualToString:@"getFlowStructureList"]) {
        [CommonUtils callWebservice:@selector(getFlowStructureList) forTarget:self];
    }
    else if ([webserviceMethodName isEqualToString:@"sendNotification"]) {
        [CommonUtils callWebservice:@selector(sendNotification) forTarget:self];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}






#pragma mark - Collection View
- (void)registerCell {
    [self.cv registerNib:[UINib nibWithNibName:@"GridCell" bundle:nil] forCellWithReuseIdentifier:@"GridCell"];
    self.cv.delegate = self;
    self.cv.dataSource = self;
    [self.cv reloadData];
}

#pragma mark Collection view Delegates
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (propDetail) {
        return [CommonUtils getArrayCountFromArray:propDetail.aryUserProperties];
    }
    else {
        return [CommonUtils getArrayCountFromArray:aryList];
    }
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *menuIdentifier = @"GridCell";
    GridCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:menuIdentifier forIndexPath:indexPath];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"GridCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.lblElementName.text = @"";//subFlow.subFlow_itemname;
    
    
    NSString *btnTitle = @"";
    NSInteger aryCount;
    SubFlow *subFlow = nil;
    if (propDetail) {
        UserProperty *up = [propDetail.aryUserProperties objectAtIndex:indexPath.item];
        btnTitle = [CommonUtils getNotNullString:up.up_name];
        aryCount = [propDetail.aryUserProperties count];
        
        [cell.btnElement setTitle:btnTitle forState:UIControlStateNormal];
        cell.btnElement.titleLabel.textAlignment = NSTextAlignmentCenter;
        cell.btnElement.titleLabel.numberOfLines = 0;
        cell.btnElement.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        
        [cell.btnElement setTitleEdgeInsets:UIEdgeInsetsMake(0.0f, 6.0f, 0.0, 6.0f)];//UIEdgeInsetsMake(0.0, 5.0, 0.0, 0.0)
        
        
        if (aryCount>=3) {
            [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"element3"] forState:UIControlStateNormal];
            [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"elementh3"] forState:UIControlStateHighlighted];
        }
        else if (aryCount==2) {
            [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"element2"] forState:UIControlStateNormal];
            [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"elementh2"] forState:UIControlStateHighlighted];
        }
        else {
            [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"element1"] forState:UIControlStateNormal];
            [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"elementh1"] forState:UIControlStateHighlighted];
        }
    }
    else {
        subFlow = [aryList objectAtIndex:indexPath.item];
        btnTitle = [CommonUtils getNotNullString:subFlow.subFlow_itemname];
        aryCount = [aryList count];
        
        if ([subFlow.subFlow_imageName length]!=0) {
            cell.viewGrid.hidden = NO;
            cell.imgBG.hidden = NO;
            cell.imgElement.hidden = NO;
            cell.lblElementName.hidden = NO;
            cell.lblElementName.text = btnTitle;
            [cell.btnElement setTitle:@"" forState:UIControlStateNormal];
            [cell.btnElement setBackgroundImage:nil forState:UIControlStateNormal];
            [cell.btnElement setBackgroundImage:nil forState:UIControlStateHighlighted];
            NSString *imgElementName = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[CommonUtils getNotNullString:subFlow.subFlow_imageName]];
            [cell.imgElement sd_setImageWithURL:[NSURL URLWithString:imgElementName] placeholderImage:nil];
            
            if (aryCount>=3) {
                cell.imgBG.image = [UIImage imageNamed:@"element3"];
            }
            else if (aryCount==2) {
                cell.imgBG.image = [UIImage imageNamed:@"element2"];
            }
            else {
                cell.imgBG.image = [UIImage imageNamed:@"element1"];
            }
        }
        else {
            
            cell.viewGrid.hidden = YES;
            cell.imgBG.hidden = YES;
            cell.imgElement.hidden = YES;
            cell.lblElementName.hidden = YES;
            
            [cell.btnElement setTitle:btnTitle forState:UIControlStateNormal];
            cell.btnElement.titleLabel.textAlignment = NSTextAlignmentCenter;
            cell.btnElement.titleLabel.numberOfLines = 0;
            cell.btnElement.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
            
            [cell.btnElement setTitleEdgeInsets:UIEdgeInsetsMake(0.0f, 6.0f, 0.0, 6.0f)];
            
            if (aryCount>=3) {
                [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"element3"] forState:UIControlStateNormal];
                [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"elementh3"] forState:UIControlStateHighlighted];
            }
            else if (aryCount==2) {
                [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"element2"] forState:UIControlStateNormal];
                [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"elementh2"] forState:UIControlStateHighlighted];
            }
            else {
                [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"element1"] forState:UIControlStateNormal];
                [cell.btnElement setBackgroundImage:[UIImage imageNamed:@"elementh1"] forState:UIControlStateHighlighted];
            }
        }
    }
    
    cell.btnElement.tag = indexPath.item;
    [cell.btnElement addTarget:self action:@selector(onClickBtnElement:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}

//Report your arrival ( standard )
//Show contact form
//show message
//
//Report your arrival to Victor
//By entering your name and mobile no
//Message From Victor

- (void)onClickBtnElement:(UIButton *)btnElement {
    
    //invalidate timer
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    
    if([calTimer isValid])
    {
        [calTimer invalidate];
        calTimer = nil;
    }
    
    if (self.isEndElement) {
        
        userProperty = nil;
        userProperty = [propDetail.aryUserProperties objectAtIndex:btnElement.tag];
        if ([userProperty.up_formAction isEqualToString:@"message"]) {
            NSString *headerTitle;
            if ([CommonUtils isEnglishLanguage]) {
                headerTitle = [NSString stringWithFormat:@"Message From %@.", userProperty.up_name];
            }
            else {
                headerTitle = [NSString stringWithFormat:@"Meddelse fra %@.", userProperty.up_name];
            }
            MessageForm *message = [[MessageForm alloc] initWithHeaderTitle:headerTitle withMessage:userProperty.up_message];
            message.delegate = self;
            [message setupSubViews];
        }
        else {
            if ([userProperty.up_formAction isEqualToString:@"default"]) {
                NSString *headerTitle;
                if ([CommonUtils isEnglishLanguage]) {
                    headerTitle = [NSString stringWithFormat:@"Report your arrival to %@\nby entering your name and mobile no.", userProperty.up_name];
                }
                else {
                    headerTitle = [NSString stringWithFormat:@"Meld din ankomst til %@\nved at angive dit navn og mobilnr.", userProperty.up_name];
                }
                StandardForm *standard = [[StandardForm alloc] initWithHeaderTitle:headerTitle];
                standard.delegate = self;
                isStandardType = YES;
                [standard setupSubViews];
            }
            else {
                NSString *headerTitle;
                if ([CommonUtils isEnglishLanguage]) {
                    headerTitle = [NSString stringWithFormat:@"Send a message to %@\nby completing the form below.", userProperty.up_name];
                }
                else {
                    headerTitle = [NSString stringWithFormat:@"Send en besked til %@\nved at udfylde nedenstående formular.", userProperty.up_name];
                }
                ContactForm *contact = [[ContactForm alloc] initWithHeaderTitle:headerTitle];
                contact.delegate = self;
                isStandardType = NO;
                [contact setupSubViews];
            }
        }
    }
    else {
        subFlow_ForChild = [aryList objectAtIndex:btnElement.tag];
        appDel.levelCount++;
        [[NSUserDefaults standardUserDefaults] setInteger:appDel.levelCount forKey:@"levelCount"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        HomeViewController *home = [[HomeViewController alloc]  initWithNibName:@"HomeViewController" bundle:nil];
        home.subFlow = subFlow_ForChild;
        
        if (subFlow_ForChild == nil && propDetail !=nil) {
            userProperty = nil;
            userProperty = [propDetail.aryUserProperties objectAtIndex:btnElement.tag];
            if ([userProperty.up_issub isEqualToString:@"no"]) {

                //start timer
                
                if ([userProperty.up_formAction isEqualToString:@"message"]) {
                    NSString *headerTitle;
                    if ([CommonUtils isEnglishLanguage]) {
                        headerTitle = [NSString stringWithFormat:@"Message From %@.", userProperty.up_name];
                    }
                    else {
                        headerTitle = [NSString stringWithFormat:@"Meddelse fra %@.", userProperty.up_name];
                    }
                    MessageForm *message = [[MessageForm alloc] initWithHeaderTitle:headerTitle withMessage:userProperty.up_message];
                    message.delegate = self;
                    [message setupSubViews];
                }
                else {
                    if ([userProperty.up_formAction isEqualToString:@"default"]) {
                        NSString *headerTitle;
                        if ([CommonUtils isEnglishLanguage]) {
                            headerTitle = [NSString stringWithFormat:@"Report your arrival to %@\nby entering your name and mobile no.", userProperty.up_name];
                        }
                        else {
                            headerTitle = [NSString stringWithFormat:@"Meld din ankomst til %@\nved at angive dit navn og mobilnr.", userProperty.up_name];
                        }
                        StandardForm *standard = [[StandardForm alloc] initWithHeaderTitle:headerTitle];
                        standard.delegate = self;
                        isStandardType = YES;
                        [standard setupSubViews];
                    }
                    else {
                        NSString *headerTitle;
                        if ([CommonUtils isEnglishLanguage]) {
                            headerTitle = [NSString stringWithFormat:@"Send a message to %@\nby completing the form below.", userProperty.up_name];
                        }
                        else {
                            headerTitle = [NSString stringWithFormat:@"Send en besked til %@\nved at udfylde nedenstående formular.", userProperty.up_name];
                        }
                        ContactForm *contact = [[ContactForm alloc] initWithHeaderTitle:headerTitle];
                        contact.delegate = self;
                        isStandardType = NO;
                        [contact setupSubViews];
                    }
                }
                return;
            }
            else {
                home.isTarget = YES;
                [[NSUserDefaults standardUserDefaults] setBool:home.isTarget forKey:@"isTarget"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                home.propertyDetail = propDetail;
                home.uProperty = userProperty;
                home.isTargetElement = YES;
                home.isEndElement = YES;
                home.rootButtonName = userProperty.up_name;
            }
            
        }
        else {
            
            if (home.subFlow.subFlow_targetPID.length !=0) {
                home.isTarget = YES;
                [[NSUserDefaults standardUserDefaults] setBool:home.isTarget forKey:@"isTarget"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                if (propDetail) {
                    home.propertyDetail = propDetail;
                    home.uProperty = userProperty;
                    home.isTargetElement = YES;
                    home.isEndElement = YES;
                    home.rootButtonName = userProperty.up_name;
                }
                else {
                    home.isTargetElement = NO;
                    home.rootButtonName = subFlow_ForChild.subFlow_itemname;
                }
            }
            else {
                
                home.isTarget = NO;
                home.rootButtonName = subFlow_ForChild.subFlow_itemname;
                [[NSUserDefaults standardUserDefaults] setBool:home.isTarget forKey:@"isTarget"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                if([subFlow_ForChild.subFlow_issub isEqualToString:@"no"])
                {
                    return;
                }
            }
        }
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isFromRoot"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.navigationController pushViewController:home animated:YES];
        NSLog(@"%ld",(long)btnElement.tag);
    }
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger aryCount;
    if ([aryEvents count]!=0) {
        if (propDetail) {

            aryCount = [propDetail.aryUserProperties count];
            return CGSizeMake(135, 75);
            
        }
        else {
            
            aryCount = [aryList count];
            
            if (aryCount>=3) {
                return CGSizeMake(180, 170);
            }
            else if (aryCount==2) {
                
                return CGSizeMake(180, 170);//return CGSizeMake(262, 262);
            }
            else {
                
                return CGSizeMake(180, 170);//return CGSizeMake(267, 267);
            }
        }
    }
    else {
        if (propDetail) {
            
            aryCount = [propDetail.aryUserProperties count];
            
            return CGSizeMake(125, 75);
            
        }
        else {
            
            aryCount = [aryList count];
            
            if (aryCount>=3) {
                return CGSizeMake(170, 170);
            }
            else if (aryCount==2) {
                
                return CGSizeMake(170, 170);//return CGSizeMake(262, 262);
            }
            else {
                
                return CGSizeMake(170, 170);//return CGSizeMake(267, 267);
            }
        }
    }
}


#pragma mark - Contact / Standard / Message Form Delegates

- (void)standardForm:(StandardForm *)standard sendNotification:(NSDictionary *)dict {
    name = [CommonUtils getNotNullString:[dict valueForKey:@"name"]];
    mobileNo = [CommonUtils getNotNullString:[dict valueForKey:@"mobile"]];
    webserviceMethodName = @"getFlowStructureList";
    [CommonUtils callWebservice:@selector(sendNotification) forTarget:self];
}

- (void)contactForm:(ContactForm *)contact sendNotification:(NSDictionary *)dict {
    name = [CommonUtils getNotNullString:[dict valueForKey:@"name"]];
    mobileNo = [CommonUtils getNotNullString:[dict valueForKey:@"mobile"]];
    email = [CommonUtils getNotNullString:[dict valueForKey:@"email"]];
    msg = [CommonUtils getNotNullString:[dict valueForKey:@"message"]];
    webserviceMethodName = @"getFlowStructureList";
    [CommonUtils callWebservice:@selector(sendNotification) forTarget:self];
}

- (void)contactDismissForm:(ContactForm *)contact {
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)standardDismissForm:(StandardForm *)standard {
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)messageDismissForm:(MessageForm *)message {
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)contactDismissFormOnTouchOutSide:(ContactForm *)contact {
    self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
}

- (void)standardDismissFormOnTouchOutSide:(StandardForm *)contact {
    self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
}

- (void)messageDismissFormOnTouchOutSide:(MessageForm *)contact {
    self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
}

- (void)messageDismissThankYouFormOnTouchOutSide:(ThankYouForm *)contact {
    self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
}

- (void)messageDismissThankYouContactFormOnTouchOutSide:(ThankYouContactForm *)contact {
    self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
}

#pragma mark - Webservice Requests
- (void) getFlowEndUser {
    
    NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
    
    
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_END_USER];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"targetPID=%@&customerPID=%@&userPID=%@&startflagPID=%@",self.propertyDetail.upd_pID,[[CommonUtils getLoginDetails] customerID],self.uProperty.up_pID,root_childPID_INIT];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionGetFlowEndUser = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionGetFlowEndUser )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}

- (void) getFlowEndUserList_ROOT {
    
    
    NSString * root_targetPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_targetPID_INIT"]];
    NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
    
    // NSString *root_targetPID = [[NSUserDefaults standardUserDefaults] valueForKey:@"root_targetPID"];
    
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_END_USER_LIST];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"targetPID=%@&customerPID=%@&startflagPID=%@",root_targetPID_INIT,[[CommonUtils getLoginDetails] customerID],root_childPID_INIT];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionGetFlowEndUserList = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionGetFlowEndUserList )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}

- (void) getFlowEndUserList {
    
    
    NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
    
    
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_END_USER_LIST];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"targetPID=%@&customerPID=%@&startflagPID=%@",self.subFlow.subFlow_targetPID,[[CommonUtils getLoginDetails] customerID],root_childPID_INIT];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionGetFlowEndUserList = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionGetFlowEndUserList )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}

- (void) getFlowStructureListForChild {
    
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_STRUCTURE_WITH_PARENT_ID];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    
    NSString *params = nil;
    
    if (self.isFromRoot) {
        NSString * root_flowPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_flowPID_INIT"]];
        NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
        
        params = [NSString stringWithFormat:@"flowPID=%@&childPID=%@&customerPID=%@&startflagPID=%@",root_flowPID_INIT,root_childPID_INIT,[[CommonUtils getLoginDetails] customerID],root_childPID_INIT];
    }
    else {
        NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
        params = [NSString stringWithFormat:@"flowPID=%@&childPID=%@&customerPID=%@&startflagPID=%@",self.subFlow.subFlow_flowPID,self.subFlow.subFlow_pID,[[CommonUtils getLoginDetails] customerID],root_childPID_INIT];
    }
    
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionGetCategory = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionGetCategory )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}

- (void)getFlowStructureList {
    
    NSString * root_flowPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_flowPID_INIT"]];
    NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
    
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,GET_FLOW_STRUCTURE_WITH_PARENT_ID];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"flowPID=%@&childPID=%@&customerPID=%@&startflagPID=%@",root_flowPID_INIT,root_childPID_INIT,[[CommonUtils getLoginDetails] customerID],root_childPID_INIT];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionGetCategory = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionGetCategory )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}

- (void) sendNotification {
    
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,SEND_NOTIFICATION];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"customerPID=%@&userPID=%@&userName=%@&userPhone=%@&userEmail=%@&userMessage=%@",[[CommonUtils getLoginDetails] customerID],userProperty.up_pID,name,mobileNo,email,msg];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionSendNotification = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionSendNotification )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}

#pragma mark Webservice Response
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [self.responseData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.responseData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connectionDidFinishLoading");
    
    NSString *stringResponse = [[NSString alloc]initWithData:self.responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Response : %@",stringResponse);
    
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
    
    NSError *jsonParsingError = nil;
    NSDictionary *tempDict = [NSJSONSerialization JSONObjectWithData:self.responseData options:0 error:&jsonParsingError];
    
    NSLog(@"Temp Dict = %@",tempDict);
    
    if (connection == self.connectionGetCategory) {
        if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
            
            if ([[tempDict valueForKey:@"PageTitle"] isKindOfClass:[NSArray class]]) {
                rootHeaderTitle = @"";
            }
            else {
                rootHeaderTitle = [CommonUtils getNotNullString:[tempDict valueForKey:@"PageTitle"]];
            }
            
            
            if ([[tempDict valueForKey:@"DesignKey"] isKindOfClass:[NSArray class]]) {
                isDesignKey = NO;
            }
            else {
                NSString *dKey = [CommonUtils getNotNullString:[tempDict valueForKey:@"DesignKey"]];
                if ([dKey length]!=0) {
                    isDesignKey = YES;
                    [[NSUserDefaults standardUserDefaults] setValue:dKey forKey:@"root_design_key_INIT"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
                else {
                    isDesignKey = NO;
                    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"root_design_key_INIT"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
            
            //start timer here
            if([self.resetTimer isValid])
            {
                [self.resetTimer invalidate];
                self.resetTimer = nil;
            }
            
            self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
            
            NSArray *aryFlowList = [tempDict valueForKey:@"Result"];
            
            if ([aryList count]!=0) {
                [aryList removeAllObjects];
                
            }
            
            aryList = [self getArratListForFlow:aryFlowList];
            
            if ([[tempDict valueForKey:@"Design"] count]!=0) {
                NSDictionary *dictDesignProp = [[tempDict valueForKey:@"Design"] objectAtIndex:0];
                design = [[Design alloc] initWithDictionary:dictDesignProp];
                [self setCustomUI];
            }
            else {
                [self displayInitialUI];
            }
            
            [self registerCell];
            
        }
    }
    else if (connection == self.connectionGetFlowEndUserList) {
        if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
            
            if([self.resetTimer isValid])
            {
                [self.resetTimer invalidate];
                self.resetTimer = nil;
            }
            
            if ([[tempDict valueForKey:@"DesignKey"] isKindOfClass:[NSArray class]]) {
                isDesignKey = NO;
            }
            else {
                NSString *dKey = [CommonUtils getNotNullString:[tempDict valueForKey:@"DesignKey"]];
                if ([dKey length]!=0) {
                    isDesignKey = YES;
                    [[NSUserDefaults standardUserDefaults] setValue:dKey forKey:@"root_design_key_INIT"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
                else {
                    isDesignKey = NO;
                    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"root_design_key_INIT"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
            
            //start timer here
            self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
            
            propDetail = [[UserPropertyDetail alloc] initWithDictionary:[[tempDict valueForKey:@"Result"] objectAtIndex:0]];
            
            
            if ([[tempDict valueForKey:@"Design"] count]!=0) {
                NSDictionary *dictDesignProp = [[tempDict valueForKey:@"Design"] objectAtIndex:0];
                design = [[Design alloc] initWithDictionary:dictDesignProp];
                [self setCustomUI];
            }
            else {
                [self displayInitialUI];
            }
            
            [self registerCell];
            
        }
    }
    else if (connection == self.connectionGetFlowEndUser) {
        if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
            
            if([self.resetTimer isValid])
            {
                [self.resetTimer invalidate];
                self.resetTimer = nil;
            }
            
            if ([[tempDict valueForKey:@"DesignKey"] isKindOfClass:[NSArray class]]) {
                isDesignKey = NO;
            }
            else {
                NSString *dKey = [CommonUtils getNotNullString:[tempDict valueForKey:@"DesignKey"]];
                if ([dKey length]!=0) {
                    isDesignKey = YES;
                    [[NSUserDefaults standardUserDefaults] setValue:dKey forKey:@"root_design_key_INIT"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
                else {
                    isDesignKey = NO;
                    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"root_design_key_INIT"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
            
            //start timer here
            self.resetTimer = [NSTimer scheduledTimerWithTimeInterval:self.resetAfterAlert target:self selector:@selector(resetToHome) userInfo:nil repeats:YES];
            
            propDetail = [[UserPropertyDetail alloc] initWithDictionary:[[tempDict valueForKey:@"Result"] objectAtIndex:0]];
            
            
            if ([[tempDict valueForKey:@"Design"] count]!=0) {
                NSDictionary *dictDesignProp = [[tempDict valueForKey:@"Design"] objectAtIndex:0];
                design = [[Design alloc] initWithDictionary:dictDesignProp];
                [self setCustomUI];
            }
            else {
                [self displayInitialUI];
            }
            
            self.isEndElement = YES;
            
            [self registerCell];
        }
    }
    else if (connection == self.connectionSendNotification) {
        if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
            if (isStandardType) {
                NSString *headerTitle;
                if ([CommonUtils isEnglishLanguage]) {
                    headerTitle = [NSString stringWithFormat:@"Your arrival at %@ is reported.", userProperty.up_name];
                }
                else {
                    headerTitle = [NSString stringWithFormat:@"Din ankomst til %@ er anmeldt.", userProperty.up_name];//@"Din ankomst til Multiple Email & SMS er anmeldt.";//[NSString stringWithFormat:@"Din ankomst til %@ er anmeldt.", userProperty.up_name];
                }
                ThankYouForm *thankYouForm = [[ThankYouForm alloc] initWithHeaderTitle:headerTitle withMessage:@"Vent her ved Standeren"];
                thankYouForm.delegate = self;
                [thankYouForm setupSubViews];
            }
            else {
                NSString *headerTitle;
                NSString *msgTitle,*subMsg;
                if ([CommonUtils isEnglishLanguage]) {
                    headerTitle = @"Send message";
                    msgTitle = @"Your form has been sent!";
                    subMsg = @"Thanks for your visit";
                }
                else {
                    headerTitle = @"Din formular er afsendt!";//@"Send besked";
                    msgTitle = @"";//@"Din formular er afsendt!";
                    subMsg = @"Tak for dit besøg";
                }
                ThankYouContactForm *thankYouContactForm = [[ThankYouContactForm alloc] initWithHeaderTitle:headerTitle withMessage:msgTitle withSubMessage:subMsg];
                thankYouContactForm.delegate = self;
                [thankYouContactForm setupSubViews];
            }
        }
    }
}

-(void)messageDismissThankYouForm:(ThankYouForm *)thankYouForm {
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    appDel.levelCount = [[NSUserDefaults standardUserDefaults] integerForKey:@"levelCount"];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)messageDismissThankYouContactForm:(ThankYouContactForm *)thankYouContactForm {
    appDel.levelCount = [[NSUserDefaults standardUserDefaults] integerForKey:@"levelCount"];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - Parse Web service Response
- (NSMutableArray *)getArratListForFlow:(NSArray *)aryFlowList {
    NSMutableArray *aryFlows = [[NSMutableArray alloc] init];
    if ([aryFlows count]!=0) {
        [aryFlows removeAllObjects];
    }
    
    for (NSDictionary *dict in aryFlowList) {
        SubFlow *subFlow = [[SubFlow alloc] initWithDictionary:dict];
        [aryFlows addObject:subFlow];
    }
    
    return aryFlows;
}

- (void)setCustomUI {
    
    
    
    
    
    if ([design.aryFlowDesignProperty count]!=0) {
        
        BOOL isBGColor;
        
        if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_TYPE] dp_value] isEqualToString:@"color"]) {
            self.viewPlacement.hidden = YES;
            NSString *rgba = [[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_COLOR] dp_value];
            
            // Store Color is Set as Background
            isBGColor = YES;
            
            // Store RGB Color Code to NSUserDefaults
            NSString *colorNameToStoreLocally = @"BG_COLOR";
            
            [[NSUserDefaults standardUserDefaults] setValue:rgba forKey:colorNameToStoreLocally];
            [[NSUserDefaults standardUserDefaults] setValue:[NSNumber numberWithBool:isBGColor] forKey:@"isBGColor"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [self setBackgroundColor];
            
            /*
            CGFloat r,g,b,a;
            NSArray *aryRGBA;
            
            if ([rgba isEqualToString:colorNameFromLocal]) {
                aryRGBA = [colorNameFromLocal componentsSeparatedByString:@","];
            } else {
                aryRGBA = [rgba componentsSeparatedByString:@","];
            }
            
            if ([aryRGBA count]!=0) {
                r = [[aryRGBA objectAtIndex:0] floatValue];
                g = [[aryRGBA objectAtIndex:1] floatValue];
                b = [[aryRGBA objectAtIndex:2] floatValue];
                a = [[aryRGBA objectAtIndex:3] floatValue];
                NSLog(@"r=%f,g=%f,b=%f,a=%f",r,g,b,a);
                [self.view setBackgroundColor:[UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]];
                
                [[NSUserDefaults standardUserDefaults] setValue:rgba forKey:colorNameToStoreLocally];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            else {
                [self.view setBackgroundColor:[UIColor whiteColor]];
            }*/
            
            
            
        }
        else {
            // Store Image is Set as Background
            isBGColor = NO;
            NSString *backgroundView;
            self.viewPlacement.hidden = NO;
            if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"top left"]) {
                backgroundView = KEY_topleft;
                [self showTopLeftView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"top center"]) {
                backgroundView = KEY_topcenter;
                [self showTopMidView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"top right"]) {
                backgroundView = KEY_topright;
                [self showTopRightView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"center left"]) {
                backgroundView = KEY_centerleft;
                [self showMidLeftView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"center center"]) {
                backgroundView = KEY_centercenter;
                   [self showMidCenterView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"center right"]) {
                backgroundView = KEY_centerright;
                [self showMidRightView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"bottom left"]) {
                backgroundView = KEY_bottomleft;
                [self showBottomLeftView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"bottom center"]) {
                backgroundView = KEY_bottomcenter;
                [self showBottomCenterView];
            }
            else if ([[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE_PLACEMENT] dp_value] isEqualToString:@"bottom right"]) {
                backgroundView = KEY_bottomright;
                [self showBottomRightView];
            }
            else {
                backgroundView = @"";
                //[self hidePlecementView];
            }
            [self.view setBackgroundColor:[UIColor whiteColor]];
            [[NSUserDefaults standardUserDefaults] setValue:[NSNumber numberWithBool:isBGColor] forKey:@"isBGColor"];
            [[NSUserDefaults standardUserDefaults] setValue:backgroundView forKey:@"BGView"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        [self displayInitialUI];
    }
}

- (UIImage *)getLocalImage:(NSString *)imageName webImageName:(NSString *)imageWebName andWebImageURL:(NSString *)imageWebURL {
    
    // Method to save image from web, meanswhile display placeholder image, and check every time a new image in available or not.
    // If new image is available than download and display.
    
    UIImage *returnImage = nil;
    
    BOOL isImageExist = NO; // To Check if image exist locally (By Default Not Exist)
    
    // Local Path of Saved Image
    NSString *imageNameToStoreLocally = imageName;
    NSString *imageNameFromLocal = [[NSUserDefaults standardUserDefaults] valueForKey:imageNameToStoreLocally];
    NSString *filepath = [CommonUtils getDocumentDirectoryPathForFileName:imageNameToStoreLocally];
    
    NSURL *imageURL = [NSURL URLWithString:imageWebURL];

    if ([imageWebName length]!=0) {
        
        // Check if Image Exist on Local Side
        if ([CommonUtils fileExistAtPath:filepath] && [imageNameFromLocal isEqualToString:imageWebName]) {
            // Image Exist on Local
            
            isImageExist = YES;
        } else {
            // Image Doest Not Exist on Local Side.
            
            isImageExist = NO;
            
            // Save Image Name to NSUserDefaults
            [[NSUserDefaults standardUserDefaults] setValue:imageWebName forKey:imageNameToStoreLocally];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            if ([CommonUtils fileExistAtPath:filepath]) {
                // Remove Existing File
                [CommonUtils removeFileFromDocumentDir:imageNameToStoreLocally];
            }
            
            // Save Image to Local Directory with extension.
            NSData *imgData = [NSData dataWithContentsOfURL:imageURL];
            [CommonUtils downloadData:imgData atPath:filepath];
            NSLog(@"Image Path : %@", filepath);
            
            if ([CommonUtils fileExistAtPath:filepath]) {
                isImageExist = YES;
            }
            else {
                isImageExist = NO;
            }
        }
        
        if (isImageExist) {
            if ([CommonUtils fileExistAtPath:filepath]) {
                returnImage = [UIImage imageWithData:[NSData dataWithContentsOfFile:filepath]];
            } else {
                returnImage = [UIImage imageNamed:imageName];
            }
        }
        else {
            returnImage = [UIImage imageNamed:imageName];
        }
    } else {
        if ([CommonUtils fileExistAtPath:filepath]) {
            returnImage = [UIImage imageWithData:[NSData dataWithContentsOfFile:filepath]];
        } else {
            returnImage = [UIImage imageNamed:imageName];
        }
        //returnImage = [UIImage imageNamed:imageName];
    }
    
    return returnImage;
}

- (void) clearLocalImageData:(NSString *)imageName {
    
    // Clear Image Name to NSUserDefaults
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:imageName];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    // Delete Image From Local
    [CommonUtils removeFileFromDocumentDir:imageName];
}

- (void) displayInitialUI {
    
    NSString *topImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_TOP_IMAGE] dp_ImageName]];
    NSString *topImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,topImage];
    NSString *topImageKey = @"top-image";
    if (isDesignKey) {
        self.imgBar.image = [self getLocalImage:topImageKey webImageName:topImage andWebImageURL:topImageURL];
        
    }
    else {
        self.imgBar.image = [UIImage imageNamed:@"top-image"];
    }
    
    
    [self.imgBar setContentMode:UIViewContentModeScaleAspectFit];
    self.imgBar.clipsToBounds = YES;
    self.imgBar.layer.allowsEdgeAntialiasing = YES;
    
    NSString *homeButtonImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_HOME_BUTTON] dp_ImageName]];
    NSString *homeButtonImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,homeButtonImage];
    NSString *homeImageKey  = @"home";
    
    
    if (isDesignKey) {
        
        UIImage *imgBtnHome = [self getLocalImage:homeImageKey webImageName:homeButtonImage andWebImageURL:homeButtonImageURL];
        [self.btnHome setBackgroundImage:imgBtnHome forState:UIControlStateNormal];
    }
    else {
        [self.btnHome setBackgroundImage:[UIImage imageNamed:@"home"] forState:UIControlStateNormal];
    }
    
    
    
    NSString *tempHeadline =  [[NSUserDefaults standardUserDefaults] valueForKey:@"root_headline"];
    NSString *headline = [[CommonUtils getNotNullString:tempHeadline] stringByReplacingOccurrencesOfString:@"{bruger}" withString:[CommonUtils getNotNullString:self.rootButtonName]];
    
    [self.btnBack setBackgroundImage:[UIImage imageNamed:@"backn"] forState:UIControlStateNormal];
    [self.btnBack setBackgroundImage:[UIImage imageNamed:@"backh"] forState:UIControlStateHighlighted];
    
    self.btnBack.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.btnBack.layer.borderWidth = 0.8f;
    
    self.btnBack.layer.cornerRadius = 5.0f;
    self.btnBack.layer.masksToBounds = YES;
    
    
    if (appDel.levelCount != 0) {
        if (propDetail) {
            NSString *tempPropHeadline = [CommonUtils getNotNullString:propDetail.upd_page_headline];
            NSString *propHeadline = [[CommonUtils getNotNullString:tempPropHeadline] stringByReplacingOccurrencesOfString:@"{bruger}" withString:[CommonUtils getNotNullString:self.rootButtonName]];
            self.lblHeader.text = propHeadline;
        }
        else {
            NSString *tempSubFlowHeadline = [CommonUtils getNotNullString:self.subFlow.subFlow_page_headline];
            NSString *subFlowHeadline = [[CommonUtils getNotNullString:tempSubFlowHeadline] stringByReplacingOccurrencesOfString:@"{bruger}" withString:[CommonUtils getNotNullString:self.rootButtonName]];
            self.lblHeader.text = subFlowHeadline;
        }
    }
    else {
        
        
        self.lblHeader.text = headline;
        self.btnHome.hidden = YES;
        self.btnBack.hidden = YES;
    }
    
    if (self.isFromRoot) {
        self.btnHome.hidden = YES;
        self.btnBack.hidden = YES;
        NSLog(@"BEFORE = %@",self.lblHeader);
        if (propDetail) {
            self.lblHeader.text = [CommonUtils getNotNullString:propDetail.upd_page_headline];
            
            NSInteger aryCount;
            
            aryCount = [propDetail.aryUserProperties count];
            
            
            if ([aryEvents count]!=0) {
                self.lblHeader.frame = CGRectMake(0, 143, 557, 83);
                    self.eventView.hidden = NO;
                
                if (aryCount>=3) {
                    self.cv.frame = CGRectMake(8, 234, 570, 518);//CGRectMake(8, 213, 570, 539);
                }
                else if (aryCount==2) {
                    self.cv.frame = CGRectMake(160,234,280,518);//CGRectMake(160,213,280,539);
                }
                else {
                    self.cv.frame = CGRectMake(160, 234, 279, 518);//CGRectMake(160, 213, 279, 539);
                }
                
                        //                    if (aryCount>=3) {
                        //                        self.cv.frame = CGRectMake(139, 213, 531, 539);
                        //                    }
                        //                    else if (aryCount==2) {
                        //                        self.cv.frame = CGRectMake(382, 213, 260, 539);
                        //                    }
                        //                    else {
                        //                        self.cv.frame = CGRectMake(382, 213, 259, 539);
                        //                    }
            }
            else {
                self.lblHeader.frame = CGRectMake(0, 143, 1024, 83);
                self.eventView.hidden = YES;
                if (aryCount>=5) {
                    self.cv.frame = CGRectMake(179, 234, 666, 518);
                }
                else if (aryCount==4) {
                    self.cv.frame = CGRectMake(247, 234, 530, 518);
                }
                else if (aryCount==3) {
                    self.cv.frame = CGRectMake(314, 234, 396, 518);//CGRectMake(245, 234, 534, 518);
                }
                else if (aryCount==2) {
                    self.cv.frame = CGRectMake(382, 234, 260, 518);
                }
                else {
                    self.cv.frame = CGRectMake(382, 213, 259, 539);
                }
            }
            
            /*if ([ics length]!=0) {
                
                

               
            }
            else {
                if (aryCount>=5) {
                    self.cv.frame = CGRectMake(179, 213, 666, 539);
                }
                else if (aryCount==4) {
                    self.cv.frame = CGRectMake(247, 213, 530, 539);
                }
                else if (aryCount==3) {
                    self.cv.frame = CGRectMake(245, 213, 534, 539);
                }
                else if (aryCount==2) {
                    self.cv.frame = CGRectMake(382, 213, 260, 539);
                }
                else {
                    self.cv.frame = CGRectMake(382, 213, 259, 539);
                }
            }*/
        }
        else {
            NSString * root_headline_INIT = @"";
            if ([rootHeaderTitle length]!=0) {
                 root_headline_INIT = [CommonUtils getNotNullString:rootHeaderTitle];
                NSArray *ary = [root_headline_INIT componentsSeparatedByString:@"*br*"];
                
                
                if ([ary count]>1) {
                    rootHeaderTitle = [NSString stringWithFormat:@"%@\n%@",[ary objectAtIndex:0],[ary objectAtIndex:1]];
                    root_headline_INIT = rootHeaderTitle;
                }
                else {
                    root_headline_INIT = rootHeaderTitle;//[NSString stringWithFormat:@""];
                }

            }
            else {
                root_headline_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_headline_INIT"]];
                NSArray *ary = [root_headline_INIT componentsSeparatedByString:@"*br*"];
                
                
                if ([ary count]>1) {
                    rootHeaderTitle = [NSString stringWithFormat:@"%@\n%@",[ary objectAtIndex:0],[ary objectAtIndex:1]];
                    root_headline_INIT = rootHeaderTitle;
                }
                else {
                    root_headline_INIT = rootHeaderTitle;//[NSString stringWithFormat:@""];
                }

            }
            //
            

            self.lblHeader.text = root_headline_INIT;//[CommonUtils getNotNullString:self.subFlow.subFlow_page_headline];
            
            NSInteger aryCount;
            
            aryCount = [aryList count];
            
            if ([aryEvents count]!=0) {
                self.lblHeader.frame = CGRectMake(0, 143, 557, 83);
                self.eventView.hidden = NO;
                if (aryCount>=3) {
                    self.cv.frame = CGRectMake(8, 234, 570, 518);
                }
                else if (aryCount==2) {
                    self.cv.frame = CGRectMake(114, 234, 373, 518);
                }
                else {
                    self.cv.frame = CGRectMake(116, 234, 368, 518);
                }
            }
            else {
                self.lblHeader.frame = CGRectMake(0, 143, 1024, 83);
                self.eventView.hidden = YES;
                if (aryCount>=3) {
                    self.cv.frame = CGRectMake(247, 234, 530, 518);
                }
                else if (aryCount==2) {
                    self.cv.frame = CGRectMake(337, 234, 350, 518);
                }
                else {
                    self.cv.frame = CGRectMake(337, 234, 349, 518);
                }
            }
            
            /*if ([ics length]!=0) {
                if (allEvents != nil && allEvents ) {
                    self.eventView.hidden = NO;
                    if (aryCount>=3) {
                        self.cv.frame = CGRectMake(139, 213, 531, 539);
                    }
                    else if (aryCount==2) {
                        self.cv.frame = CGRectMake(337, 213, 350, 539);
                    }
                    else {
                        self.cv.frame = CGRectMake(337, 213, 349, 539);
                    }
                }
                else {
                    self.eventView.hidden = YES;
                    if (aryCount>=3) {
                        self.cv.frame = CGRectMake(247, 213, 530, 539);
                    }
                    else if (aryCount==2) {
                        self.cv.frame = CGRectMake(337, 213, 350, 539);
                    }
                    else {
                        self.cv.frame = CGRectMake(337, 213, 349, 539);
                    }
                }
            }
            else {
                if (aryCount>=3) {
                    self.cv.frame = CGRectMake(247, 213, 530, 539);
                }
                else if (aryCount==2) {
                    self.cv.frame = CGRectMake(337, 213, 350, 539);
                }
                else {
                    self.cv.frame = CGRectMake(337, 213, 349, 539);
                }
            }*/
        }
        NSLog(@"After = %@",self.lblHeader);
    }
    else {
        self.btnHome.hidden = NO;
        self.btnBack.hidden = NO;
        [self.btnBack setImage:[UIImage imageNamed:@"dark_back_arrow_right"] forState:UIControlStateNormal];
        
        if (propDetail) {
            
            NSString *tempPropHeadline = [CommonUtils getNotNullString:propDetail.upd_page_headline];
            NSString *propHeadline = [[CommonUtils getNotNullString:tempPropHeadline] stringByReplacingOccurrencesOfString:@"{bruger}" withString:[CommonUtils getNotNullString:self.rootButtonName]];
            self.lblHeader.text = propHeadline;
            
            NSInteger aryCount;
            
            aryCount = [propDetail.aryUserProperties count];
            
            if (aryCount>=5) {
                self.cv.frame = CGRectMake(179, 234, 666, 518);
            }
            else if (aryCount==4) {
                self.cv.frame = CGRectMake(247, 234, 530, 518);
            }
            else if (aryCount==3) {
                self.cv.frame = CGRectMake(314, 234, 396, 518);//CGRectMake(245, 234, 534, 518);
            }
            else if (aryCount==2) {
                self.cv.frame = CGRectMake(382, 234, 260, 518);
            }
            else {
                self.cv.frame = CGRectMake(382, 234, 259, 518);
            }
        }
        else {
            NSString *tempSubFlowHeadline = [CommonUtils getNotNullString:self.subFlow.subFlow_page_headline];
            NSString *subFlowHeadline = [[CommonUtils getNotNullString:tempSubFlowHeadline] stringByReplacingOccurrencesOfString:@"{bruger}" withString:[CommonUtils getNotNullString:self.rootButtonName]];
            self.lblHeader.text = subFlowHeadline;
            
            NSInteger aryCount;
            
            aryCount = [aryList count];
            
            if (aryCount>=3) {
                self.cv.frame = CGRectMake(247, 234, 530, 518);
            }
            else if (aryCount==2) {
                self.cv.frame = CGRectMake(337, 234, 350, 518);
            }
            else {
                self.cv.frame = CGRectMake(337, 234, 349, 518);
            }
        }
    }
   
}



#pragma mark - MANAGE PLACEMENT VIEWS

- (void) hidePlecementView {
    [self.view setHidden:YES];
}

- (void) showPlacementView {
    [self.view setHidden:NO];
}

- (void) showTopLeftView {
    self.viewTopLeft.hidden = NO;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = NO;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgTopLeft.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgTopLeft setContentMode:UIViewContentModeScaleAspectFit];
    self.imgTopLeft.clipsToBounds = YES;
    self.imgTopLeft.layer.allowsEdgeAntialiasing = YES;

    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgTopLeft sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showTopMidView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = NO;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = NO;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgTopCenter.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgTopCenter setContentMode:UIViewContentModeScaleAspectFit];
    self.imgTopCenter.clipsToBounds = YES;
    self.imgTopCenter.layer.allowsEdgeAntialiasing = YES;
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgTopCenter sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showTopRightView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = NO;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = NO;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgTopRight.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgTopRight setContentMode:UIViewContentModeScaleAspectFit];
    self.imgTopRight.clipsToBounds = YES;
    self.imgTopRight.layer.allowsEdgeAntialiasing = YES;
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgTopRight sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showMidLeftView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = NO;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = NO;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgMidLeft.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgMidLeft setContentMode:UIViewContentModeScaleAspectFit];
    self.imgMidLeft.clipsToBounds = YES;
    self.imgMidLeft.layer.allowsEdgeAntialiasing = YES;
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgMidLeft sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showMidCenterView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = NO;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = NO;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgMidCenter.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgMidCenter setContentMode:UIViewContentModeScaleAspectFit];
    self.imgMidCenter.clipsToBounds = YES;
    self.imgMidCenter.layer.allowsEdgeAntialiasing = YES;
    
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgMidCenter sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showMidRightView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = NO;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = NO;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgMidRight.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgMidRight setContentMode:UIViewContentModeScaleAspectFit];
    self.imgMidRight.clipsToBounds = YES;
    self.imgMidRight.layer.allowsEdgeAntialiasing = YES;
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgMidRight sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showBottomLeftView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = NO;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = NO;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgBottomLeft.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgBottomLeft setContentMode:UIViewContentModeScaleAspectFit];
    self.imgBottomLeft.clipsToBounds = YES;
    self.imgBottomLeft.layer.allowsEdgeAntialiasing = YES;
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgBottomLeft sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showBottomCenterView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = NO;
    self.viewBottomRight.hidden = YES;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = NO;
    self.imgBottomRight.hidden = YES;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgBottomCenter.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgBottomCenter setContentMode:UIViewContentModeScaleAspectFit];
    self.imgBottomCenter.clipsToBounds = YES;
    self.imgBottomCenter.layer.allowsEdgeAntialiasing = YES;
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgBottomCenter sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

- (void) showBottomRightView {
    self.viewTopLeft.hidden = YES;
    self.viewTopCenter.hidden = YES;
    self.viewTopRight.hidden = YES;
    
    self.viewMidLeft.hidden = YES;
    self.viewMidCenter.hidden = YES;
    self.viewMidRight.hidden = YES;
    
    self.viewBottomLeft.hidden = YES;
    self.viewBottomCenter.hidden = YES;
    self.viewBottomRight.hidden = NO;
    
    self.imgTopLeft.hidden = YES;
    self.imgTopCenter.hidden = YES;
    self.imgTopRight.hidden = YES;
    
    self.imgMidLeft.hidden = YES;
    self.imgMidCenter.hidden = YES;
    self.imgMidRight.hidden = YES;
    
    self.imgBottomLeft.hidden = YES;
    self.imgBottomCenter.hidden = YES;
    self.imgBottomRight.hidden = NO;
    
    NSString *bgImage = [CommonUtils getNotNullString:[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    NSString *bgImageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,bgImage];
    NSString *bgImageKey = @"bg-image";
    self.imgBottomRight.image = [self getLocalImage:bgImageKey webImageName:bgImage andWebImageURL:bgImageURL];
    
    [self.imgBottomRight setContentMode:UIViewContentModeScaleAspectFit];
    self.imgBottomRight.clipsToBounds = YES;
    self.imgBottomRight.layer.allowsEdgeAntialiasing = YES;
    
    /*
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",BG_IMAGE_URL,[[design.aryFlowDesignProperty objectAtIndex:DP_TAG_BG_IMAGE] dp_ImageName]];
    [self.imgBottomRight sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@""]];
    */
}

#pragma mark - SET BACKGROUND COLOR
- (void) setBackgroundColor {
    BOOL isBGColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isBGColor"] boolValue];
    if (isBGColor) {
        NSString *colorNameToStoreLocally = @"BG_COLOR";
        NSString *colorNameFromLocal = [[NSUserDefaults standardUserDefaults] valueForKey:colorNameToStoreLocally];
        
        CGFloat r,g,b,a;
        NSArray *aryRGBA = [colorNameFromLocal componentsSeparatedByString:@","];
        
        if ([aryRGBA count]!=0) {
            r = [[aryRGBA objectAtIndex:0] floatValue];
            g = [[aryRGBA objectAtIndex:1] floatValue];
            b = [[aryRGBA objectAtIndex:2] floatValue];
            a = [[aryRGBA objectAtIndex:3] floatValue];
            NSLog(@"r=%f,g=%f,b=%f,a=%f",r,g,b,a);
            
            if (isDesignKey) {
                [self.view setBackgroundColor:[UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]];
            }
            else {
                self.view.backgroundColor = [UIColor whiteColor];
            }
        }
        else {
            [self.view setBackgroundColor:[UIColor whiteColor]];
        }
    } else {
        [self.view setBackgroundColor:[UIColor whiteColor]];
    }
}

#pragma mark - SET BACKGROUND IMAGE
- (void) setBackgroundImage {
    BOOL isBGColor = [[[NSUserDefaults standardUserDefaults] valueForKey:@"isBGColor"] boolValue];
    if (!isBGColor) {
        
        NSString *backgroundView = [[NSUserDefaults standardUserDefaults] valueForKey:@"BGView"];
        if ([ backgroundView isEqualToString:KEY_topleft]) {
            [self showTopLeftView];
        }
        else if ([ backgroundView isEqualToString:KEY_topcenter]) {
            [self showTopMidView];
        }
        else if ([ backgroundView isEqualToString:KEY_topright]) {
            [self showTopRightView];
        }
        else if ([ backgroundView isEqualToString:KEY_centerleft]) {
            [self showMidLeftView];
        }
        else if ([ backgroundView isEqualToString:KEY_centercenter]) {
            [self showMidCenterView];
        }
        else if ([ backgroundView isEqualToString:KEY_centerright]) {
            [self showMidRightView];
        }
        else if ([ backgroundView isEqualToString:KEY_bottomleft]) {
            [self showBottomLeftView];
        }
        else if ([ backgroundView isEqualToString:KEY_bottomcenter]) {
            [self showBottomCenterView];
        }
        else if ([ backgroundView isEqualToString:KEY_bottomright]) {
            [self showBottomRightView];
        }
        else {
            //[self hidePlecementView];
        }
    }
}

#pragma mark - HOME BUTTONS
- (IBAction)onBtnHomeClicked:(UIButton *)sender {
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    appDel.levelCount = 0;
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)onBtnBackClicked:(id)sender {
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    appDel.levelCount--;
    
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if(appDel.levelCount == 0) {
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else {
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isFromRoot"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)imgLongOffPressed:(UILongPressGestureRecognizer *)sender {
    
    if (sender.state == UIGestureRecognizerStateBegan) {
        NSLog(@"LONG PRESS begun");
        NSLog(@"AFTER %f",[sender minimumPressDuration]);
        
        NSString *topImageKey = @"top-image";
        NSString *homeImageKey  = @"home";
        [self clearLocalImageData:topImageKey];
        [self clearLocalImageData:homeImageKey];
        
        [[NSUserDefaults standardUserDefaults] setPersistentDomain:[NSDictionary dictionary] forName:[[NSBundle mainBundle] bundleIdentifier]];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        if([noInternetTimer isValid]) {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
            
        }
        
        LoginViewController *login = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:login];
        appDel.window.rootViewController = nav;
        
        [UIView transitionWithView:appDel.window
                          duration:0.3
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:nil
                        completion:nil];
    }
    else if (sender.state == UIGestureRecognizerStateEnded) {
        
    }
    else if (sender.state == UIGestureRecognizerStateChanged) {
        
    }
}

-(void)resetToHome
{
    if([self.resetTimer isValid])
    {
        [self.resetTimer invalidate];
        self.resetTimer = nil;
    }
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
    }
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}



#pragma mark - TABLE VIEW 

#pragma mark - UITableViewDataSource

- (void)registerTableCell {
    
    [self.tableView registerNib:[UINib nibWithNibName:@"EventCell" bundle:nil] forCellReuseIdentifier:EventCellIdentifier];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [CommonUtils getArrayCountFromArray:aryEvents];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
            CGFloat cellHeight = [self heightForEventCellAtIndexPath:indexPath];
            return cellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
   
            return 75;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
            return [self EventCellAtIndexPath:indexPath];
    }


#pragma mark EventCell Cell Configuration
- (EventCell *)EventCellAtIndexPath:(NSIndexPath *)indexPath
{
    static EventCell *cell = nil;
    cell = [self.tableView dequeueReusableCellWithIdentifier:EventCellIdentifier];
    [self configureEventCell:cell atIndexPath:indexPath];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
- (void)configureEventCell:(EventCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
//    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:@"GGG®GGG"
//                                                                                         attributes:@{NSFontAttributeName: [UIFont fontWithName:@"HelveticaNeue-Bold" size:17]}];
//    [attributedString setAttributes:@{NSBaselineOffsetAttributeName : @10} range:NSMakeRange(3, 1)];
    
//    cell.lblTime.attributedText = attributedString;
    //cell.lblMessasge.text = self.message;
    
    

    
    //NSString *qlwUnitsPlainText = @"Hellom3";
    //cell.lblTime.attributedText = [self plainStringToAttributedUnits:qlwUnitsPlainText];
    
    
    cell.lblSub.text = [CommonUtils getNotNullString:[[aryEvents objectAtIndex:indexPath.row] eventSummary]];
    cell.lblLocation.text = [CommonUtils getNotNullString:[[aryEvents objectAtIndex:indexPath.row] eventLocation]];
    
    
    // To Convert Date To Server Time Zone
//    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
//    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:[[aryEvents objectAtIndex:indexPath.row] eventStartDate]];
    NSInteger hour = [components hour];
    NSInteger minute = [components minute];
    
    
    
    NSString *h = [NSString stringWithFormat:@"%ld",(long)hour];
    NSString *m = [NSString stringWithFormat:@"%ld",(long)minute];
    
    NSString *strHour,*strMinute;
    
    if ([h length]==1) {
        strHour = [NSString  stringWithFormat:@"0%@",h];
    }
    else {
        strHour = [NSString  stringWithFormat:@"%@",h];
    }
    
    if ([m length]==1) {
        strMinute = [NSString  stringWithFormat:@"0%@",m];
    }
    else {
        strMinute = [NSString  stringWithFormat:@"%@",m];
    }
    
    
    cell.lblTime.text = [NSString stringWithFormat:@"%@:%@",strHour,strMinute];
}

- (NSMutableAttributedString *)plainStringToAttributedUnits:(NSString *)string;
{
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:string];
    UIFont *font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:17];
    UIFont *smallFont = [UIFont fontWithName:@"HelveticaNeue-Bold" size:10];
    
    [attString beginEditing];
    [attString addAttribute:NSFontAttributeName value:(font) range:NSMakeRange(0, string.length - 2)];
    [attString addAttribute:NSFontAttributeName value:(smallFont) range:NSMakeRange(string.length - 1, 1)];
    [attString addAttribute:(NSString*)kCTSuperscriptAttributeName value:@1 range:NSMakeRange(string.length - 1, 1)];
    [attString addAttribute:(NSString*)kCTForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, string.length - 1)];
    [attString endEditing];
    return attString;
}

- (CGFloat)heightForEventCellAtIndexPath:(NSIndexPath *)indexPath
{
    static EventCell *sizingCell = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sizingCell = [self.tableView dequeueReusableCellWithIdentifier:EventCellIdentifier];
    });
    
    [self configureEventCell:sizingCell atIndexPath:indexPath];
    return [self calculateHeightForConfiguredSizingCell:sizingCell];
}
#pragma mark Calculate Height for Cell

- (CGFloat)calculateHeightForConfiguredSizingCell:(UITableViewCell *)sizingCell
{
    sizingCell.bounds = CGRectMake(0.0f, 0.0f, CGRectGetWidth(self.tableView.frame), CGRectGetHeight(sizingCell.bounds));
    [sizingCell setNeedsLayout];
    [sizingCell layoutIfNeeded];
    
    CGSize size = [sizingCell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
    return size.height + 1.0f; // Add 1.0f for the cell separator height
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}




#pragma mark - Calendar Events

- (void) configOutlookCalendarEventsWithTimer {
    if ([calTimer isValid]) {
        NSLog(@"CALENDER FOR TIMER COLLED");
    }
    
    if ([aryEvents count]!=0) {
        [aryEvents removeAllObjects];
    }

    
    MXLCalendarManager *calendarManager = [[MXLCalendarManager alloc] init];
    savedDates = [[NSMutableDictionary alloc]  init];
    
    // @"http://outlook.office365.com/owa/calendar/2b72e23ace2742e7bed4dfba4a4fd7d8@fifonetwork.com/ddf67f931a8c4cb0b597e358354525af2396092010071341869/calendar.ics"
    // @"https://outlook.office365.com/owa/calendar/cfc1668bbb6b4931b38f0ae4b3074ca6@9924942185.onmicrosoft.com/e951c291eeac467b8241a583844b31bc17401919216781863666/calendar.ics"
    //http://outlook.office365.com/owa/calendar/2b72e23ace2742e7bed4dfba4a4fd7d8@fifonetwork.com/ddf67f931a8c4cb0b597e358354525af2396092010071341869/calendar.ics
    // @"https://outlook.office365.com/owa/calendar/cfc1668bbb6b4931b38f0ae4b3074ca6@9924942185.onmicrosoft.com/e951c291eeac467b8241a583844b31bc17401919216781863666/calendar.ics"
    
    [calendarManager scanICSFileAtRemoteURL:[NSURL URLWithString:ics] withCompletionHandler:^(MXLCalendar *calendar, NSError *error) {
        currentCalendar = [[MXLCalendar alloc] init];
        currentCalendar = calendar;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self calendarDidLoadNextPage];
        });
    }];
    
    /* [calendarManager scanICSFileAtLocalPath:[[NSBundle mainBundle] pathForResource:@"basic" ofType:@"ics"]
     withCompletionHandler:^(MXLCalendar *calendar, NSError *error) {
     currentCalendar = [[MXLCalendar alloc] init];
     currentCalendar = calendar;
     
     dispatch_async(dispatch_get_main_queue(), ^{
     [self calendarDidLoadNextPage];
     });
     }];*/
}

- (void) configOutlookCalendarEvents {
    
    
    MXLCalendarManager *calendarManager = [[MXLCalendarManager alloc] init];
    savedDates = [[NSMutableDictionary alloc]  init];
    
    // @"http://outlook.office365.com/owa/calendar/2b72e23ace2742e7bed4dfba4a4fd7d8@fifonetwork.com/ddf67f931a8c4cb0b597e358354525af2396092010071341869/calendar.ics"
    // @"https://outlook.office365.com/owa/calendar/cfc1668bbb6b4931b38f0ae4b3074ca6@9924942185.onmicrosoft.com/e951c291eeac467b8241a583844b31bc17401919216781863666/calendar.ics"
    //http://outlook.office365.com/owa/calendar/2b72e23ace2742e7bed4dfba4a4fd7d8@fifonetwork.com/ddf67f931a8c4cb0b597e358354525af2396092010071341869/calendar.ics
    // @"https://outlook.office365.com/owa/calendar/cfc1668bbb6b4931b38f0ae4b3074ca6@9924942185.onmicrosoft.com/e951c291eeac467b8241a583844b31bc17401919216781863666/calendar.ics"
    [calendarManager scanICSFileAtRemoteURL:[NSURL URLWithString:ics] withCompletionHandler:^(MXLCalendar *calendar, NSError *error) {
        currentCalendar = [[MXLCalendar alloc] init];
        currentCalendar = calendar;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self calendarDidLoadNextPage];
        });
    }];
    
   /* [calendarManager scanICSFileAtLocalPath:[[NSBundle mainBundle] pathForResource:@"basic" ofType:@"ics"]
                      withCompletionHandler:^(MXLCalendar *calendar, NSError *error) {
                          currentCalendar = [[MXLCalendar alloc] init];
                          currentCalendar = calendar;
                          
                          dispatch_async(dispatch_get_main_queue(), ^{
                              [self calendarDidLoadNextPage];
                          });
                      }];*/
}


- (void)calendarDidLoadNextPage {
    [self loadEventsForDate:[NSDate date]];
}

- (void)loadEventsForDate:(NSDate *)currentDate {
    NSDateComponents *currentDateComponents = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth fromDate:currentDate];
    
    // If this month hasn't already loaded and been cached, start loading events
    if (![[savedDates objectForKey:[NSNumber numberWithInteger:currentDateComponents.year]] objectForKey:[NSNumber numberWithInteger:currentDateComponents.month]]) {
        
        // Show a loading HUD (https://github.com/jdg/MBProgressHUD)
        //        MBProgressHUD *loadingHUD = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        //        [loadingHUD setMode:MBProgressHUDModeIndeterminate];
        //        [loadingHUD setLabelText:@"Loading..."];
        
        // Check the month on a background thread
        dispatch_async( dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            NSMutableArray *daysArray = [[NSMutableArray alloc] init];
            
            // Create a formatter to provide the date
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyyddMM"];
            
            // For this initial check, all we need to know is whether there's at least ONE event on each day, nothing more.
            // So we loop through each event...
            for (MXLCalendarEvent *event in currentCalendar.events) {
                
                NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:[event eventStartDate]];
                
                // If the event starts this month, add it to the array
                if ([components month] == currentDateComponents.month && [components year] == currentDateComponents.year) {
                    [daysArray addObject:[NSNumber numberWithInteger:[components day]]];
                    [currentCalendar addEvent:event onDateString:[dateFormatter stringFromDate:[event eventStartDate]]];
                } else {
                    NSCalendar *cal = [NSCalendar currentCalendar];
                    NSRange rng = [cal rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:currentDate];
                    NSUInteger numberOfDaysInMonth = rng.length;
                    
                    // We loop through each day, check if there's an event already there
                    // and if there is, we move onto the next one and repeat until we find a day WITHOUT an event on.
                    // Then we check if this current event occurs then.
                    // This is a way of reducing the number of checkDate: runs we need to do. It also means the algorithm speeds up as it progresses
                    for (int i = 1; i <= numberOfDaysInMonth; i++) {
                        
                        if (![daysArray containsObject:[NSNumber numberWithInt:i]]) {
                            if ([event checkDay:i month:currentDateComponents.month year:currentDateComponents.year]) {
                                [daysArray addObject:[NSNumber numberWithInteger:i]];
                                [currentCalendar addEvent:event onDay:i month:currentDateComponents.month year:currentDateComponents.year];
                            }
                        }
                    }
                }
            }
            
            // Cache the events
            if (![savedDates objectForKey:[NSNumber numberWithInteger:currentDateComponents.year]]) {
                [savedDates setObject:[NSMutableDictionary dictionaryWithObject:@[] forKey:[NSNumber numberWithInteger:currentDateComponents.month]]
                               forKey:[NSNumber numberWithInteger:currentDateComponents.year]];
            }
            
            [[savedDates objectForKey:[NSNumber numberWithInteger:currentDateComponents.year]] setObject:daysArray forKey:[NSNumber numberWithInteger:currentDateComponents.month]];
            
            allEvents = [currentCalendar eventsForDate:[NSDate date]];
            
            for (MXLCalendarEvent *event in allEvents) {
                
             NSCalendar *calendar = [NSCalendar currentCalendar];
             NSDateComponents *components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:event.eventStartDate];
             NSInteger hour = [components hour];
             NSInteger minute = [components minute];
              
              NSString *strAfterTime = [NSString stringWithFormat:@"%ld:%02ld",(long)hour,(long)minute];
                NSLog(@"Start Time = %@",strAfterTime);
                
                
             NSDate *startTime = [CommonUtils getDateFormattedFromStringDate:strAfterTime withInputFormat:@"HH:mm" andOutputFormat:@"HH:mm:ss" isString:NO];
                
                BOOL isEventConsidered = [self shouldEventStartTime:startTime];
                
                if (isEventConsidered) {
                    [aryEvents addObject:event];
                }
            }
            
            // Refresh the UI on main thread
            dispatch_async( dispatch_get_main_queue(), ^{
                if ([aryEvents count]!=0) {
                    self.eventView.hidden = NO;
                    [self registerTableCell];
                }
                else {
                    self.eventView.hidden = YES;
                }
                [self displayInitialUI];
                
                if([calTimer isValid])
                {
                    [calTimer invalidate];
                    calTimer = nil;
                    
                }
                calTimer = [NSTimer scheduledTimerWithTimeInterval:60 target:self selector:@selector(configOutlookCalendarEventsWithTimer) userInfo:nil repeats:YES];
                //                [self.calendar reloadData];
                //                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            });
        });
    }
    
}

- (BOOL)shouldEventStartTime:(NSDate *)startTime {
    // Grab current time
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    
    NSDate *afterTimeDateSeconds = [startTime dateByAddingTimeInterval:[strTimeAfter integerValue]*60];
    NSDateComponents *components_Add = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitDay) fromDate:afterTimeDateSeconds];
    NSInteger hourAfter = [components_Add hour];
    NSInteger minuteAfter = [components_Add minute];

    NSString *strAfterTime = [NSString stringWithFormat:@"%ld:%02ld:00",(long)hourAfter,(long)minuteAfter];
    
    NSDate *afterTimeDate = [CommonUtils getDateFromString:strAfterTime withFormat:@"HH:mm:ss"];
    
    NSDate *beforeTimeDateSeconds = [startTime dateByAddingTimeInterval:-60*[strTimeBefore integerValue]];
    NSDateComponents *components_Minus = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:beforeTimeDateSeconds];
    NSInteger hourBefore = [components_Minus hour];
    NSInteger minuteBefore = [components_Minus minute];
    NSString *strBeforeTime = [NSString stringWithFormat:@"%ld:%02ld:00",(long)hourBefore,(long)minuteBefore];
    
    NSDate *beforeTimeDate = [CommonUtils getDateFromString:strBeforeTime withFormat:@"HH:mm:ss"];
    
    return [self checkWhetherTimeFallsBetweenBeforeTime:beforeTimeDate andAfterTime:afterTimeDate];
}

-(BOOL)checkWhetherTimeFallsBetweenBeforeTime:(NSDate *)beforeTime andAfterTime:(NSDate *)afterTime {
    NSDateComponents *openingTime = [[NSCalendar currentCalendar] components:NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond
                                                                    fromDate:beforeTime];
    
    NSDateComponents *closingTime = [[NSCalendar currentCalendar] components:NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond
                                                                    fromDate:afterTime];
    
    NSDate *now = [NSDate date];
    
    NSDateComponents *currentTime = [[NSCalendar currentCalendar] components:NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond
                                                                    fromDate:now];
    
    NSMutableArray *times = [@[openingTime, closingTime, currentTime] mutableCopy];
    [times sortUsingComparator:^NSComparisonResult(NSDateComponents *t1, NSDateComponents *t2) {
        if (t1.hour > t2.hour) {
            return NSOrderedDescending;
        }
        
        if (t1.hour < t2.hour) {
            return NSOrderedAscending;
        }
        // hour is the same
        if (t1.minute > t2.minute) {
            return NSOrderedDescending;
        }
        
        if (t1.minute < t2.minute) {
            return NSOrderedAscending;
        }
        // hour and minute are the same
        if (t1.second > t2.second) {
            return NSOrderedDescending;
        }
        
        if (t1.second < t2.second) {
            return NSOrderedAscending;
        }
        return NSOrderedSame;
        
    }];
    
    
    NSLog(@"Times = %@",times);
    if ([times indexOfObject:currentTime] == 1) {
        return YES;
    } else {
        return NO;
    }
}



//- (void)eventStartTime:(NSDate *)startTime {
//    
//   // NSDate *afterTimeDate = [calendar dateBySettingHour:0 minute:[strTimeAfter integerValue] second:0 ofDate:startTime options:0];
//     // Grab current time
//    
//    NSCalendar *calendar = [NSCalendar currentCalendar];
//
//    
//    NSDate *afterTimeDateSeconds = [startTime dateByAddingTimeInterval:[strTimeAfter integerValue]*60];
//    NSDateComponents *components_Add = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:afterTimeDateSeconds];
//    NSInteger hourAfter = [components_Add hour];
//    NSInteger minuteAfter = [components_Add minute];
//    NSString *strAfterTime = [NSString stringWithFormat:@"%ld:%02ld",(long)hourAfter,(long)minuteAfter];
//    
//    NSDate *afterTimeDate = [CommonUtils getDateFromString:strAfterTime withFormat:@"hh:mm"];
//
//    NSDate *beforeTimeDateSeconds = [startTime dateByAddingTimeInterval:-60*[strTimeBefore integerValue]];
//    NSDateComponents *components_Minus = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:beforeTimeDateSeconds];
//    NSInteger hourBefore = [components_Minus hour];
//    NSInteger minuteBefore = [components_Minus minute];
//    NSString *strBeforeTime = [NSString stringWithFormat:@"%ld:%02ld",(long)hourBefore,(long)minuteBefore];
//    
//    NSDate *beforeTimeDate = [CommonUtils getDateFromString:strBeforeTime withFormat:@"hh:mm"];
//    
//    
//    
//    
//    
//    [self checkWhetherTimeFallsBetweenBeforeTime:beforeTimeDate andAfterTime:afterTimeDate];
//   
//    
//    /*NSDateFormatter *df = [[NSDateFormatter alloc] init];
//    [df setDateFormat:@"HH:mm"];
//    NSDate *date1 = [df dateFromString:strAfterTime];//@"14:10"
//    NSDate *date2 = [df dateFromString:strBeforeTime];//@"18:09"
//    NSTimeInterval interval = [date2 timeIntervalSinceDate:date1];
//    int hours = (int)interval / 3600;             // integer division to get the hours part
//    int minutes = (interval - (hours*3600)) / 60; // interval minus hours part (in seconds) divided by 60 yields minutes
//    NSString *timeDiff = [NSString stringWithFormat:@"%d:%02d", hours, minutes];*/
//}
//
//-(void)checkWhetherTimeFallsBetweenBeforeTime:(NSDate *)beforeTime andAfterTime:(NSDate *)afterTime {
//    NSDateComponents *openingTime = [[NSCalendar currentCalendar] components:NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond
//                                                                    fromDate:beforeTime];
//    
//    NSDateComponents *closingTime = [[NSCalendar currentCalendar] components:NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond
//                                                                    fromDate:afterTime];
//    
//    NSDate *now = [NSDate date];
//    
//    NSDateComponents *currentTime = [[NSCalendar currentCalendar] components:NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond
//                                                                    fromDate:now];
//    
//    NSMutableArray *times = [@[openingTime, closingTime, currentTime] mutableCopy];
//    [times sortUsingComparator:^NSComparisonResult(NSDateComponents *t1, NSDateComponents *t2) {
//        if (t1.hour > t2.hour) {
//            return NSOrderedDescending;
//        }
//        
//        if (t1.hour < t2.hour) {
//            return NSOrderedAscending;
//        }
//        // hour is the same
//        if (t1.minute > t2.minute) {
//            return NSOrderedDescending;
//        }
//        
//        if (t1.minute < t2.minute) {
//            return NSOrderedAscending;
//        }
//        // hour and minute are the same
//        if (t1.second > t2.second) {
//            return NSOrderedDescending;
//        }
//        
//        if (t1.second < t2.second) {
//            return NSOrderedAscending;
//        }
//        return NSOrderedSame;
//        
//    }];
//    
//    if ([times indexOfObject:currentTime] == 1) {
//        NSLog(@"We are Open!");
//    } else {
//        NSLog(@"Sorry, we are closed!");
//    }
//}

/*
 - (void)loadEventsForDate:(NSDate *)currentDate {
 NSDateComponents *currentDateComponents = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:currentDate];
 
 // If this month hasn't already loaded and been cached, start loading events
 if (![[savedDates objectForKey:[NSNumber numberWithInteger:currentDateComponents.year]] objectForKey:[NSNumber numberWithInteger:currentDateComponents.month]]) {
 
 // Show a loading HUD (https://github.com/jdg/MBProgressHUD)
 MBProgressHUD *loadingHUD = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
 [loadingHUD setMode:MBProgressHUDModeIndeterminate];
 [loadingHUD setLabelText:@"Loading..."];
 
 // Check the month on a background thread
 dispatch_async( dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
 
 NSMutableArray *daysArray = [[NSMutableArray alloc] init];
 
 // Create a formatter to provide the date
 NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
 [dateFormatter setDateFormat:@"yyyyddMM"];
 
 // For this initial check, all we need to know is whether there's at least ONE event on each day, nothing more.
 // So we loop through each event...
 for (MXLCalendarEvent *event in currentCalendar.events) {
 
 NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:[event eventStartDate]];
 
 // If the event starts this month, add it to the array
 if ([components month] == currentDateComponents.month && [components year] == currentDateComponents.year) {
 [daysArray addObject:[NSNumber numberWithInteger:[components day]]];
 [currentCalendar addEvent:event onDateString:[dateFormatter stringFromDate:[event eventStartDate]]];
 } else {
 NSCalendar *cal = [NSCalendar currentCalendar];
 NSRange rng = [cal rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:currentDate];
 NSUInteger numberOfDaysInMonth = rng.length;
 
 // We loop through each day, check if there's an event already there
 // and if there is, we move onto the next one and repeat until we find a day WITHOUT an event on.
 // Then we check if this current event occurs then.
 // This is a way of reducing the number of checkDate: runs we need to do. It also means the algorithm speeds up as it progresses
 for (int i = 1; i <= numberOfDaysInMonth; i++) {
 
 if (![daysArray containsObject:[NSNumber numberWithInt:i]]) {
 if ([event checkDay:i month:currentDateComponents.month year:currentDateComponents.year]) {
 [daysArray addObject:[NSNumber numberWithInteger:i]];
 [currentCalendar addEvent:event onDay:i month:currentDateComponents.month year:currentDateComponents.year];
 }
 }
 }
 }
 }
 
 // Cache the events
 if (![savedDates objectForKey:[NSNumber numberWithInteger:currentDateComponents.year]]) {
 [savedDates setObject:[NSMutableDictionary dictionaryWithObject:@[] forKey:[NSNumber numberWithInteger:currentDateComponents.month]]
 forKey:[NSNumber numberWithInteger:currentDateComponents.year]];
 }
 
 [[savedDates objectForKey:[NSNumber numberWithInteger:currentDateComponents.year]] setObject:daysArray forKey:[NSNumber numberWithInteger:currentDateComponents.month]];
 
 // Refresh the UI on main thread
 dispatch_async( dispatch_get_main_queue(), ^{
 [self.calendar reloadData];
 [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
 });
 });
 }
 }
 
 
 */


@end
