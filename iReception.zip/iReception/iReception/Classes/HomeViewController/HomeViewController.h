//
//  HomeViewController.h
//  iReception
//
//  Created by spaculus on 7/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "VRGCalendarView.h"

@interface HomeViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *imgBG;
@property (strong, nonatomic) IBOutlet UIImageView *imgBar;
@property (strong, nonatomic) IBOutlet UIView *barView;
@property (strong, nonatomic) IBOutlet UIView *eventView;

@property (strong, nonatomic) IBOutlet UICollectionView *cv;

@property (strong, nonatomic) IBOutlet UIButton *btnBack;
@property (strong, nonatomic) IBOutlet UIButton *btnHome;

@property (strong, nonatomic) IBOutlet UILabel *lblHeader;
@property (strong, nonatomic) IBOutlet UIImageView *imgLogOff;


// Redirected References
//@property (nonatomic, assign) BOOL isChild; // Start When User at Root Controller
@property (nonatomic, readwrite) BOOL isTarget; // Whether Element has Sub Element Or Not
@property (nonatomic, readwrite) BOOL isTargetElement; // Whether Element has Flow End Element or not
@property (nonatomic, readwrite) BOOL isEndElement;
@property (nonatomic, readwrite) BOOL isFromRoot;
@property (strong, nonatomic) SubFlow *subFlow;
@property (strong, nonatomic) UserPropertyDetail *propertyDetail;
@property (strong, nonatomic) UserProperty *uProperty;

@property (strong, nonatomic) NSString * subflow_design_key;
@property (strong, nonatomic) NSString * rootButtonName;

//------Background Image Placement--------//
@property (strong, nonatomic) IBOutlet UIView *viewPlacement;

@property (strong, nonatomic) IBOutlet UIView *viewTopLeft;
@property (strong, nonatomic) IBOutlet UIImageView *imgTopLeft;
@property (strong, nonatomic) IBOutlet UIView *viewTopCenter;
@property (strong, nonatomic) IBOutlet UIImageView *imgTopCenter;
@property (strong, nonatomic) IBOutlet UIView *viewTopRight;
@property (strong, nonatomic) IBOutlet UIImageView *imgTopRight;

@property (strong, nonatomic) IBOutlet UIView *viewMidLeft;
@property (strong, nonatomic) IBOutlet UIImageView *imgMidLeft;
@property (strong, nonatomic) IBOutlet UIView *viewMidCenter;
@property (strong, nonatomic) IBOutlet UIImageView *imgMidCenter;
@property (strong, nonatomic) IBOutlet UIView *viewMidRight;
@property (strong, nonatomic) IBOutlet UIImageView *imgMidRight;

@property (strong, nonatomic) IBOutlet UIView *viewBottomLeft;
@property (strong, nonatomic) IBOutlet UIImageView *imgBottomLeft;
@property (strong, nonatomic) IBOutlet UIView *viewBottomCenter;
@property (strong, nonatomic) IBOutlet UIImageView *imgBottomCenter;
@property (strong, nonatomic) IBOutlet UIView *viewBottomRight;
@property (strong, nonatomic) IBOutlet UIImageView *imgBottomRight;

- (void)imgLongOffPressed:(UILongPressGestureRecognizer *)sender;
- (void)displayNoInternetConnection;
@end
