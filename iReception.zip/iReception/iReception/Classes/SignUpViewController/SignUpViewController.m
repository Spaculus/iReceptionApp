//
//  SignUpViewController.m
//  iReception
//
//  Created by spaculus on 8/19/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "SignUpViewController.h"
#import "HomeViewController.h"
#import "SignUpCell.h"
#import "NoInternetConnection.h"

#import "ThankYouFormForSignUpForm.h"

@interface SignUpViewController () <UITextFieldDelegate,UITableViewDataSource, UITableViewDelegate, NoInternetConnectionDelegate, ThankYouFormForSignUpFormDelegate> {
    NSMutableArray *aryList;
    NSInteger row;
    SubFlow *subFlow;
    NSString *webserviceMethodName;
    NoInternetConnection *noInternetConnectionView;
    
    NSTimer *noInternetTimer;
    
    NSString *companyname;
    NSString *contactname;
    NSString *address;
    NSString *zipcode;
    NSString *city;
    NSString *phone;
    NSString *email;
    NSInteger textFieldTag;
}

@property (strong, nonatomic) IBOutlet UILabel *lblFlowTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblFlowNameTitle;


@property (strong, nonatomic) IBOutlet UIButton *btnStartiReception;
@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingTableView *tblView;
@property (nonatomic, strong) NSMutableData *responseData;
@property (nonatomic, strong) NSURLConnection *connectionSignUp;


@property (strong, nonatomic) IBOutlet UIButton *btnBack;
- (IBAction)onButtonBackClicked:(id)sender;
@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    
    [self initData];
    webserviceMethodName = @"signUp";
    //[CommonUtils callWebservice:@selector(getFlowList) forTarget:self];
    
    
    // [self.tblView reloadData];
    // Do any additional setup after loading the view from its nib.
}

-(void)initData {
    row = -1;
    subFlow = nil;
    aryList = [[NSMutableArray alloc]  init];
    [self.btnStartiReception setEnabled:NO];
    
//    if ([CommonUtils isEnglishLanguage]) {
//        self.lblFlowTitle.text = @"Choose a starting point ?";
//        self.lblFlowNameTitle.text = @"Starting Point name";
//    }
//    else {
//        self.lblFlowTitle.text = @"Vælg et startpunkt ?";
//        self.lblFlowNameTitle.text = @"startpunkt navn";
//    }
    
    textFieldTag = 0;
    
    companyname = @"";
    contactname = @"";
    address = @"";
    zipcode = @"";
    city = @"";
    phone = @"";
    email = @"";
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    
    if([noInternetTimer isValid])
    {
        [noInternetTimer invalidate];
        noInternetTimer = nil;
        
    }
    
    noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
    
    // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayNoInternetConnection) name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
}



- (void)checkInterNet {
    if ([CommonUtils connected]) {
        
        if([noInternetTimer isValid])
        {
            [noInternetTimer invalidate];
            noInternetTimer = nil;
            
        }
        
        noInternetTimer = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(checkInterNet) userInfo:nil repeats:YES];
        
        
        if (noInternetConnectionView) {
            [noInternetConnectionView cancelButtonPressed:nil];
        }
    }
    else {
        if (noInternetConnectionView == nil) {
            noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
            noInternetConnectionView.delegate = self;
        }
    }
}/*{
  if ([CommonUtils connected]) {
  
  //        if([noInternetTimer isValid])
  //        {
  //            [noInternetTimer invalidate];
  //            noInternetTimer = nil;
  //        }
  
  if (noInternetConnectionView) {
  [noInternetConnectionView cancelButtonPressed:nil];
  }
  }
  else {
  if (noInternetConnectionView == nil) {
  noInternetConnectionView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:YES];
  noInternetConnectionView.delegate = self;
  }
  }
  }
  */

#pragma mark NO INTERNET CONNECTION VIEW
- (void)displayNoInternetConnection {
    NoInternetConnection *noInternetView = [[NoInternetConnection alloc] initInternetConnectionErrorViewFromView:NO];
    noInternetView.delegate = self;
    
}

- (void)dismissMessageNoInternetConnection:(NoInternetConnection *)noInternetConnection {
    [self callWebserviceAfterInternetConnectionAvailable];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:DISPLAY_NO_INTERNET_CONNECTION object:nil];
    if (noInternetConnectionView!=nil){
        noInternetConnectionView = nil;
    }
}

- (void) callWebserviceAfterInternetConnectionAvailable {
    if ([webserviceMethodName isEqualToString:@"signUp"]) {
        [CommonUtils callWebservice:@selector(signUp) forTarget:self];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableview Delegates


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *menuIdentifier = @"SignUpCell";
    SignUpCell *cell = (SignUpCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SignUpCell" owner:self options:nil];
        if([CommonUtils isiPad])
        {
            cell = [nib objectAtIndex:0];
        }
        else
        {
            cell = [nib objectAtIndex:0];
        }
    }
    
    
    cell.txtCompanyName.delegate = self;
    cell.txtContactName.delegate = self;
    cell.txtAddress.delegate = self;
    cell.txtZip.delegate = self;
    cell.txtCity.delegate = self;
    cell.txtPhone.delegate = self;
    cell.txtEmail.delegate = self;
    
    cell.txtCompanyName.text = companyname;
    cell.txtContactName.text = contactname;
    cell.txtAddress.text = address;
    cell.txtZip.text = zipcode;
    cell.txtCity.text = city;
    cell.txtPhone.text = phone;
    cell.txtEmail.text = email;
    
    cell.btnSignUp.layer.cornerRadius = 5.0f;
    cell.btnSignUp.clipsToBounds = YES;
    
    
    switch (textFieldTag) {
        case 10:
        {
            [cell.txtCompanyName becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            break;
            
        case 11:
        {
            [cell.txtContactName becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 12:
        {
            [cell.txtAddress becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 13:
        {
            [cell.txtZip becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 14:
        {
            [cell.txtCity becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 15:
        {
            [cell.txtPhone becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 16:
        {
            [cell.txtEmail becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
        }
            
            break;
            
        default:
        {
            [cell.txtCompanyName becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            break;
    }
    
    
    [cell.btnSignUp addTarget:self action:@selector(onClickSignUp) forControlEvents:UIControlEventTouchUpInside];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 508;
}

#pragma mark Estmated Height For Row
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 508;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}

- (void)onClickSignUp {
    [self.view endEditing:YES];
    if ([companyname length]==0) {
        textFieldTag = 10;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv firmanavn" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
        
    }
    else if ([contactname length]==0) {
        textFieldTag = 11;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv navn på kontaktpersonen" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
    }
    else if ([address length]==0) {
        textFieldTag = 12;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv din adresse" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
    }
    else if ([zipcode length]==0) {
        textFieldTag = 13;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv et korrekt post nr." andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
        
    }
    else if ([city length]==0) {
        textFieldTag = 14;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv et bynavn" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
    }
    else if ([phone length]==0) {
        textFieldTag = 15;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv et korrekt telefon nr." andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
    }
    else if ([email length] == 0)
    {
        textFieldTag = 16;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv en e-mail adresse." andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
    }
    else if (![CommonUtils IsValidEmail:email]) {
        textFieldTag = 16;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv en e-mail adresse." andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
    }
    else {
        [CommonUtils callWebservice:@selector(signUp) forTarget:self];
    }
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    [self.tblView reloadData];
}


#pragma mark - TextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    SignUpCell *cell = (SignUpCell *)[self.tblView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    switch (textField.tag) {
        case 10:
        {
            [cell.txtCompanyName becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            break;
            
        case 11:
        {
            [cell.txtContactName becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 12:
        {
            [cell.txtAddress becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 13:
        {
            [cell.txtZip becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 14:
        {
            [cell.txtCity becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 15:
        {
            [cell.txtPhone becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            
            break;
        case 16:
        {
            [cell.txtEmail becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
        }
            
            break;
            
        default:
        {
            [cell.txtCompanyName becomeFirstResponder];
            
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCompanyName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.8f
                                             withPadding:8
                                                andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtContactName
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtAddress
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtZip
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtCity
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtPhone
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
            
            [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                         forCornerRadius:5.0
                                          forBorderWidth:1.0f
                                             withPadding:8
                                                andColor:[[UIColor lightGrayColor] CGColor]];
        }
            break;
    }
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 13) {
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        zipcode = newString;
        if (zipcode.length>4) {
            return NO;
        }
        else {
            return YES;
        }
    }
    else if (textField.tag == 15) {
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        phone = newString;
        if (phone.length>8) {
            return NO;
        }
        else {
            return YES;
        }
    }
    else {
        return  YES;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    switch (textField.tag) {
        case 10:
        {
            companyname = textField.text;
        }
            break;
            
        case 11:
        {
            contactname = textField.text;
        }
            
            break;
        case 12:
        {
            address = textField.text;
        }
            
            break;
        case 13:
        {
            zipcode = textField.text;
        }
            
            break;
        case 14:
        {
            city = textField.text;
        }
            
            break;
        case 15:
        {
            phone = textField.text;
        }
            
            break;
        case 16:
        {
            email = textField.text;
        }
            
            break;
            
        default:
        {
            companyname = @"";
            contactname = @"";
            address = @"";
            zipcode = @"";
            city = @"";
            phone = @"";
            email = @"";
        }
            break;
    }
}


#pragma mark Webservice Requests
-(void)signUp
{
    NSString *myURL = [NSString stringWithFormat:@"%@%@",WEBSERVICE_URL,SIGN_UP];
    NSMutableURLRequest *Request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: myURL]];
    NSString *params = [NSString stringWithFormat:@"companyname=%@&contactname=%@&address=%@&zipcode=%@&city=%@&phone=%@&email=%@",companyname,contactname,address,zipcode,city,phone,email];
    [Request setHTTPMethod:@"POST"];
    [Request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    self.connectionSignUp = [[NSURLConnection alloc] initWithRequest:Request delegate:self];
    
    if( self.connectionSignUp )
    {
        _responseData = [NSMutableData data];
    }
    else
    {
        NSLog(@"connectionLogin is NULL");
    }
}
#pragma mark Webservice Response
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [self.responseData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.responseData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"connectionDidFinishLoading");
    
    NSString *stringResponse = [[NSString alloc]initWithData:self.responseData encoding:NSUTF8StringEncoding];
    NSLog(@"Response : %@",stringResponse);
    
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
    
    NSError *jsonParsingError = nil;
    NSDictionary *tempDict = [NSJSONSerialization JSONObjectWithData:self.responseData options:0 error:&jsonParsingError];
    
    if ([[tempDict valueForKey:@"Status"] isEqualToString:@"Success"]) {
        // {"Status":"Success","Result":"Data inserted successfully"}
        // @"Tak for din registrering"
        // @"Du vil modtage et login,"
        // @"så snart vi har behandlet din registrering"
        
        NSString *headerTitle;
        NSString *msgTitle,*subMsg;
        
        headerTitle = @"Tak for din registrering";//@"Send besked";
        msgTitle = @"Du vil modtage et login,";//@"Din formular er afsendt!";
        subMsg = @"så snart vi har behandlet din registrering";
        
        ThankYouFormForSignUpForm *thankYouSignUpForm = [[ThankYouFormForSignUpForm alloc] initWithHeaderTitle:headerTitle withMessage:msgTitle withSubMessage:subMsg];
        thankYouSignUpForm.delegate = self;
        [thankYouSignUpForm setupSubViews];
    }
    
    if (self.responseData == nil)
    {
        ShowAlert(AlertTitle, @"Server not reachable. Please try again.");
        return;
    }
}

- (void)messageDismissThankYouFormForSignUpForm:(ThankYouFormForSignUpForm *)thankYouFormForSignUpForm {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - Parse Web service Response
- (NSMutableArray *)getArratListForFlow:(NSArray *)aryFlowList {
    NSMutableArray *aryFlows = [[NSMutableArray alloc] init];
    if ([aryFlows count]!=0) {
        [aryFlows removeAllObjects];
    }
    
    for (NSDictionary *dict in aryFlowList) {
        SubFlow *subFlow_ = [[SubFlow alloc] initWithDictionary:dict];
        [aryFlows addObject:subFlow_];
    }
    
    return aryFlows;
}





#pragma mark - Status Bar
//-(BOOL)prefersStatusBarHidden{
//    return YES;
//}

#pragma mark willRotateToAnimation
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [self.tblView reloadData];
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
     }completion:^(id<UIViewControllerTransitionCoordinatorContext> context)
     {
         
     }];
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
}

- (IBAction)onButtonBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end

