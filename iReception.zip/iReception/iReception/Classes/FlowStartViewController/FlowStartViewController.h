//
//  FlowStartViewController.h
//  iReception
//
//  Created by spaculus on 7/25/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowStartViewController : UIViewController
@property (strong, nonatomic) Flow *flow;
@property (strong, nonatomic) SubFlow *subFlow;

@property (strong, nonatomic) IBOutlet UIButton *btnStart;
@end
