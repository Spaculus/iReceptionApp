//
//  FlowStartViewController.m
//  iReception
//
//  Created by spaculus on 7/25/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "FlowStartViewController.h"
#import "HomeViewController.h"

@interface FlowStartViewController ()

@property (strong, nonatomic) IBOutlet UILabel *lblFlowNameTitle;
@property (strong, nonatomic) IBOutlet UILabel *lblDescTitle;


@property (strong, nonatomic) IBOutlet UIButton *btnBack;
- (IBAction)onButtonBackClicked:(id)sender;

@end

@implementation FlowStartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.btnStart.layer.cornerRadius = 5.0f;
    self.btnStart.layer.masksToBounds = YES;
    
    if ([CommonUtils isEnglishLanguage]) {
        self.lblFlowNameTitle.text = @"Note :";
        self.lblDescTitle.text = [NSString stringWithFormat:@"%@\n\n%@",@"To reset the application and select another flow of flow start, press and hold the right corner for 5-7 seconds.",@"here after the application will stand in the login image."];
    }
    else {
        self.lblFlowNameTitle.text = @"Bemærk:";
        self.lblDescTitle.text = [NSString stringWithFormat:@"%@\n\n%@",@"For at nulstille receptionen og derved vælge en andet flow og start, skal du trykke og holde fingeren på skærmen i nederste højre hjørne i 5-7 sekunder.",@"Herefter vil receptionen stille sig i login billedet igen, hvorfra du skal logge på."];
    }
   
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction) onClickButtonStartReception: (UIButton *)btnStartreception {
   
   [[NSUserDefaults standardUserDefaults] setValue:@"2" forKey:@"LoggedIn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_flowPID forKey:@"root_flowPID"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_pID forKey:@"root_childPID"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_page_headline forKey:@"root_headline"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_targetPID forKey:@"root_targetPID"];
    [[NSUserDefaults standardUserDefaults] synchronize];
   
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_design_key forKey:@"root_design_key"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *root_targetPID = [[NSUserDefaults standardUserDefaults] valueForKey:@"root_targetPID"];
    
     NSLog(@"%@\n%@",self.subFlow.subFlow_targetPID,root_targetPID);
    appDel.levelCount = 0;
    
    HomeViewController *home = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    home.subFlow = self.subFlow;
    //home.isFromRoot = YES;
   // home.isFromStartFlow =  YES;
    
    if (self.subFlow.subFlow_targetPID.length !=0) {
        appDel.levelCount++;
        [[NSUserDefaults standardUserDefaults] setInteger:appDel.levelCount forKey:@"levelCount"];
        [[NSUserDefaults standardUserDefaults] synchronize];
     //   home.isChild = NO;
        home.isTarget = YES;
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isTarget"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        home.isTargetElement = YES;
        home.isEndElement = NO;
        
    }
    else {
       // home.isChild = YES;
        home.isTarget = NO;
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isTarget"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        home.isTargetElement = NO;
    }
    
    
    home.subflow_design_key = [CommonUtils getNotNullString:self.subFlow.subFlow_design_key];
    
    [[NSUserDefaults standardUserDefaults] setValue:@"2" forKey:@"LoggedIn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_flowPID forKey:@"root_flowPID_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_pID forKey:@"root_childPID_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_page_headline forKey:@"root_headline_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.subFlow.subFlow_targetPID forKey:@"root_targetPID_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setInteger:appDel.levelCount forKey:@"levelCount_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:home.isTarget forKey:@"isTarget_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:home.subflow_design_key forKey:@"root_design_key_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:home];
    appDel.window.rootViewController = nav;
    
    [UIView transitionWithView:appDel.window
                      duration:0.3
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:nil
                    completion:nil];
}

- (IBAction)onButtonBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
