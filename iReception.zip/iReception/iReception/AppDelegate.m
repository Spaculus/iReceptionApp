//
//  AppDelegate.m
//  iReception
//
//  Created by spaculus on 7/5/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginViewController.h"
#import "HomeViewController.h"
#import "FlowViewController.h"
#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    
    NSString * custID = [[NSUserDefaults standardUserDefaults] valueForKey:@"custID"];
    NSString * flowname = [[NSUserDefaults standardUserDefaults] valueForKey:@"flowname"];
    NSString * pincode = [[NSUserDefaults standardUserDefaults] valueForKey:@"pincode"];
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    NSString * LoggedIn = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"LoggedIn"]];
    NSString * root_flowPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_flowPID_INIT"]];
    NSString * root_childPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_childPID_INIT"]];
    
    NSString * root_headline_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_headline_INIT"]];
    NSString * root_targetPID_INIT = [CommonUtils getNotNullString:[[NSUserDefaults standardUserDefaults] valueForKey:@"root_targetPID_INIT"]];
    BOOL isFromRoot_INIT = [[NSUserDefaults standardUserDefaults] boolForKey:@"isFromRoot_INIT"];
    
    NSInteger levelCount_INIT = [[NSUserDefaults standardUserDefaults] integerForKey:@"levelCount_INIT"];
    BOOL isTarget_INIT = [[NSUserDefaults standardUserDefaults] boolForKey:@"isTarget_INIT"];
    
    NSString *ics = [[NSUserDefaults standardUserDefaults] valueForKey:@"ics_available_INIT"];
    NSString *strTimeAfter = [[NSUserDefaults standardUserDefaults] valueForKey:@"timeAfter_INIT"];
    NSString *strTimeBefore = [[NSUserDefaults standardUserDefaults] valueForKey:@"timeBefore_INIT"];
    
    NSString *resetAfterAlert = [[NSUserDefaults standardUserDefaults] valueForKey:@"resetAfterAlert_INIT"];
    NSString *resetForAlert = [[NSUserDefaults standardUserDefaults] valueForKey:@"resetForAlert_INIT"];
    NSString *resetForChild = [[NSUserDefaults standardUserDefaults] valueForKey:@"resetForChild_INIT"];
    
    NSString *design_key = [[NSUserDefaults standardUserDefaults] valueForKey:@"root_design_key_INIT"];
    
    NSString *isBGColor = [[NSUserDefaults standardUserDefaults] valueForKey:@"isBGColor"];
    NSString *BGView = [[NSUserDefaults standardUserDefaults] valueForKey:@"BGView"];
    NSString *BG_COLOR = [[NSUserDefaults standardUserDefaults] valueForKey:@"BG_COLOR"];
    
    [[NSUserDefaults standardUserDefaults] setPersistentDomain:[NSDictionary dictionary] forName:[[NSBundle mainBundle] bundleIdentifier]];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:design_key forKey:@"root_design_key_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:LoggedIn forKey:@"LoggedIn"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:root_flowPID_INIT forKey:@"root_flowPID_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:root_childPID_INIT forKey:@"root_childPID_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:root_headline_INIT forKey:@"root_headline_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:root_targetPID_INIT forKey:@"root_targetPID_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:isFromRoot_INIT forKey:@"isFromRoot_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setInteger:levelCount_INIT forKey:@"levelCount_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setBool:isTarget_INIT forKey:@"isTarget_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:resetAfterAlert forKey:@"resetAfterAlert_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:resetForAlert forKey:@"resetForAlert_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:resetForChild forKey:@"resetForChild_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:ics forKey:@"ics_available_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:strTimeAfter forKey:@"timeAfter_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:strTimeBefore forKey:@"timeBefore_INIT"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:isBGColor forKey:@"isBGColor"];
    [[NSUserDefaults standardUserDefaults] setValue:BGView forKey:@"BGView"];
    [[NSUserDefaults standardUserDefaults] setValue:BG_COLOR forKey:@"BG_COLOR"];
    
    [[NSUserDefaults standardUserDefaults] setValue:custID forKey:@"custID"];

    [[NSUserDefaults standardUserDefaults] setValue:flowname forKey:@"flowname"];
    
    [[NSUserDefaults standardUserDefaults] setValue:pincode forKey:@"pincode"];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    // Override point for customization after application launch.
    
    [Fabric with:@[[Crashlytics class]]];

    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    self.aryLevels = [[NSMutableArray alloc] init];
    self.levelCount = 0;
    
    self.resetAfterAlert = [[[NSUserDefaults standardUserDefaults] valueForKey:@"resetAfterAlert"] integerValue];
    self.resetForAlert = [[[NSUserDefaults standardUserDefaults] valueForKey:@"resetForAlert"] integerValue];
    self.resetForChild = [[[NSUserDefaults standardUserDefaults] valueForKey:@"resetForChild"] integerValue];
    
    UIViewController *vc = nil;
    if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"LoggedIn"] isEqualToString:@"2"]) {
        vc = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    }
    else if([[[NSUserDefaults standardUserDefaults] valueForKey:@"LoggedIn"] isEqualToString:@"1"]){
        vc = [[FlowViewController alloc] initWithNibName:@"FlowViewController" bundle:nil];
    }
    else {
        vc = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    }
    
    self.navController = [[UINavigationController alloc] initWithRootViewController:vc];
    self.window.rootViewController = self.navController;
    
    
    //[self.navigationController.navigationBar setBackgroundColor:[UIColor clearColor]];
    
    [CommonUtils clearBackButtonForNavigationBarAppearance];
    [CommonUtils setLightNavigationBarForAppearanceWithNavigationController:self.navController];
    [application setStatusBarHidden:YES];
    [self.window makeKeyAndVisible];
    return YES;

}

- (void)applicationWillResignActive:(UIApplication *)application {
   
    
    
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
   
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
   
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFromRoot"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end

