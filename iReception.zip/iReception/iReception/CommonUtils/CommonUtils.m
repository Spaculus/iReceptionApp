//
//  CommonUtils.m
//  iReception
//
//  Created by spaculus on 7/5/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "CommonUtils.h"

@implementation CommonUtils

#pragma mark - DEVICE TYPES
+(BOOL)isiPad
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
+(BOOL)isIPhone4
{
    if ([[UIScreen mainScreen] bounds].size.height<568) {
        return YES;
    }else
    {
        return NO;
    }
}
+(BOOL)isIPhone5
{
    
    if ([[UIScreen mainScreen] bounds].size.height==568) {
        return YES;
    }else
    {
        return NO;
    }
    
}
+(BOOL)isIPhone6
{
    
    if ([[UIScreen mainScreen] bounds].size.height==667) {
        return YES;
    }else
    {
        return NO;
    }
    
}
+(BOOL)isIPhone6Plus
{
    
    if ([[UIScreen mainScreen] bounds].size.height==736) {
        return YES;
    }else
    {
        return NO;
    }
    
}


+(BOOL)isIPhone4_Landscape
{
    if ([[UIScreen mainScreen] bounds].size.width<568) {
        return YES;
    }else
    {
        return NO;
    }
}
+(BOOL)isIPhone5_Landscape
{
    
    if ([[UIScreen mainScreen] bounds].size.width==568) {
        return YES;
    }else
    {
        return NO;
    }
    
}
+(BOOL)isIPhone6_Landscape
{
    
    if ([[UIScreen mainScreen] bounds].size.width==667) {
        return YES;
    }else
    {
        return NO;
    }
    
}
+(BOOL)isIPhone6Plus_Landscape
{
    
    if ([[UIScreen mainScreen] bounds].size.width==736) {
        return YES;
    }else
    {
        return NO;
    }
    
}


#pragma mark Device Screens
+(CGSize)screenSize
{
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    if ((NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) && UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation))
    {
        return CGSizeMake(screenSize.height, screenSize.width);
    }
    else
    {
        return screenSize;
    }
}

+(BOOL)isLandscapeOrientation {
    return UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation);
}

#pragma mark - Check Network
+(BOOL)connected
{
    Reachability *reachability = [Reachability reachabilityWithHostName:@"www.google.com"];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return !(networkStatus == NotReachable);
}

#pragma mark - DOC Folder
+(NSString *)getDocumentDirectoryPathForFileName:(NSString *)fileName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    return filePath;
}


+(BOOL)fileExistAtPath:(NSString *)filePath
{
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        return YES;
    }else
    {
        return NO;
    }
}

+(void)downloadData:(NSData *)data atPath:(NSString *)filePath
{
    [data writeToFile:filePath atomically:NO];
}

+(NSData *)getDataFromPath:(NSString *)filePath
{
    NSURL *url = [NSURL fileURLWithPath:filePath];//fullPath
    NSData *data = [NSData dataWithContentsOfURL:url];
    return data;
}

+(NSArray *)getPathsOnDocumentDirectories
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return paths;
}

+(void)removeFileFromDocumentDir:(NSString *)fileName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
    NSString *filePath = [documentsPath stringByAppendingPathComponent:fileName];
    NSError *error;
    BOOL success = [fileManager removeItemAtPath:filePath error:&error];
    if (success)
    {
        NSLog(@"Deleted file successfully");
    }
    else
    {
        NSLog(@"Could not delete file -:%@ ",[error localizedDescription]);
    }
}

#pragma mark - GPS
+(NSString *)milesfromPlace:(double)fromLat fromLongitude:(double)fromLong toLatitude:(double)toLat toLongitude:(double)toLong
{
    CLLocation *userloc = [[CLLocation alloc]initWithLatitude:fromLat longitude:fromLong];
    CLLocation *dest = [[CLLocation alloc]initWithLatitude:toLat longitude:toLong];
    CLLocationDistance dist = [userloc distanceFromLocation:dest]/1609.34;
    
    return [NSString stringWithFormat:@"%.2f miles",dist];
}

+(NSMutableArray *)getLatLongfromAddress:(NSString *)addressText
{
    NSString *stringAdress = [addressText stringByReplacingOccurrencesOfString:@" " withString:@"+"];
    NSString *esc_addr =  [stringAdress stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
    
    NSMutableDictionary *data = [NSJSONSerialization JSONObjectWithData:[result dataUsingEncoding:NSUTF8StringEncoding]options:NSJSONReadingMutableContainers error:nil];
    NSMutableArray *dataArray = (NSMutableArray *)[data valueForKey:@"results" ];
    
    if (dataArray.count == 0)
    {
        ShowAlert(AlertTitle, @"Please Enter a valid address");
    }
    else
    {
        for (id firstTime in dataArray)
        {
            NSString *jsonStr1 = [firstTime valueForKey:@"geometry"];
            NSMutableArray *Location = [jsonStr1 valueForKey:@"location"];
            NSString *latitude = [Location  valueForKey:@"lat"];
            NSLog(@"Data Return=%@",latitude);
            return Location;
        }
    }
    return nil;
}

#pragma mark - String
+(BOOL)isEnglishLanguage {
    NSString * language = [[NSLocale preferredLanguages] objectAtIndex:0];
    NSDictionary *languageDic = [NSLocale componentsFromLocaleIdentifier:language];
    NSString *languageCode = (NSString *)[languageDic objectForKey:@"kCFLocaleLanguageCodeKey"];
    if ([languageCode isEqualToString:@"en"]) {
        return NO;
    }
    else {
        return NO;
    }
}
+(NSString *)getOrdinalStringFromValue:(NSInteger)anObject {
    //    if (![anObject isKindOfClass:[NSNumber class]]) {
    //        return nil;
    //    }
    
    NSString *strRep =  [NSString stringWithFormat:@"%ld",(long)anObject];//[anObject stringValue];
    NSString *lastDigit = [strRep substringFromIndex:([strRep length]-1)];
    
    NSString *ordinal;
    
    
    if ([strRep isEqualToString:@"11"] || [strRep isEqualToString:@"12"] || [strRep isEqualToString:@"13"]) {
        ordinal = @"th";
    } else if ([lastDigit isEqualToString:@"1"]) {
        ordinal = @"st";
    } else if ([lastDigit isEqualToString:@"2"]) {
        ordinal = @"nd";
    } else if ([lastDigit isEqualToString:@"3"]) {
        ordinal = @"rd";
    } else {
        ordinal = @"th";
    }
    
    return [NSString stringWithFormat:@"%@%@", strRep, ordinal];
}

+(BOOL) validateAlphabets:(NSString *)string
{
    NSString *abnRegex = @"[A-Za-z]+(\\s[A-Za-z]+)?";
    NSPredicate *abnTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", abnRegex];
    BOOL isValid = [abnTest evaluateWithObject:string];
    return isValid;
}

+(NSString *)getNotNullString:(id)string
{
    NSString *sourceStr = @"";
    
    if ([string isKindOfClass:[NSNumber class]]) {
        sourceStr = [string stringValue];
    }
    else {
        sourceStr = [NSString stringWithFormat:@"%@",(NSString *)string];
    }
    
    if ([sourceStr isEqualToString:@"(null)"]) {
        sourceStr = @"";
    }
    if ([sourceStr isEqualToString:@"<null>"]) {
        sourceStr = @"";
        
    }
    if ([sourceStr isEqualToString:@"<nil>"]) {
        sourceStr = @"";
    }
    if ([sourceStr isKindOfClass:[NSNull class]]) {
        sourceStr = @"";
    }
    if (sourceStr.length == 0) {
        sourceStr = @"";
    }
    if (sourceStr == nil) {
        sourceStr = @"";
    }
    
    return sourceStr;
}

+(NSString *)suffixNumber:(NSNumber*)number
{
    if (!number)
        return @"";
    
    long long num = [number longLongValue];
    
    int s = ( (num < 0) ? -1 : (num > 0) ? 1 : 0 );
    NSString* sign = (s == -1 ? @"-" : @"" );
    
    num = llabs(num);
    
    if (num < 1000)
        return [NSString stringWithFormat:@"%@%lld",sign,num];
    
    int exp = (int) (log(num) / log(1000));
    
    NSArray* units = @[@"K",@"M",@"G",@"T",@"P",@"E"];
    
    return [NSString stringWithFormat:@"%@%.1f%@",sign, (num / pow(1000, exp)), [units objectAtIndex:(exp-1)]];
}

+(NSString *)removeLeadingTrailingWhiteSpace:(NSString *)string
{
    NSString *rawString = string;
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    return trimmed;
}

+(NSString *)convertToUTF8:(NSString *)string
{
    NSArray* words = [string componentsSeparatedByCharactersInSet :[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString* nospacestring = [words componentsJoinedByString:@" "];
    NSData *data = [nospacestring dataUsingEncoding:NSUTF8StringEncoding];
    NSString *goodValue = [[NSString alloc] initWithData:data encoding:NSNonLossyASCIIStringEncoding];
    return goodValue;
}

+(NSString *)convertToUnicode:(NSString *)string
{
    NSData *dataenc = [string dataUsingEncoding:NSNonLossyASCIIStringEncoding];
    NSString *encodevalue = [[NSString alloc]initWithData:dataenc encoding:NSUTF8StringEncoding];
    return encodevalue;
}

+(NSString *)explodeString:(NSString*)stringToBeExploded WithDelimiter:(NSString*)delimiter andCOmponent:(NSUInteger)rowNum
{
    return [stringToBeExploded componentsSeparatedByString: delimiter][rowNum];
}

+(NSString *)removeHTMLFromString:(NSString *)str
{
    NSAttributedString *attr = [[NSAttributedString alloc] initWithData:[str dataUsingEncoding:NSUTF8StringEncoding]
                                                                options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                          NSCharacterEncodingDocumentAttribute:@(NSUTF8StringEncoding)}
                                                     documentAttributes:nil
                                                                  error:nil];
    return [attr string];
}

#pragma mark JSON String
+(NSString *)getJSONStringFromDict:(id)dict
{
    NSError *jsonParsingError = nil;
    NSData *jsonData2 = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&jsonParsingError];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData2 encoding:NSUTF8StringEncoding];
    NSLog(@"jsonData as string:\n%@", jsonString);
    return jsonString;
}

#pragma mark BASE 64 STRINGs
+(NSString *)getBase64StringFrom:(NSString *)decodeString
{
    NSData *encodeData = [decodeString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [encodeData base64EncodedStringWithOptions:0];
    NSLog(@"Encode String: %@", base64String);
    return base64String;
}

+(NSString *)encodeToBase64String:(UIImage *)image
{
    return [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
}

#pragma mark - Validation
+ (BOOL)validateUrl:(NSString *)candidate
{
    NSString *urlRegEx =
    @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

+(BOOL)IsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

+(BOOL) validateName:(NSString *)text
{
    NSString *Regex = @"^[a-zA-Z\\s]+";
    NSPredicate *TestResult = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", Regex];
    return [TestResult evaluateWithObject:text];
}

+(BOOL)validateUserName:(NSString *)string
{
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    //((?:^|\\s)(?:@){1}[0-9a-zA-Z_]{1,21})
    //^[a-z0-9_-]{6,20}$
    NSError *error = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"^[a-z0-9_-]{3,20}$" options:NSRegularExpressionCaseInsensitive error:&error];
    
    NSAssert(regex, @"Unable to create regular expression");
    
    NSRange textRange = NSMakeRange(0, trimmedString.length);
    NSRange matchRange = [regex rangeOfFirstMatchInString:trimmedString options:NSMatchingReportProgress range:textRange];
    
    BOOL didValidate = NO;
    
    // Did we find a matching range
    if (matchRange.location != NSNotFound)
        didValidate = YES;
    
    return didValidate;
}

+(BOOL)validatePassword:(NSString *)text
{
    NSString *Regex = @"^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$";
    NSPredicate *TestResult = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", Regex];
    return [TestResult evaluateWithObject:text];
}

+(BOOL)isValidNumber:(NSString *)text
{
    BOOL valid;
    
    NSCharacterSet *alphaNums = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *inStringSet = [NSCharacterSet characterSetWithCharactersInString:text];
    valid = [alphaNums isSupersetOfSet:inStringSet];
    if (!valid)
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

#pragma mark - GET USER DETAILS
+(BOOL)isLoggedIn {
    NSString *isLogin = [[NSUserDefaults standardUserDefaults] valueForKey:@"LoggedIn"];
    
    if ([isLogin isEqualToString:@"1"]) {
        return YES;
        
    }
    else {
        return NO;
    }
}

+(User *)getLoginDetails {
    NSString *custID = [[NSUserDefaults standardUserDefaults] valueForKey:@"custID"];
    NSString *flowname = [[NSUserDefaults standardUserDefaults] valueForKey:@"flowname"];
    NSString *pincode = [[NSUserDefaults standardUserDefaults] valueForKey:@"pincode"];

    User *user = [[User alloc] initWithCustomerID:custID moduleName:flowname pinCode:pincode];
    
    return user;
}

#pragma mark - DATE UTILITIES
+(NSDate *)datewithServerZone:(NSString *)date_added
{
    // To Convert Date To Server Time Zone
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    //[dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:strTimeZone]];
    NSDate *date = [dateFormatter dateFromString:date_added];
    [dateFormatter setDateFormat:@"MMM dd"];
    return date;
}

+(NSDate *)getDateFromString:(NSString *)strDate withFormat:(NSString *)format
{
    NSDate *date = [[NSDate alloc] init];
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:format];
    date = [df dateFromString:strDate];
    return date;
}

+(id)getDateFormattedFromDate:(NSDate *)dt withInputFormat:(NSString *)inputFormat andOutputFormat:(NSString *)outputFormat isString:(BOOL)isString isSameFormat:(BOOL)sameFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:inputFormat];
    NSString *strDate = [dateFormat stringFromDate:dt];
    [dateFormat setDateFormat:outputFormat];
    NSDate *dte = [dateFormat dateFromString:strDate];
    if (isString)
    {
        if (sameFormat) {
            return strDate;
        }
        else {
            NSString *strFormattedDate = [dateFormat stringFromDate:dte];
            return strFormattedDate;
        }
        
    }
    else
    {
        if (sameFormat) {
            NSString *strFormattedDate = [dateFormat stringFromDate:dte];
            NSDate *formattedDate = [dateFormat dateFromString:strFormattedDate];
            return formattedDate;
            
        }
        else {
            NSString *strFormattedDate = [dateFormat stringFromDate:dte];
            NSDate *formattedDate = [dateFormat dateFromString:strFormattedDate];
            return formattedDate;
            
        }
    }
}

+(id)getDateFormattedFromStringDate:(NSString *)strDate withInputFormat:(NSString *)inputFormat andOutputFormat:(NSString *)outputFormat isString:(BOOL)isString
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+2"];//[NSTimeZone defaultTimeZone];
    [dateFormat setTimeZone:timeZone];
    [dateFormat setDateFormat:inputFormat];
    NSDate *dte = [dateFormat dateFromString:strDate];
    [dateFormat setDateFormat:outputFormat];
    if (isString)
    {
        NSString *strFormattedDate = [dateFormat stringFromDate:dte];
        return strFormattedDate;
    }
    else
    {
        NSString *strFormattedDate = [dateFormat stringFromDate:dte];
        NSDate *formattedDate = [dateFormat dateFromString:strFormattedDate];
        return formattedDate;
    }
}

+(NSString *)getFormattedTime:(NSString *)strTime withInputFormat:(NSString *)inputFormat andOutputFormat:(NSString *)outputFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [dateFormat setLocale:locale];
    [dateFormat setDateFormat:inputFormat];
    NSDate *dte = [dateFormat dateFromString:strTime];
    [dateFormat setDateFormat:outputFormat];
    NSString *strFormattedDate = [dateFormat stringFromDate:dte];
    return strFormattedDate;
}

+(BOOL)checkDate:(NSDate *)date1 andDate:(NSDate *)date2
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    
    if ([[dateFormat stringFromDate:date1] isEqualToString:[dateFormat stringFromDate:date2]])
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

+(NSString *)isPastDate:(NSString *)dateString
{
    NSDateFormatter *df= [[NSDateFormatter alloc] init];
    [df setDateFormat:@"MM/dd/yyyy"];
    NSString *currentDate = [df stringFromDate:[NSDate date]];
    NSDate *dt1 = [[NSDate alloc] init];
    NSDate *dt2 = [[NSDate alloc] init];
    dt1 = [df dateFromString:currentDate];
    dt2 = [df dateFromString:dateString];
    NSComparisonResult result = [dt1 compare:dt2];
    NSString *dateValue;
    
    switch (result)
    {
        case NSOrderedAscending:
        {
            NSLog(@"%@ is greater than %@", dt2, dt1);
            dateValue = @"After";
            break;
        }
        case NSOrderedDescending:
        {
            NSLog(@"%@ is less %@", dt2, dt1);
            dateValue = @"Before";
            break;
        }
        case NSOrderedSame:
        {
            NSLog(@"%@ is equal to %@", dt2, dt1);
            dateValue = @"Equal";
            break;
        }
        default:
        {
            NSLog(@"erorr dates %@, %@", dt2, dt1);
            break;
        }
    }
    return dateValue;
}

#pragma mark - SET LABEL UTILITIES
+(UILabel *)setTitleLabel:(NSString *)title
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.text = title;
    titleLabel.backgroundColor = [UIColor clearColor];
    if([self isiPad])
    {
        titleLabel.font = [UIFont fontWithName:OpenSansSemibold size:22.0];
    }
    else
    {
        titleLabel.font = [UIFont fontWithName:OpenSansSemibold size:17.0];
    }
    titleLabel.textColor = [UIColor whiteColor];
    [titleLabel sizeToFit];
    return titleLabel;
}

+(UILabel *)setDarkTitleLabel:(NSString *)title {
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.text = title;
    titleLabel.backgroundColor = [UIColor clearColor];
    if([CommonUtils isiPad])
    {
        titleLabel.font = [UIFont systemFontOfSize:22.0];
    }
    else
    {
        titleLabel.font = [UIFont systemFontOfSize:17.0];
    }
    titleLabel.textColor = [UIColor colorWithRed:1/255.0 green:72/255.0 blue:140/255.0 alpha:1];
    [titleLabel sizeToFit];
    return titleLabel;
}

+(void)findUsernameAndHashTag:(TTTAttributedLabel *)lbl withColor:(UIColor *)color atRange:(NSRange)range
{
    NSRegularExpression *mentionExpression = [NSRegularExpression regularExpressionWithPattern:@"(?:^|\\s)(#\\w+|@\\w+)" options:NO error:nil];
    NSArray *matches = [mentionExpression matchesInString:lbl.text
                                                  options:0
                                                    range:range];
    for (NSTextCheckingResult *match in matches)
    {
        NSArray *keys = [[NSArray alloc] initWithObjects:(id)kCTForegroundColorAttributeName,(id)kCTUnderlineStyleAttributeName, nil];
        NSArray *objects = [[NSArray alloc] initWithObjects:color,[NSNumber numberWithInt:kCTUnderlineStyleNone], nil];
        NSDictionary *linkAttributes = [[NSDictionary alloc] initWithObjects:objects forKeys:keys];
        [lbl addLinkWithTextCheckingResult:match attributes:linkAttributes];
    }
}

+(TTTAttributedLabel *)changeTextStyleMethod:(TTTAttributedLabel *)attLabel setText:(NSString *)text textRange:(NSString *)range fontName:(NSString *)font fontSize:(NSInteger)size andColor:(UIColor *)color
{
    // For changing TTTAttributedLabel Text Style with Size
    
    [attLabel setText:text afterInheritingLabelAttributesAndConfiguringWithBlock:^(NSMutableAttributedString *mutableAttributedString) {
        
        //font helvetica with bold and italic
        UIFont *boldSystemFont = [UIFont systemFontOfSize:size];
        
        //UIFont *boldSystemFont = [UIFont italicSystemFontOfSize:size];
        
        CTFontRef font = CTFontCreateWithName((__bridge CFStringRef)boldSystemFont.fontName, boldSystemFont.pointSize, NULL);
        
        NSRange boldRange = [[mutableAttributedString string] rangeOfString:range options:NSCaseInsensitiveSearch];
        
        [mutableAttributedString addAttribute:(NSString *)kCTFontAttributeName value:(__bridge id)font range:boldRange];
        
        [mutableAttributedString addAttribute:(NSString *)kCTForegroundColorAttributeName value:(id)color.CGColor range:boldRange];
        
        CFRelease(font);
        
        return mutableAttributedString;
    }];
    
    return attLabel;
}

+(void)setBorderAndCorner_ForLabel:(UILabel *)lbl forCornerRadius:(CGFloat)r forBorderWidth:(CGFloat)w
{
    lbl.layer.cornerRadius = r;
    lbl.layer.masksToBounds = YES;
    lbl.layer.borderWidth = w;
}

+(void)rotateLabel:(UILabel*) label
{
    CGRect orig = label.frame;
    label.transform=CGAffineTransformMakeRotation(M_PI * 3/2);
    label.frame = orig;
}

#pragma mark - SET TEXTFIELDS / Text View
+(void)setLeftPadding:(int)paddingValue andTextField:(UITextField *)textField
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, paddingValue, textField.frame.size.height)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
}

+(void)setBorderAndCorner_ForTextField:(UITextField *)txtField forCornerRadius:(CGFloat)r forBorderWidth:(CGFloat)w withPadding:(int)p andColor:(CGColorRef)color
{
    txtField.layer.cornerRadius = r;
    txtField.layer.masksToBounds = YES;
    txtField.layer.borderColor = color;
    txtField.layer.borderWidth = w;
    [CommonUtils setLeftPadding:p andTextField:txtField];
}

+(void)setLeftImageToTextField:(UITextField *)txtField andImage:(NSString *)imgName andImgWidth:(CGFloat)width andImgHeight:(CGFloat)height withPadding:(CGFloat)padding
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, padding, txtField.frame.size.height)];
    UIImageView *disUser = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imgName]];
    [disUser setFrame:CGRectMake(5, txtField.frame.size.height/2 - disUser.frame.size.height/2, width, height)];
    txtField.leftViewMode = UITextFieldViewModeAlways;
    [disUser setUserInteractionEnabled:YES];
    [paddingView addSubview:disUser];
    txtField.leftView = paddingView;
}

+(void)setRightImageToTextField:(UITextField *)txtField withImage:(NSString *)image withPadding:(CGFloat)padding withWidth:(CGFloat)width withHeight:(CGFloat)height forSelector:(SEL)openKeyBoard forTarget:(id)target
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, padding, txtField.frame.size.height)];
    UIImageView *disUser = [[UIImageView alloc] initWithImage:[UIImage imageNamed:image]];
    [disUser setFrame:CGRectMake(0, txtField.frame.size.height/2 - disUser.frame.size.height/2, width, height)];
    txtField.rightViewMode = UITextFieldViewModeAlways;
    [disUser setUserInteractionEnabled:YES];
    UITapGestureRecognizer *tapDisUser = [[UITapGestureRecognizer alloc] initWithTarget:target action:openKeyBoard];
    tapDisUser.numberOfTapsRequired = 1;
    tapDisUser.numberOfTouchesRequired = 1;
    [disUser addGestureRecognizer:tapDisUser];
    [paddingView addSubview:disUser];
    txtField.rightView = paddingView;
}

+(BOOL)checkLink:(NSString *)link
{
    NSString *string = link; //coming from server
    NSDataDetector *phoneDetector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:nil];
    NSArray *urlMatches = [phoneDetector matchesInString:string options:0 range:NSMakeRange(0, [string length])];
    
    for (NSTextCheckingResult *match in urlMatches) {
        
        if ([match resultType] == NSTextCheckingTypeLink) {
            NSString *matchingStringUrl = [match description];
            NSLog(@"found URL: %@", matchingStringUrl);
            return YES;
        }
        else
        {
            return NO;
        }
    }
    return 0;
}

+(void)setColorToAttributedPlaceholderToTextField:(UITextField *)textField andPlaceholderString:(NSString *)string andColor:(CGColorRef)color withFontColor:(UIColor *)textColor
{
    textField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:string attributes:@{NSForegroundColorAttributeName:[UIColor colorWithCGColor:color]}];
    textField.textColor = textColor;
}

+(CGFloat)setCornerRadiusForTextField
{
    if([self isiPad])
    {
        return iPadCornerRadius;
    }
    else
    {
        return iPhoneCornerRadius;
    }
}

#pragma mark - NAVIGATION BARS
+(UITextField *)setSearchFieldOnBarOfWidth:(CGFloat)width {
    
    UITextField *searchField = [[UITextField alloc]initWithFrame:CGRectMake(0, 0, width, 30.0)];
    searchField.layer.cornerRadius = 5.0;
    searchField.layer.masksToBounds = YES;
    searchField.layer.borderWidth = 0.8f;
    searchField.layer.borderColor = [UIColor colorWithRed:146.0/255.0 green:145.0/255.0 blue:145.0/255.0 alpha:1.0].CGColor;
    
    //searchField.layer.cornerRadius = 3.0;
    
    searchField.tintColor = [UIColor blackColor];
    searchField.backgroundColor = [UIColor whiteColor];
    searchField.font = [UIFont systemFontOfSize:14.0];
    searchField.placeholder = @"Search Here...";
    
    
    [CommonUtils setLeftPadding:10 andTextField:searchField];
    [CommonUtils setColorToAttributedPlaceholderToTextField:searchField andPlaceholderString:searchField.placeholder andColor:[[UIColor colorWithRed:146.0/255.0 green:145.0/255.0 blue:145.0/255.0 alpha:1.0] CGColor] withFontColor:[UIColor colorWithRed:1/255.0 green:72/255.0 blue:140/255.0 alpha:1]];
    
    
    searchField.textColor = [UIColor colorWithRed:146.0/255.0 green:145.0/255.0 blue:145.0/255.0 alpha:1.0];
    
    return searchField;
}

+ (UIBarButtonItem*)barItemWithImage:(UIImage*)image highlightedImage:(UIImage*)highlightedImage xOffset:(NSInteger)xOffset target:(id)target action:(SEL)action
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    [button setImage:image forState:UIControlStateNormal];
    [button setImage:highlightedImage forState:UIControlStateHighlighted];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7) {
        [button setImageEdgeInsets:UIEdgeInsetsMake(0, xOffset, 0, -xOffset)];
    }
    
    UIBarButtonItem *customUIBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    return customUIBarButtonItem;
}

+(void)setNavigationBarImage:(UIImage *)image forNavigationBar:(UINavigationBar *)navBar
{
    [navBar setBarTintColor:[UIColor colorWithRed:187.0/255.0 green:124.0/255.0 blue:37.0/255.0 alpha:1.0]];
    [navBar setBackgroundColor:[UIColor colorWithRed:187.0/255.0 green:124.0/255.0 blue:37.0/255.0 alpha:1.0]];
    [navBar setBackgroundImage:[image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forBarMetrics:UIBarMetricsDefault];
    [navBar setTintColor:[UIColor whiteColor]];
    
    
}


+(void)setLightNavigationBarForAppearanceWithNavigationController:(UINavigationController *)navController {
    
    /*[navBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
     navBar.shadowImage = [UIImage new];
     navBar.translucent = NO;*/
    
    [navController setNavigationBarHidden:NO];
    [[UINavigationBar appearance] setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[UIImage new]];
    [[UINavigationBar appearance] setTranslucent:YES];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    //[navBar setBarTintColor:[UIColor whiteColor]];
    //[navBar setBarTintColor:[UIColor whiteColor]];
}

+(void)setLightNavigationBar:(UINavigationBar *)navBar navigationController:(UINavigationController *)navController {
    
    /*[navBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
     navBar.shadowImage = [UIImage new];
     navBar.translucent = NO;*/
    
    [navController setNavigationBarHidden:NO];
    [navBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [navBar setShadowImage:[UIImage new]];
    [navBar setTranslucent:YES];
    //[navBar setBarTintColor:[UIColor whiteColor]];
    [navBar setTintColor:[UIColor whiteColor]];
    
    //[navBar setBarTintColor:[UIColor whiteColor]];
}

+(void)setDarkNavigationBar:(UINavigationBar *)navBar {
    [navBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    navBar.shadowImage = nil;
    navBar.translucent = NO;
    
    [navBar setBarTintColor:[UIColor blackColor]];
    [navBar setTintColor:[UIColor whiteColor]];
}

+(void)clearBackButtonForNavigationBarAppearance {
    [UINavigationBar appearance].topItem.title = @" ";
}

+(void)clearBackButtonForNavigationBar:(UINavigationBar *)navBar {
    navBar.topItem.title = @" ";
}

#pragma mark - TABLE VIEW
+(void)setLineSeperatorForTableView
{
    // iOS 7:
    [[UITableView appearance] setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [[UITableView appearance] setSeparatorInset:UIEdgeInsetsZero];
    
    [[UITableViewCell appearance] setSeparatorInset:UIEdgeInsetsZero];
    
    // iOS 8:
    if ([UITableView instancesRespondToSelector:@selector(setLayoutMargins:)])
    {
        [[UITableView appearance] setLayoutMargins:UIEdgeInsetsZero];
        [[UITableViewCell appearance] setLayoutMargins:UIEdgeInsetsZero];
        [[UITableViewCell appearance] setPreservesSuperviewLayoutMargins:NO];
    }
}

+(UITableViewCell *)createDefaultCell:(UITableView *)tblView {
    static NSString * Identifier = @"defaultcell";
    UITableViewCell *cell = [tblView dequeueReusableCellWithIdentifier:Identifier];
    if (cell==nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    
    return cell;
}

#pragma mark - ALERT VIEW
+(void)alertViewDelegateWithTitle:(NSString *)title withMessage:(NSString *)message andTarget:(id)target forCancelString:(NSString *)cancelString forOtherButtonString:(NSString *)otherString withTag:(NSInteger)tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:message delegate:target cancelButtonTitle:cancelString otherButtonTitles:otherString, nil];
    [alertView setTag:tag];
    [alertView show];
}

+(void)alertViewWithTextfieldForTitle:(NSString *)title withMessage:(NSString *)message andTarget:(id)target forCancelString:(NSString *)cancelString forOtherButtonString:(NSString *)otherString withAlertTag:(NSInteger)alertTag withTextfieldTag:(NSInteger)textFieldTag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:AlertTitle message:message delegate:target cancelButtonTitle:cancelString otherButtonTitles:otherString, nil];
    alertView.tag = alertTag;
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *txtEmail = [alertView textFieldAtIndex:0];
    txtEmail.tag = textFieldTag;
    [txtEmail becomeFirstResponder];
    [alertView show];
}

#pragma mark - Button
+(void)setBorderAndCorner_ForButton:(UIButton *)button forCornerRadius:(CGFloat)r forBorderWidth:(CGFloat)w withColor:(CGColorRef)color
{
    button.layer.cornerRadius = r;
    button.layer.borderColor = color;
    button.layer.borderWidth = w;
}

#pragma mark - Image
+ (UIImage *)imageFromColor:(UIColor *)color forSize:(CGSize)size withCornerRadius:(CGFloat)radius
{
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // Begin a new image that will be the new image with the rounded corners
    // (here with the size of an UIImageView)
    UIGraphicsBeginImageContext(size);
    
    // Add a clip before drawing anything, in the shape of an rounded rect
    [[UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:radius] addClip];
    // Draw your image
    [image drawInRect:rect];
    
    // Get the image, here setting the UIImageView image
    image = UIGraphicsGetImageFromCurrentImageContext();
    
    // Lets forget about that we were drawing
    UIGraphicsEndImageContext();
    
    return image;
}

+(void)setBackgroundImage:(UIImageView *)imageView withPortrait:(NSString *)imgPortrait withLandscape:(NSString *)imgLandscape
{
    if(UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation))
    {
        [imageView setImage:[UIImage imageNamed:imgLandscape]];
    }
    else
    {
        [imageView setImage:[UIImage imageNamed:imgPortrait]];
    }
}

+ (UIImage *)blurWithCoreImage:(UIImage *)sourceImage withView:(UIView *)myView
{
    CIImage *inputImage = [CIImage imageWithCGImage:sourceImage.CGImage];
    
    // Apply Affine-Clamp filter to stretch the image so that it does not
    // look shrunken when gaussian blur is applied
    CGAffineTransform transform = CGAffineTransformIdentity;
    CIFilter *clampFilter = [CIFilter filterWithName:@"CIAffineClamp"];
    [clampFilter setValue:inputImage forKey:@"inputImage"];
    [clampFilter setValue:[NSValue valueWithBytes:&transform objCType:@encode(CGAffineTransform)] forKey:@"inputTransform"];
    
    // Apply gaussian blur filter with radius of 30
    CIFilter *gaussianBlurFilter = [CIFilter filterWithName: @"CIGaussianBlur"];
    [gaussianBlurFilter setValue:clampFilter.outputImage forKey: @"inputImage"];
    [gaussianBlurFilter setValue:@30 forKey:@"inputRadius"];
    
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef cgImage = [context createCGImage:gaussianBlurFilter.outputImage fromRect:[inputImage extent]];
    
    // Set up output context.
    UIGraphicsBeginImageContext(myView.bounds.size);
    CGContextRef outputContext = UIGraphicsGetCurrentContext();
    
    // Invert image coordinates
    CGContextScaleCTM(outputContext, 1.0, -1.0);
    CGContextTranslateCTM(outputContext, 0, -myView.bounds.size.height);
    
    // Draw base image.
    CGContextDrawImage(outputContext, myView.bounds, cgImage);
    
    // Apply white tint
    CGContextSaveGState(outputContext);
    CGContextSetFillColorWithColor(outputContext, [UIColor colorWithWhite:1 alpha:0.2].CGColor);
    CGContextFillRect(outputContext, myView.bounds);
    CGContextRestoreGState(outputContext);
    
    // Output image is ready.
    UIImage *outputImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return outputImage;
}

#pragma mark - Others
+(NSString *)FormatePhoneNumber:(NSString *)text
{
    PhoneNumberFormatter *myPhoneNumberFormatter = [[PhoneNumberFormatter alloc] init];
    NSString *myLocale = @"us";
    text = [myPhoneNumberFormatter format:text withLocale:myLocale];
    return text;
    
}


+(NSMutableString *)filteredPhoneStringFromStringWithFilter:(NSString *)string andFilter:(NSString *)filter
{
    NSUInteger onOriginal = 0, onFilter = 0, onOutput = 0;
    char outputString[([filter length])];
    BOOL done = NO;
    
    while(onFilter < [filter length] && !done)
    {
        char filterChar = [filter characterAtIndex:onFilter];
        char originalChar = onOriginal >= string.length ? '\0' : [string characterAtIndex:onOriginal];
        switch (filterChar) {
            case '#':
                if(originalChar=='\0')
                {
                    // We have no more input numbers for the filter.  We're done.
                    done = YES;
                    break;
                }
                if(isdigit(originalChar))
                {
                    outputString[onOutput] = originalChar;
                    onOriginal++;
                    onFilter++;
                    onOutput++;
                }
                else
                {
                    onOriginal++;
                }
                break;
            default:
                // Any other character will automatically be inserted for the user as they type (spaces, - etc..) or deleted as they delete if there are more numbers to come.
                outputString[onOutput] = filterChar;
                onOutput++;
                onFilter++;
                if(originalChar == filterChar)
                    onOriginal++;
                break;
        }
    }
    outputString[onOutput] = '\0'; // Cap the output string
    return [NSMutableString stringWithUTF8String:outputString];
}



#pragma mark - Get Array Count
+(NSInteger)getArrayCountFromArray:(NSArray *)ary {
    if (ary != nil)
    {
        if ([ary count]==0)
        {
            return 0;
        }else
        {
            return [ary count];
        }
    }else
    {
        return 0;
    }
}

#pragma mark - Call Webservice
+(void)callWebservice:(SEL)webservice forTarget:(id)target{
    BOOL hasConnected = [CommonUtils connected];
    if (hasConnected)
    {
        [target performSelector:webservice withObject:nil afterDelay:0.0001];
    }
    else
    {
        //[[NSNotificationCenter defaultCenter] postNotificationName:DISPLAY_NO_INTERNET_CONNECTION object:nil];
        //ShowAlert(AlertTitle, MSG_NO_INTERNET_CONNECTION);
    }
}

+(void)callWebservice:(SEL)webservice withObject:(id)object forTarget:(id)target{
    BOOL hasConnected = [CommonUtils connected];
    if (hasConnected)
    {
        [target performSelector:webservice withObject:object afterDelay:0.0001];
    }
    else
    {
        ShowAlert(AlertTitle, MSG_NO_INTERNET_CONNECTION);
    }
}

#pragma mark Navigation Bar Icon
+(UIImageView *)setNavBarIcon:(NSString *)imgName withXPosition:(CGFloat)xPos
{
    UIImageView *imgNav = [[UIImageView alloc] initWithFrame:CGRectMake(xPos, 4.5, 35, 35)];
    imgNav.image = [UIImage imageNamed:imgName];
    imgNav.backgroundColor = [UIColor clearColor];
    return imgNav;
}

#pragma mark YouTube Video Detector
+(NSString *)YoutubeEmbededDetectType:(NSString *)wallPostString
{
    wallPostString=[wallPostString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (([wallPostString rangeOfString:@"https://m.youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"https://youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"https://www.youtube.com/embed"].location == NSNotFound) && ([wallPostString rangeOfString:@"http://m.youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"http://youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"http://www.youtube.com/embed"].location == NSNotFound))
    {
        
        wallPostString=@"";
    }
    else
    {
        if (([wallPostString rangeOfString:@"https://m.youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"https://youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"http://m.youtu.be"].location == NSNotFound) && ([wallPostString rangeOfString:@"http://youtu.be"].location == NSNotFound))
        {
            
        }
        else
        {
            wallPostString=  [wallPostString substringWithRange:NSMakeRange([wallPostString rangeOfString:@"youtu.be"].location, [wallPostString length]-[wallPostString rangeOfString:@"youtu.be"].location)];
            wallPostString=  [wallPostString stringByReplacingOccurrencesOfString:@"youtu.be" withString:@""];
            
            return wallPostString;
        }
        
        if (([wallPostString rangeOfString:@"https://www.youtube.com/embed"].location == NSNotFound) && ([wallPostString rangeOfString:@"http://www.youtube.com/embed"].location == NSNotFound))
        {
            
        }
        else
        {
            wallPostString=  [wallPostString substringWithRange:NSMakeRange([wallPostString rangeOfString:@"embed"].location, [wallPostString length]-[wallPostString rangeOfString:@"embed"].location)];
            wallPostString=[wallPostString stringByReplacingOccurrencesOfString:@"embed" withString:@""];
            
            return wallPostString;
        }
    }
    return wallPostString;
}

+(BOOL)YoutubeDetectType:(NSString *)youtubeURL
{
    youtubeURL=[youtubeURL stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (([youtubeURL rangeOfString:@"http://www.youtube.com/watch?"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://m.youtube.com/watch?"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://m.youtube.com/watch?"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://www.youtube.com/watch?"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://m.youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://www.youtube.com/embed"].location == NSNotFound) && ([youtubeURL rangeOfString:@"http://m.youtu.be"].location==NSNotFound) && ([youtubeURL rangeOfString:@"http://youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"http://www.youtube.com/embed"].location == NSNotFound))
    {
        return NO;
    }
    else
    {
        if ([youtubeURL rangeOfString:@"v="].location==NSNotFound)
        {
            if([youtubeURL isEqualToString:@"https://m.youtu.be"]||[youtubeURL isEqualToString:@"https://youtu.be"]||[youtubeURL isEqualToString:@"https://www.youtube.com/embed"]||[youtubeURL isEqualToString:@"http://m.youtu.be"]||[youtubeURL isEqualToString:@"http://youtu.be"]||[youtubeURL isEqualToString:@"http://www.youtube.com/embed"])
            {
                return NO;
            }
            
            if(([youtubeURL rangeOfString:@"https://m.youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"https://www.youtube.com/embed"].location == NSNotFound) && ([youtubeURL rangeOfString:@"http://m.youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"http://youtu.be"].location == NSNotFound) && ([youtubeURL rangeOfString:@"http://www.youtube.com/embed"].location==NSNotFound))
            {
                return NO;
            }
            else
            {
                return YES;
            }
        }
        else
        {
            NSLog(@"Found");
            return YES;
        }
    }
    return NO;
}

#pragma mark Gradient Color
+(void)setGradientColorForView:(UIView *)gradView forStartColor:(UIColor *)startColor andMidColor:(UIColor *)midColor andEndColor:(UIColor *)endColor andTempColor:(UIColor *)tempColor withVertical:(BOOL)isVerticalType
{
    CAGradientLayer *layer =  [CAGradientLayer layer];
    layer.frame = gradView.bounds;
    
    UIColor *fallbackColor = [UIColor blackColor];
    
    if(isVerticalType)
    {
        layer.colors = @[ (id)startColor.CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.7].CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.6].CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.5].CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.4].CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.3].CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.2].CGColor ?: (id)fallbackColor.CGColor,
                          (id)[UIColor colorWithRed:117/255.0 green:200/255.0 blue:6/255.0 alpha:0.1].CGColor ?: (id)fallbackColor.CGColor,
                          (id)endColor.CGColor ?: (id)fallbackColor.CGColor,
                          (id)endColor.CGColor ?: (id)fallbackColor.CGColor];
        
        layer.startPoint = CGPointMake(0.5f, 0.0f);
        layer.endPoint = CGPointMake(0.5f, 1.0f);
    }
    else
    {
        layer.colors = @[ (id)startColor.CGColor ?: (id)fallbackColor.CGColor,
                          (id)midColor.CGColor ?: (id)fallbackColor.CGColor,
                          (id)midColor.CGColor ?: (id)fallbackColor.CGColor,
                          (id)endColor.CGColor ?: (id)fallbackColor.CGColor,
                          (id)endColor.CGColor ?: (id)fallbackColor.CGColor];
        
        layer.startPoint = CGPointMake(0.0f, 0.5f);
        layer.endPoint = CGPointMake(1.0f, 0.5f);
    }
    
    [gradView.layer insertSublayer:layer atIndex:0];
}

@end
