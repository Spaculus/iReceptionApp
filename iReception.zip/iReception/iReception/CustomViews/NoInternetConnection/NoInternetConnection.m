//
//  NoInternetConnection.m
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "NoInternetConnection.h"
#import "ThankYouFormForStandaredCell.h"
#import "HeaderCell.h"
#import "ButtonCell.h"

@interface NoInternetConnection () 

{
    NSTimer *resetTimer;
    BOOL fromView;
}

@property UIView *backgroundMaskView;
@property UIView *containerView;
@property UILabel *lblTitle;
@property UILabel *lblLine;
@property UIImageView *imgView;
@property UILabel *lblMsg;

@property NSString *headerTitle;
@property NSString *message;

@property BOOL tapBackgroundToDismiss;
//tap item to select and confirm
@property BOOL tapPickerViewItemToConfirm;
@end

typedef void (^StandardFormDismissCallback)(void);

@implementation NoInternetConnection {
    StandardFormDismissCallback callback;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (instancetype) initInternetConnectionErrorViewFromView:(BOOL)isFromView {
    self = [super init];
    if(self){
        fromView = isFromView;
        [self setupSubViews];
    }
    return self;
}

- (void)setupSubViews {
    CGRect rect= [UIScreen mainScreen].bounds;
    self.frame = rect;
    
    //mask is full screen
    self.backgroundMaskView = [self buildBackgroundMaskView];
    [self addSubview:self.backgroundMaskView];
    

    self.containerView = [self buildContainerView];
    [self addSubview:self.containerView];
    
    self.lblTitle = [self buildTitleLabel];
    [self.containerView addSubview:self.lblTitle];
    
    // self.lblLine = [self buildLineLabel];
    // [self.containerView addSubview:self.lblLine];
    
    self.lblMsg = [self buildMsgLabel];
    [self.containerView addSubview:self.lblMsg];
    
    self.imgView = [self buildImageView];
    [self.containerView addSubview:self.imgView];
    
    [self show];
    
    if (!fromView) {
            resetTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(resetToHomeForAlert) userInfo:nil repeats:YES];
    }
}


-(void)resetToHomeForAlert
{
    if ([CommonUtils connected]) {
        if (resetTimer) {
            if([resetTimer isValid])
            {
                [resetTimer invalidate];
                resetTimer = nil;
            }
        }
        
        [self cancelButtonPressed:nil];
    }
    else {
    }
}

- (void)show {
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    self.frame = mainWindow.frame;
    [mainWindow addSubview:self];
    
    self.containerView.layer.opacity = 1.0f;
    self.layer.opacity = 0.3f;
    self.layer.transform = CATransform3DMakeScale(1.5f, 1.5f, 1.0f);
    
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                         self.layer.opacity = 1.0f;
                         self.backgroundMaskView.layer.opacity = 0.3f;
                         self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                     }
                     completion:^(BOOL finished) {
                     }
     
     ];
}


- (UIView *)buildBackgroundMaskView{
    
    UIView *bgv;
    bgv = [[UIView alloc] initWithFrame:self.frame];
    bgv.alpha = 0.0;
    bgv.backgroundColor = [UIColor blackColor];
    bgv.userInteractionEnabled = NO;
//    if(self.tapBackgroundToDismiss){
//        [bgv addGestureRecognizer:
//         [[UITapGestureRecognizer alloc] initWithTarget:self
//                                                 action:@selector(cancelButtonPressed:)]];
//    }
    return bgv;
}

- (UIView *)buildContainerView {
    CGRect containerFrame = CGRectMake(227, 306, 569, 156);
    CGRect newRect = containerFrame;
    UIView *bcv = [[UIView alloc] initWithFrame:newRect];
    bcv.layer.cornerRadius = 5.0f;
    bcv.clipsToBounds = YES;
    bcv.backgroundColor = [UIColor whiteColor];
    return bcv;
}



- (UILabel *)buildTitleLabel {
    CGRect newRect = CGRectMake(158, 45, 380, 36);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.textColor = [UIColor blackColor];
    lbl.text = @"Reception er midlertidig ude af drift.";
    lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:20];
    lbl.textAlignment = NSTextAlignmentLeft;
    return lbl;
    
}

- (UILabel *)buildMsgLabel {
    CGRect newRect = CGRectMake(158, 81, 380, 30);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.textColor = [UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0];
    lbl.text = @"Vi arbejder på sagen, vi beklager ulejligheden";
    lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:17];
    lbl.textAlignment = NSTextAlignmentLeft;
    return lbl;
    
}

- (UILabel *)buildLineLabel {
    CGRect newRect = CGRectMake(0, 59, 500, 1);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0];
    return lbl;
    
}

- (UIImageView *)buildImageView {
    CGRect newRect = CGRectMake(31, 30, 96, 96);
    UIImageView *img = [[UIImageView alloc] initWithFrame:newRect];
    img.image = [UIImage imageNamed:@"warning"];
    return img;
    
}

#pragma mark - cancel/confirm button delegate

- (IBAction)cancelButtonPressed:(UIButton *)sender {
    [self dismiss:^{
        [self callDismiss];
    }];
}

- (void)callDismiss {
    if([self.delegate respondsToSelector:@selector(dismissMessageNoInternetConnection:)]){
        [self.delegate dismissMessageNoInternetConnection:self];
    }
}

- (void)dismiss:(StandardFormDismissCallback)completion {
    
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    callback = completion;
    
    if(callback){
        callback();
    }
    float delayTime;
    if (self.tapPickerViewItemToConfirm) {
        delayTime = 0.5;
    }else {
        delayTime = 0;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                             self.layer.opacity = 0.1f;
                             self.layer.transform = CATransform3DMakeScale(3.0f, 3.0f, 1.0f);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         ];
    });
}


    //[self cancelButtonPressed:btnClose];




@end

