//
//  NoInternetConnection.h
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NoInternetConnection;
@protocol NoInternetConnectionDelegate <NSObject>

- (void)dismissMessageNoInternetConnection:(NoInternetConnection *)noInternetConnection;

@end

@interface NoInternetConnection : UIView
@property (nonatomic, strong) id<NoInternetConnectionDelegate> delegate;

- (instancetype) initInternetConnectionErrorViewFromView:(BOOL)isFromView;
- (IBAction)cancelButtonPressed:(UIButton *)sender;
@end
