//
//  StandardForm.h
//  iReception
//
//  Created by spaculus on 7/26/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StandardForm;

@protocol StandardFormDelegate <NSObject>

- (void)standardForm:(StandardForm *)standard sendNotification:(NSDictionary *)dict;
- (void)standardDismissForm:(StandardForm *)standard;
- (void)standardDismissFormOnTouchOutSide:(StandardForm *)contact;
@end


@interface StandardForm : UIView

@property (nonatomic, strong) id<StandardFormDelegate> delegate;

- (id)initWithHeaderTitle:(NSString *)headerTitle;
- (void)setupSubViews;
@end
