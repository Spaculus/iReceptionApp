//
//  ContactForm.m
//  iReception
//
//  Created by spaculus on 7/26/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "ContactForm.h"
#import "ContactFormCell.h"
#import "HeaderCell.h"
#import "ButtonCell.h"

static NSString * const kMessagePlaceholder   = @" ";


@interface ContactForm () <UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate>

{
    NSString *name;
    NSString *mobileNo;
    NSString *email;
    NSString *message;
    
    BOOL showingMessagePlaceholder;
    
    NSTimer *resetTimer;
    
    NSInteger textFieldTag;
}

@property UIView *backgroundMaskView;
@property UIView *containerView;
@property TPKeyboardAvoidingTableView *tableView;
@property UILabel *lblTitle;
@property UILabel *lblLine;
@property UIButton *btnClose;

@property NSString *headerTitle;
@property BOOL tapBackgroundToDismiss;
//tap item to select and confirm
@property BOOL tapPickerViewItemToConfirm;
@end

typedef void (^StandardFormDismissCallback)(void);

@implementation ContactForm {
    StandardFormDismissCallback callback;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (id)initWithHeaderTitle:(NSString *)headerTitle {
    self = [super init];
    if(self){
        self.tapBackgroundToDismiss = YES;
        self.headerTitle = headerTitle ? headerTitle : @"";
    }
    return self;
}

- (void)setupSubViews {
    textFieldTag = 0;
    CGRect rect= [UIScreen mainScreen].bounds;
    self.frame = rect;
    
    //mask is full screen
    self.backgroundMaskView = [self buildBackgroundMaskView];
    [self addSubview:self.backgroundMaskView];
    
    self.containerView = [self buildContainerView];
    [self addSubview:self.containerView];
    
    self.lblTitle = [self buildTitleLabel];
    [self.containerView addSubview:self.lblTitle];

    self.lblLine = [self buildLineLabel];
    [self.containerView addSubview:self.lblLine];
    
    self.btnClose = [self buildButtonClose];
    [self.containerView addSubview:self.btnClose];
    
    self.tableView = [self buildTableView];
    [self.containerView addSubview:self.tableView];
    
    [self show];
    
    [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.containerView.frame = CGRectMake(262, 16, 500, 384);
                     }
                     completion:^(BOOL finished) {
                     }
     
     ];
    
    
    
    
    NSInteger resetForAlert = [[[NSUserDefaults standardUserDefaults] valueForKey:@"resetForAlert_INIT"] integerValue]/1000.0;

    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    resetTimer = [NSTimer scheduledTimerWithTimeInterval:resetForAlert target:self selector:@selector(resetToHomeForAlert) userInfo:nil repeats:YES];
    
    
}


-(void)resetToHomeForAlert
{
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    [self dismiss:^{
        if([self.delegate respondsToSelector:@selector(contactDismissForm:)]){
            [self.delegate contactDismissForm:self];
        }
    }];
}

- (void)show {
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    self.frame = mainWindow.frame;
    [mainWindow addSubview:self];
    
    self.containerView.layer.opacity = 1.0f;
    self.layer.opacity = 0.5f;
    self.layer.transform = CATransform3DMakeScale(1.5f, 1.5f, 1.0f);
    
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                         self.layer.opacity = 1.0f;
                         self.backgroundMaskView.layer.opacity = 0.5f;
                         self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                     }
                     completion:^(BOOL finished) {
                     }
     
     ];
}


- (UIView *)buildBackgroundMaskView{
    
    UIView *bgv;
    bgv = [[UIView alloc] initWithFrame:self.frame];
    bgv.alpha = 0.0;
    bgv.backgroundColor = [UIColor blackColor];
    bgv.userInteractionEnabled = YES;
    if(self.tapBackgroundToDismiss){
        [bgv addGestureRecognizer:
         [[UITapGestureRecognizer alloc] initWithTarget:self
                                                 action:@selector(dismissForm:)]];
    }
    return bgv;
}

- (UIView *)buildContainerView {
    CGRect containerFrame = CGRectMake(262, -384, 500, 384);
    CGRect newRect = containerFrame;
    UIView *bcv = [[UIView alloc] initWithFrame:newRect];
    bcv.layer.cornerRadius = 5.0f;
    bcv.clipsToBounds = YES;
    bcv.backgroundColor = [UIColor whiteColor];
    return bcv;
}


- (TPKeyboardAvoidingTableView *)buildTableView {
    CGRect newRect = CGRectMake(0, 87, 500, 297);
    TPKeyboardAvoidingTableView *tableView = [[TPKeyboardAvoidingTableView alloc] initWithFrame:newRect style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    return tableView;
}

- (UILabel *)buildTitleLabel {
    CGRect newRect = CGRectMake(8, 0, 444, 72);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.textColor = [UIColor blackColor];
    lbl.text = self.headerTitle; //@"Reception er midlertidig ude af drift.";
    lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    lbl.textAlignment = NSTextAlignmentLeft;
    lbl.numberOfLines = 3;
    lbl.lineBreakMode = NSLineBreakByTruncatingTail;
    return lbl;
    
}
- (UILabel *)buildLineLabel {
    CGRect newRect = CGRectMake(0, 82, 500, 1);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0];
    return lbl;
    
}

- (UIButton *)buildButtonClose {
    CGRect newRect = CGRectMake(460, 0, 40, 40);
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = newRect;
    [btn setTitle:@"X" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont fontWithName:@"Verdana-Bold" size:18];
    [btn addTarget:self action:@selector(onButtonCloseClicked:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
    
    /*UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.textColor = [UIColor blackColor];
    lbl.text = @"Reception er midlertidig ude af drift.";
    lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:30];
    lbl.textAlignment = NSTextAlignmentLeft;
    return lbl;*/
    
}

#pragma mark - cancel/confirm button delegate

- (void)dismissForm:(id)sender {
    [self dismiss:^{
        if([self.delegate respondsToSelector:@selector(contactDismissFormOnTouchOutSide:)]){
         [self.delegate contactDismissFormOnTouchOutSide:self];
         }
    }];
}

- (IBAction)cancelButtonPressed:(UIButton *)sender {
    [self dismiss:^{
        /*if([self.delegate respondsToSelector:@selector(pickerviewDidClickCancelButton:)]){
         [self.delegate pickerviewDidClickCancelButton:self];
         }*/
    }];
}


- (void)dismiss:(StandardFormDismissCallback)completion {
    
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    callback = completion;
    
    if(callback){
        callback();
    }
    float delayTime;
    if (self.tapPickerViewItemToConfirm) {
        delayTime = 0.5;
    }else {
        delayTime = 0;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        /*[UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                             self.layer.opacity = 0.1f;
                             self.layer.transform = CATransform3DMakeScale(3.0f, 3.0f, 1.0f);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         ];*/
        [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                         animations:^{
                             self.containerView.frame = CGRectMake(262, -384, 500, 384);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         
         ];
    });
    
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
     return 2;
   // return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            return 225;
        }
            break;
            
        case 1:
        {
            return 72;
        }
            break;
            
        default:
            return 0;
            break;
    }
    /*switch (indexPath.row) {
        case 0:
        {
            return 95;
        }
            break;
            
        case 1:
        {
            return 274;
        }
            break;
            
        case 2:
        {
            return 72;
        }
            break;
            
        default:
            return 0;
            break;
    }*/
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    switch (indexPath.row) {
        case 0:
        {
            static NSString *menuIdentifier = @"ContactFormCell";
            ContactFormCell *cell = (ContactFormCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ContactFormCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            cell.txtName.delegate = self;
            cell.txtMobileNo.delegate = self;
            cell.txtEmail.delegate = self;
            cell.txtMessage.delegate = self;
            
            if (textFieldTag == 10) {
                [cell.txtName becomeFirstResponder];
                
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtName
                                             forCornerRadius:5.0
                                              forBorderWidth:1.8f
                                                 withPadding:8
                                                    andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtMobileNo
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
            }
            else if (textFieldTag == 11) {
                [cell.txtMobileNo becomeFirstResponder];
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtName
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtMobileNo
                                             forCornerRadius:5.0
                                              forBorderWidth:1.8f
                                                 withPadding:8
                                                    andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
            }
            else if (textFieldTag == 12) {
                [cell.txtEmail becomeFirstResponder];
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtName
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtMobileNo
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                             forCornerRadius:5.0
                                              forBorderWidth:1.8f
                                                 withPadding:8
                                                    andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
            }
            else {
                [cell.txtName becomeFirstResponder];
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtName
                                             forCornerRadius:5.0
                                              forBorderWidth:1.8f
                                                 withPadding:8
                                                    andColor:[[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtMobileNo
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
                
                [CommonUtils setBorderAndCorner_ForTextField:cell.txtEmail
                                             forCornerRadius:5.0
                                              forBorderWidth:1.0f
                                                 withPadding:8
                                                    andColor:[[UIColor lightGrayColor] CGColor]];
            }
            
            [cell.txtName becomeFirstResponder];
            
            cell.txtName.tag = 10;
            cell.txtMobileNo.tag = 11;
            cell.txtEmail.tag = 12;
            
            cell.txtName.text = name;
            cell.txtMobileNo.text = mobileNo;
            cell.txtEmail.text = email;
            message = @"";
            [self configureSubspecialityTextView:cell];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        case 1:
        {
            static NSString *menuIdentifier = @"ButtonCell";
            ButtonCell *cell = (ButtonCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ButtonCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            if ([CommonUtils isEnglishLanguage]) {
                [cell.btnRollback setTitle:@"Rollback" forState:UIControlStateNormal];
                [cell.btnSend setTitle:@"Send" forState:UIControlStateNormal];
            }
            else {
                [cell.btnRollback setTitle:@"Fortryd" forState:UIControlStateNormal];
                [cell.btnSend setTitle:@"Send" forState:UIControlStateNormal];
            }
            
            [cell.btnSend addTarget:self action:@selector(onButtonSendClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnRollback addTarget:self action:@selector(onButtonRollbackClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        default:
            return [CommonUtils createDefaultCell:tableView];
            break;
    }
    
    /*switch (indexPath.row) {
        case 0:
        {
            static NSString *menuIdentifier = @"HeaderCell";
            HeaderCell *cell = (HeaderCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HeaderCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            cell.lblHeader.text = self.headerTitle;
            
            [cell.btnClose addTarget:self action:@selector(onButtonCloseClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        case 1:
        {
            static NSString *menuIdentifier = @"ContactFormCell";
            ContactFormCell *cell = (ContactFormCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ContactFormCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            cell.txtName.delegate = self;
            cell.txtMobileNo.delegate = self;
            cell.txtEmail.delegate = self;
            cell.txtMessage.delegate = self;
            
            [cell.txtName becomeFirstResponder];
            
            cell.txtName.tag = 10;
            cell.txtMobileNo.tag = 11;
            cell.txtEmail.tag = 12;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        case 2:
        {
            static NSString *menuIdentifier = @"ButtonCell";
            ButtonCell *cell = (ButtonCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ButtonCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            if ([CommonUtils isEnglishLanguage]) {
                [cell.btnRollback setTitle:@"Rollback" forState:UIControlStateNormal];
                [cell.btnSend setTitle:@"Send" forState:UIControlStateNormal];
            }
            else {
                [cell.btnRollback setTitle:@"Fortryd" forState:UIControlStateNormal];
                [cell.btnSend setTitle:@"Send" forState:UIControlStateNormal];
            }
            
            [cell.btnSend addTarget:self action:@selector(onButtonSendClicked:) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnRollback addTarget:self action:@selector(onButtonRollbackClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        default:
            return [CommonUtils createDefaultCell:tableView];
            break;
    }*/
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}

#pragma mark - TextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    ContactFormCell *cell = (ContactFormCell *)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    switch (textField.tag) {
        case 10:
            cell.txtName.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            cell.txtName.layer.borderWidth = 1.8f;
            cell.txtMobileNo.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMobileNo.layer.borderWidth = 1.0;
            cell.txtEmail.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtEmail.layer.borderWidth = 1.0;
            cell.txtMessage.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMessage.layer.borderWidth = 1.0;
            break;
            
        case 11:
            cell.txtName.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtName.layer.borderWidth = 1.0f;
            cell.txtMobileNo.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            cell.txtMobileNo.layer.borderWidth = 1.8;
            cell.txtEmail.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtEmail.layer.borderWidth = 1.0;
            cell.txtMessage.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMessage.layer.borderWidth = 1.0;
            break;
            
        case 12:
            cell.txtName.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtName.layer.borderWidth = 1.0f;
            cell.txtMobileNo.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMobileNo.layer.borderWidth = 1.0;
            cell.txtEmail.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            cell.txtEmail.layer.borderWidth = 1.8;
            cell.txtMessage.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMessage.layer.borderWidth = 1.0;
            break;
            
        default:
            cell.txtName.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtName.layer.borderWidth = 1.0f;
            cell.txtMobileNo.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMobileNo.layer.borderWidth = 1.0;
            cell.txtEmail.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtEmail.layer.borderWidth = 1.0;
            cell.txtMessage.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.txtMessage.layer.borderWidth = 1.0;
            break;
    }
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    switch (textField.tag) {
        case 10:
            name = textField.text;
            break;
            
        case 11:
            mobileNo = textField.text;
            break;
        
        case 12:
            email = textField.text;
            break;
            
        default:
            name = @"";
            mobileNo = @"";
            email = @"";
            break;
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 11) {
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        mobileNo = newString;
        if (mobileNo.length>8) {
            return NO;
        }
        else {
            return YES;
        }
    }
    else {
        return  YES;
    }
}

#pragma mark - TEXT VIEW

-(void)configureSubspecialityTextView:(ContactFormCell *)cell
{
    showingMessagePlaceholder = YES;
    if ([message length]==0)
    {
        [cell.txtMessage setText:kMessagePlaceholder];
        [cell.txtMessage setTextColor:[UIColor lightGrayColor]];
    }
    else
    {
        [cell.txtMessage setText:message];
        [cell.txtMessage setTextColor:[UIColor blackColor]];
        showingMessagePlaceholder = NO;
    }
}
#pragma mark UITextView Delegate Methods
-(BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    return YES;
}
-(void)textViewDidBeginEditing:(UITextView *)textView {
    // Check if it's showing a placeholder, remove it if so
    
    ContactFormCell *cell = (ContactFormCell *)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    cell.txtName.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtName.layer.borderWidth = 1.0f;
    cell.txtMobileNo.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtMobileNo.layer.borderWidth = 1.0;
    cell.txtEmail.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtEmail.layer.borderWidth = 1.0;
    cell.txtMessage.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
    cell.txtMessage.layer.borderWidth = 1.8;
    
    if(showingMessagePlaceholder) {
        [textView setText:@""];
        [textView setTextColor:[UIColor blackColor]];
        showingMessagePlaceholder = NO;
    }
}
-(void)textViewDidEndEditing:(UITextView *)textView {
    ContactFormCell *cell = (ContactFormCell *)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    cell.txtName.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtName.layer.borderWidth = 1.0f;
    cell.txtMobileNo.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtMobileNo.layer.borderWidth = 1.0;
    cell.txtEmail.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtEmail.layer.borderWidth = 1.0;
    cell.txtMessage.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.txtMessage.layer.borderWidth = 1.0;
    
    if([[textView text] length] == 0 && !showingMessagePlaceholder) {
        [textView setText:kMessagePlaceholder];
        [textView setTextColor:[UIColor lightGrayColor]];
        
        showingMessagePlaceholder = YES;
    }
    else
    {
        NSLog(@"%@",textView.text);
        message = textView.text;
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    return YES ;
}



#pragma mark - Cell Button Actions
- (void)onButtonSendClicked:(UIButton *)btnSend {
    [self endEditing:YES];
    if ([name length]==0) {
        textFieldTag = 10;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv dit navn" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
        
    }
    else if ([mobileNo length]==0) {
        textFieldTag = 11;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Venligst angiv dit mobil nummer" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
        
    }
    else if ([email length] == 0)
    {
        textFieldTag = 12;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Indtast din e- mailadresse" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
    }
    else if (![CommonUtils IsValidEmail:email]) {
        textFieldTag = 12;
        [CommonUtils alertViewDelegateWithTitle:AlertTitle withMessage:@"Indtast venligst gyldig e-mailadresse" andTarget:self forCancelString:nil forOtherButtonString:@"OK" withTag:1000];
    }
    else {
        [self cancelButtonPressed:btnSend];
        if ([[self delegate] respondsToSelector:@selector(contactForm:sendNotification:)]) {
            [[self delegate] contactForm:self sendNotification:@{@"name":name,@"mobile":mobileNo,@"email":email,@"message":message}];
        }
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    [self.tableView reloadData];
}

- (void)onButtonRollbackClicked:(UIButton *)btnRollback {
    [self cancelButtonPressed:btnRollback];
}

- (void)onButtonCloseClicked:(UIButton *)btnClose {
    [self cancelButtonPressed:btnClose];
}



@end
