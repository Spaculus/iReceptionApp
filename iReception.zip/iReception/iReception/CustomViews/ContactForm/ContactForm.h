//
//  ContactForm.h
//  iReception
//
//  Created by spaculus on 7/26/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ContactForm;

@protocol ContactFormDelegate <NSObject>

- (void)contactForm:(ContactForm *)contact sendNotification:(NSDictionary *)dict;
- (void)contactDismissForm:(ContactForm *)contact;
- (void)contactDismissFormOnTouchOutSide:(ContactForm *)contact;

@end


@interface ContactForm : UIView

@property (nonatomic, strong) id<ContactFormDelegate> delegate;

- (id)initWithHeaderTitle:(NSString *)headerTitle;
- (void)setupSubViews;
@end
