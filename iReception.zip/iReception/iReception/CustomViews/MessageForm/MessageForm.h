//
//  MessageForm.h
//  iReception
//
//  Created by spaculus on 7/27/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MessageForm;

@protocol MessageFormDelegate <NSObject>

- (void)messageDismissForm:(MessageForm *)message;
- (void)messageDismissFormOnTouchOutSide:(MessageForm *)contact;
@end

@interface MessageForm : UIView

@property (nonatomic, strong) id<MessageFormDelegate> delegate;

- (id)initWithHeaderTitle:(NSString *)headerTitle withMessage:(NSString *)message;
- (void)setupSubViews;
@end
