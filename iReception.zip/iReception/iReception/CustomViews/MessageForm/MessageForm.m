//
//  MessageForm.m
//  iReception
//
//  Created by spaculus on 7/27/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "MessageForm.h"

#import "MessageFormCell.h"
#import "HeaderCell.h"
#import "ButtonCell.h"


static NSString * const MessageFormCellIdentifier = @"MessageFormCell";
@interface MessageForm () <UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate>

{
    NSString *name;
    NSString *mobileNo;
    NSTimer *resetTimer;
}

@property UIView *backgroundMaskView;
@property UIView *containerView;
@property UITableView *tableView;

@property UIView *headerContainerView;
@property UILabel *lblTitle;
@property UILabel *lblLine;
@property UILabel *lblButtonViewLine;
@property UIButton *btnClose;

@property UIView *btnContainerView;
@property UIButton *btnOK;


@property NSString *headerTitle;
@property NSString *message;

@property BOOL tapBackgroundToDismiss;
//tap item to select and confirm
@property BOOL tapPickerViewItemToConfirm;
@end

typedef void (^StandardFormDismissCallback)(void);

@implementation MessageForm {
    StandardFormDismissCallback callback;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (id)initWithHeaderTitle:(NSString *)headerTitle withMessage:(NSString *)message{
    self = [super init];
    if(self){
        self.tapBackgroundToDismiss = YES;
        self.headerTitle = headerTitle ? headerTitle : @"";
        self.message = message ? message : @"";
    }
    return self;
}

- (void)setupSubViews {
    CGRect rect= [UIScreen mainScreen].bounds;
    self.frame = rect;
    
    //mask is full screen
    self.backgroundMaskView = [self buildBackgroundMaskView];
    [self addSubview:self.backgroundMaskView];
    
    self.containerView = [self buildContainerView];
    [self addSubview:self.containerView];
    
    self.tableView = [self buildTableView];
    [self.containerView addSubview:self.tableView];
    
    self.headerContainerView = [self buildHeaderContainerView];
    [self.containerView addSubview:self.headerContainerView];
    
    self.lblTitle = [self buildTitleLabel];
    [self.headerContainerView addSubview:self.lblTitle];
    
    self.lblLine = [self buildLineLabel];
    [self.headerContainerView addSubview:self.lblLine];
    
    self.btnClose = [self buildButtonClose];
    [self.headerContainerView addSubview:self.btnClose];
    
//    self.btnOK = [self buildButtonOK];
//    [self.btnContainerView addSubview:self.btnOK];
//    
//    self.lblButtonViewLine = [self buildButtonLineLabel];
//    [self.btnContainerView addSubview:self.lblButtonViewLine];
    
    [self show];
    
    [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.containerView.frame = CGRectMake(262, 64, 500, 640);//CGRectMake(262, 264, 500, 240);
                     }
                     completion:^(BOOL finished) {
                     }
     
     ];
    
    NSInteger resetForAlert = [[[NSUserDefaults standardUserDefaults] valueForKey:@"resetForAlert_INIT"] integerValue]/1000.0;
    
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    resetTimer = [NSTimer scheduledTimerWithTimeInterval:resetForAlert target:self selector:@selector(resetToHomeForAlert) userInfo:nil repeats:YES];
}


-(void)resetToHomeForAlert
{
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    [self dismiss:^{
        if([self.delegate respondsToSelector:@selector(messageDismissForm:)]){
            [self.delegate messageDismissForm:self];
        }
    }];
}


- (void)show {
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    self.frame = mainWindow.frame;
    [mainWindow addSubview:self];
    
    self.containerView.layer.opacity = 1.0f;
    self.layer.opacity = 0.5f;
    self.layer.transform = CATransform3DMakeScale(1.5f, 1.5f, 1.0f);
    
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                         self.layer.opacity = 1.0f;
                         self.backgroundMaskView.layer.opacity = 0.5f;
                         self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                     }
                     completion:^(BOOL finished) {
                         [self registerCell];
                         self.tableView.delegate = self;
                         self.tableView.dataSource = self;
                         [self.tableView reloadData];
                     }
     
     ];
}


- (UIView *)buildBackgroundMaskView{
    
    UIView *bgv;
    bgv = [[UIView alloc] initWithFrame:self.frame];
    bgv.alpha = 0.0;
    bgv.backgroundColor = [UIColor blackColor];
    bgv.userInteractionEnabled = YES;
    if(self.tapBackgroundToDismiss){
        [bgv addGestureRecognizer:
         [[UITapGestureRecognizer alloc] initWithTarget:self
                                                 action:@selector(dismissForm:)]];
    }
    return bgv;
}

- (UIView *)buildContainerView {
    CGRect containerFrame = CGRectMake(262, -640, 500, 640);//CGRectMake(262, -264, 500, 240);
    CGRect newRect = containerFrame;
    UIView *bcv = [[UIView alloc] initWithFrame:newRect];
    bcv.layer.cornerRadius = 5.0f;
    bcv.clipsToBounds = YES;
    bcv.backgroundColor = [UIColor clearColor];
    return bcv;
}

- (UITableView *)buildTableView {
    CGRect newRect = CGRectMake(0, 87, 500, 553);//153 CGRectMake(0, 87, 500, 81);
    UITableView *tableView = [[UITableView alloc] initWithFrame:newRect style:UITableViewStylePlain];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.bounces = NO;
    return tableView;
}

- (UIView *)buildHeaderContainerView {
    CGRect containerFrame = CGRectMake(0, 0, 500, 87);
    CGRect newRect = containerFrame;
    UIView *bcv = [[UIView alloc] initWithFrame:newRect];
//    bcv.layer.cornerRadius = 5.0f;
//    bcv.clipsToBounds = YES;
    bcv.backgroundColor = [UIColor whiteColor];
    return bcv;
}

- (UILabel *)buildTitleLabel {
    CGRect newRect = CGRectMake(8, 0, 444, 72);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.textColor = [UIColor blackColor];
    lbl.text = self.headerTitle; //@"Reception er midlertidig ude af drift.";
    lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
    lbl.textAlignment = NSTextAlignmentLeft;
    lbl.numberOfLines = 3;
    lbl.lineBreakMode = NSLineBreakByTruncatingTail;
    return lbl;
    
}
- (UILabel *)buildLineLabel {
    CGRect newRect = CGRectMake(0, 82, 500, 1);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0];
    return lbl;
    
}

- (UILabel *)buildButtonLineLabel {
    CGRect newRect = CGRectMake(0, 0, 500, 1);
    UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
    lbl.backgroundColor = [UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0];
    return lbl;
    
}

- (UIButton *)buildButtonClose {
    CGRect newRect = CGRectMake(460, 0, 40, 40);
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = newRect;
    [btn setTitle:@"X" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithRed:116.0/255.0 green:116.0/255.0 blue:116.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont fontWithName:@"Verdana-Bold" size:18];
    [btn addTarget:self action:@selector(onButtonCloseClicked:) forControlEvents:UIControlEventTouchUpInside];
    return btn;
    
    /*UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
     lbl.backgroundColor = [UIColor clearColor];
     lbl.textColor = [UIColor blackColor];
     lbl.text = @"Reception er midlertidig ude af drift.";
     lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:30];
     lbl.textAlignment = NSTextAlignmentLeft;
     return lbl;*/
    
}

- (UIView *)buildButtonContainerView {
    CGRect containerFrame = CGRectMake(0, 168, 500, 72);
    CGRect newRect = containerFrame;
    UIView *bcv = [[UIView alloc] initWithFrame:newRect];
    bcv.backgroundColor = [UIColor colorWithRed:245.0/255.0 green:245.0/255.0 blue:245.0/255.0 alpha:1.0];
    bcv.layer.cornerRadius = 0.0;
    bcv.clipsToBounds = YES;
    return bcv;
}
- (UIButton *)buildButtonOK{
    CGRect newRect = CGRectMake(295, 16, 197, 40);
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = newRect;
    [btn setTitle:@"OK" forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"button-gradient"] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:20];
    [btn addTarget:self action:@selector(onButtonSendClicked:) forControlEvents:UIControlEventTouchUpInside];
    btn.layer.cornerRadius = 5.0f;
    btn.layer.masksToBounds = YES;
    return btn;
    
    /*UILabel *lbl = [[UILabel alloc] initWithFrame:newRect];
     lbl.backgroundColor = [UIColor clearColor];
     lbl.textColor = [UIColor blackColor];
     lbl.text = @"Reception er midlertidig ude af drift.";
     lbl.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:30];
     lbl.textAlignment = NSTextAlignmentLeft;
     return lbl;*/
    
}


#pragma mark - cancel/confirm button delegate
- (void)dismissForm:(id)sender {
    [self dismiss:^{
        if([self.delegate respondsToSelector:@selector(messageDismissFormOnTouchOutSide:)]){
            [self.delegate messageDismissFormOnTouchOutSide:self];
        }
    }];
}
- (IBAction)cancelButtonPressed:(UIButton *)sender {
    [self dismiss:^{
        /*if([self.delegate respondsToSelector:@selector(pickerviewDidClickCancelButton:)]){
         [self.delegate pickerviewDidClickCancelButton:self];
         }*/
    }];
}


- (void)dismiss:(StandardFormDismissCallback)completion {
    
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    callback = completion;
    
    if(callback){
        callback();
    }
    float delayTime;
    if (self.tapPickerViewItemToConfirm) {
        delayTime = 0.5;
    }else {
        delayTime = 0;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        /*[UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                             self.layer.opacity = 0.1f;
                             self.layer.transform = CATransform3DMakeScale(3.0f, 3.0f, 1.0f);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         ];*/
        [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                         animations:^{
                             self.containerView.frame = CGRectMake(262, -640, 500, 640);//CGRectMake(262, -264, 500, 240);//(262, -286, 500, 211);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         
         ];
    });
    
}

#pragma mark - UITableViewDataSource

- (void)registerCell {
    [self.tableView registerNib:[UINib nibWithNibName:@"MessageFormCell" bundle:nil] forCellReuseIdentifier:MessageFormCellIdentifier];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 72;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    self.btnContainerView = [self buildButtonContainerView];
    
    self.btnOK = [self buildButtonOK];
    [self.btnContainerView addSubview:self.btnOK];
    
    self.lblButtonViewLine = [self buildButtonLineLabel];
    [self.btnContainerView addSubview:self.lblButtonViewLine];
    
    return self.btnContainerView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;//3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            CGFloat cellHeight = [self heightForMessageFormCellAtIndexPath:indexPath];
            return cellHeight;
        }
            break;
        default:
            return 0;
            break;
    }
    /*switch (indexPath.row) {
        case 0:
        {
            return 95;
        }
            break;
            
        case 1:
        {
            CGFloat cellHeight = [self heightForMessageFormCellAtIndexPath:indexPath];
            return cellHeight;
        }
            break;
            
        case 2:
        {
            return 72;
        }
            break;
            
        default:
            return 0;
            break;
    }*/
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            return 44;
        }
            break;
        default:
            return 0;
            break;
    }
    /*switch (indexPath.row) {
        case 0:
        {
            return 95;
        }
            break;
            
        case 1:
        {
            return 44;
        }
            break;
            
        case 2:
        {
            return 72;
        }
            break;
            
        default:
            return 0;
            break;
    }*/

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            return [self MessageFormCellAtIndexPath:indexPath];
        }
            break;
        default:
            return [CommonUtils createDefaultCell:tableView];
            break;
    }
    /*switch (indexPath.row) {
        case 0:
        {
            static NSString *menuIdentifier = @"HeaderCell";
            HeaderCell *cell = (HeaderCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HeaderCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            cell.lblHeader.text = self.headerTitle;
            
            [cell.btnClose addTarget:self action:@selector(onButtonCloseClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        case 1:
        {
            return [self MessageFormCellAtIndexPath:indexPath];
        }
            break;
            
        case 2:
        {
            static NSString *menuIdentifier = @"ButtonCell";
            ButtonCell *cell = (ButtonCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ButtonCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            [cell.btnSend setTitle:@"OK" forState:UIControlStateNormal];
            [cell.btnSend addTarget:self action:@selector(onButtonSendClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnRollback.hidden = YES;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        default:
            return [CommonUtils createDefaultCell:tableView];
            break;
    }*/
}


#pragma mark MessageFormCell Cell Configuration
- (MessageFormCell *)MessageFormCellAtIndexPath:(NSIndexPath *)indexPath
{
    static MessageFormCell *cell = nil;
    cell = [self.tableView dequeueReusableCellWithIdentifier:MessageFormCellIdentifier];
    [self configureMessageFormCell:cell atIndexPath:indexPath];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
- (void)configureMessageFormCell:(MessageFormCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    cell.lblMessasge.text = self.message;
}

- (CGFloat)heightForMessageFormCellAtIndexPath:(NSIndexPath *)indexPath
{
    static MessageFormCell *sizingCell = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sizingCell = [self.tableView dequeueReusableCellWithIdentifier:MessageFormCellIdentifier];
    });
    
    [self configureMessageFormCell:sizingCell atIndexPath:indexPath];
    return [self calculateHeightForConfiguredSizingCell:sizingCell];
}
#pragma mark Calculate Height for Cell

- (CGFloat)calculateHeightForConfiguredSizingCell:(UITableViewCell *)sizingCell
{
    sizingCell.bounds = CGRectMake(0.0f, 0.0f, CGRectGetWidth(self.tableView.frame), CGRectGetHeight(sizingCell.bounds));
    [sizingCell setNeedsLayout];
    [sizingCell layoutIfNeeded];
    
    CGSize size = [sizingCell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
    return size.height + 1.0f; // Add 1.0f for the cell separator height
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}

#pragma mark - TextField Delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    switch (textField.tag) {
        case 10:
            name = textField.text;
            break;
            
        case 11:
            mobileNo = textField.text;
            break;
            
        default:
            break;
    }
}

#pragma mark - Cell Button Actions
- (void)onButtonSendClicked:(UIButton *)btnSend {
    [self cancelButtonPressed:btnSend];
}
- (void)onButtonRollbackClicked:(UIButton *)btnRollback {
    [self cancelButtonPressed:btnRollback];
}

- (void)onButtonCloseClicked:(UIButton *)btnClose {
    [self cancelButtonPressed:btnClose];
}


@end
