//
//  ThankYouFormForSignUpForm.h
//  iReception
//
//  Created by spaculus on 8/19/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ThankYouFormForSignUpForm;

@protocol ThankYouFormForSignUpFormDelegate <NSObject>

- (void)messageDismissThankYouFormForSignUpForm:(ThankYouFormForSignUpForm *)thankYouFormForSignUpForm;

@end

@interface ThankYouFormForSignUpForm : UIView

@property (nonatomic, strong) id<ThankYouFormForSignUpFormDelegate> delegate;

- (id)initWithHeaderTitle:(NSString *)headerTitle withMessage:(NSString *)message withSubMessage:(NSString *)subMessage;
- (void)setupSubViews;

@end