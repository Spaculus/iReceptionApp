//
//  ThankYouContactForm.h
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ThankYouContactForm;

@protocol ThankYouContactFormDelegate <NSObject>

- (void)messageDismissThankYouContactForm:(ThankYouContactForm *)thankYouContactForm;
- (void)messageDismissThankYouContactFormOnTouchOutSide:(ThankYouContactForm *)contact;
@end

@interface ThankYouContactForm : UIView

@property (nonatomic, strong) id<ThankYouContactFormDelegate> delegate;

- (id)initWithHeaderTitle:(NSString *)headerTitle withMessage:(NSString *)message withSubMessage:(NSString *)subMessage;
- (void)setupSubViews;

@end