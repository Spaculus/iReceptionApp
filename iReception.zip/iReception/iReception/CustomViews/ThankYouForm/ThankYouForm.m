//
//  ThankYouForm.m
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "ThankYouForm.h"
#import "ThankYouFormForStandaredCell.h"
#import "HeaderCell.h"
#import "ButtonCell.h"

@interface ThankYouForm () <UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate>

{
    NSTimer *resetTimer;
}

@property UIView *backgroundMaskView;
@property UIView *containerView;
@property TPKeyboardAvoidingTableView *tableView;

@property NSString *headerTitle;
@property NSString *message;

@property BOOL tapBackgroundToDismiss;
//tap item to select and confirm
@property BOOL tapPickerViewItemToConfirm;
@end

typedef void (^StandardFormDismissCallback)(void);

@implementation ThankYouForm {
    StandardFormDismissCallback callback;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (id)initWithHeaderTitle:(NSString *)headerTitle withMessage:(NSString *)message{
    self = [super init];
    if(self){
        self.tapBackgroundToDismiss = YES;
        self.headerTitle = headerTitle ? headerTitle : @"";
        self.message = message ? message : @"";
    }
    return self;
}

- (void)setupSubViews {
    CGRect rect= [UIScreen mainScreen].bounds;
    self.frame = rect;
    
    //mask is full screen
    self.backgroundMaskView = [self buildBackgroundMaskView];
    [self addSubview:self.backgroundMaskView];
    
    self.containerView = [self buildContainerView];
    [self addSubview:self.containerView];
    
    self.tableView = [self buildTableView];
    [self.containerView addSubview:self.tableView];
    
    [self show];
    
    [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.containerView.frame = CGRectMake(262, 134, 500, 328);
                     }
                     completion:^(BOOL finished) {
                     }
     
     ];
    
    NSInteger resetForAlert = [[[NSUserDefaults standardUserDefaults] valueForKey:@"resetForChild_INIT"] integerValue]/1000.0;
    
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    resetTimer = [NSTimer scheduledTimerWithTimeInterval:resetForAlert target:self selector:@selector(resetToHomeForAlert) userInfo:nil repeats:YES];
}


-(void)resetToHomeForAlert
{
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    [self dismiss:^{
        if([self.delegate respondsToSelector:@selector(messageDismissThankYouForm:)]){
            [self.delegate messageDismissThankYouForm:self];
        }
    }];
}

- (void)show {
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    self.frame = mainWindow.frame;
    [mainWindow addSubview:self];
    
    self.containerView.layer.opacity = 1.0f;
    self.layer.opacity = 0.2f;
    self.layer.transform = CATransform3DMakeScale(1.5f, 1.5f, 1.0f);
    
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                         self.layer.opacity = 1.0f;
                         self.backgroundMaskView.layer.opacity = 0.2f;
                         self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                     }
                     completion:^(BOOL finished) {
                     }
     
     ];
}


- (UIView *)buildBackgroundMaskView{
    
    UIView *bgv;
    bgv = [[UIView alloc] initWithFrame:self.frame];
    bgv.alpha = 0.0;
    bgv.backgroundColor = [UIColor blackColor];
    bgv.userInteractionEnabled = YES;
    if(self.tapBackgroundToDismiss){
        [bgv addGestureRecognizer:
         [[UITapGestureRecognizer alloc] initWithTarget:self
                                                 action:@selector(dismissForm:)]];
    }
    return bgv;
}

- (UIView *)buildContainerView {
    CGRect containerFrame = CGRectMake(262, -328, 500, 328);
    CGRect newRect = containerFrame;
    UIView *bcv = [[UIView alloc] initWithFrame:newRect];
    bcv.layer.cornerRadius = 5.0f;
    bcv.clipsToBounds = YES;
    return bcv;
}


- (TPKeyboardAvoidingTableView *)buildTableView {
    CGRect newRect = CGRectMake(0, 0, 500, 328);
    TPKeyboardAvoidingTableView *tableView = [[TPKeyboardAvoidingTableView alloc] initWithFrame:newRect style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    return tableView;
}





#pragma mark - cancel/confirm button delegate
- (void)dismissForm:(id)sender {
    [self dismiss:^{
        if([self.delegate respondsToSelector:@selector(messageDismissThankYouFormOnTouchOutSide:)]){
            [self.delegate messageDismissThankYouFormOnTouchOutSide:self];
        }
    }];
}

- (IBAction)cancelButtonPressed:(UIButton *)sender {
    [self dismiss:^{
        [self callDismiss];
        //[self performSelector:@selector(callDismiss) withObject:nil afterDelay:0.001];
        /*if([self.delegate respondsToSelector:@selector(pickerviewDidClickCancelButton:)]){
         [self.delegate pickerviewDidClickCancelButton:self];
         }*/
    }];
}

- (void)callDismiss {
    if([self.delegate respondsToSelector:@selector(messageDismissThankYouForm:)]){
        [self.delegate messageDismissThankYouForm:self];
    }
}

- (void)dismiss:(StandardFormDismissCallback)completion {
    
    if([resetTimer isValid])
    {
        [resetTimer invalidate];
        resetTimer = nil;
    }
    
    callback = completion;
    
    if(callback){
        callback();
    }
    float delayTime;
    if (self.tapPickerViewItemToConfirm) {
        delayTime = 0.5;
    }else {
        delayTime = 0;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       /* [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f];
                             self.layer.opacity = 0.1f;
                             self.layer.transform = CATransform3DMakeScale(3.0f, 3.0f, 1.0f);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         ];*/
        [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseIn
                         animations:^{
                             self.containerView.frame = CGRectMake(262, -328, 500, 328);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             self.layer.transform = CATransform3DMakeScale(1, 1, 1);
                             [self removeFromSuperview];
                             [self setNeedsDisplay];
                         }
         
         ];
    });
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:
        {
            return 95;
        }
            break;
            
        case 1:
        {
            return 161;
        }
            break;
            
        case 2:
        {
            return 72;
        }
            break;
            
        default:
            return 0;
            break;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    switch (indexPath.row) {
        case 0:
        {
            static NSString *menuIdentifier = @"HeaderCell";
            HeaderCell *cell = (HeaderCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HeaderCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            cell.lblHeader.text = self.headerTitle;
            
            [cell.btnClose addTarget:self action:@selector(onButtonCloseClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        case 1:
        {
            static NSString *menuIdentifier = @"ThankYouFormForStandaredCell";
            ThankYouFormForStandaredCell *cell = (ThankYouFormForStandaredCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ThankYouFormForStandaredCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            cell.lblMsg.text = [CommonUtils getNotNullString:self.message];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        case 2:
        {
            static NSString *menuIdentifier = @"ButtonCell";
            ButtonCell *cell = (ButtonCell *)[tableView dequeueReusableCellWithIdentifier:menuIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ButtonCell" owner:self options:nil];
                if([CommonUtils isiPad])
                {
                    cell = [nib objectAtIndex:0];
                }
                else
                {
                    cell = [nib objectAtIndex:0];
                }
            }
            
            [cell.btnSend setTitle:@"OK" forState:UIControlStateNormal];
            [cell.btnSend addTarget:self action:@selector(onButtonSendClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            cell.btnRollback.hidden = YES;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
            
        default:
            return [CommonUtils createDefaultCell:tableView];
            break;
    }
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}


#pragma mark - Cell Button Actions
- (void)onButtonSendClicked:(UIButton *)btnSend {
    [self cancelButtonPressed:btnSend];
    /*if ([[self delegate] respondsToSelector:@selector(standardForm:sendNotification:)]) {
          [[self delegate] standardForm:self sendNotification:@{@"name":name,@"mobile":mobileNo,@"email":@"",@"message":@""}];
    }*/
}
- (void)onButtonRollbackClicked:(UIButton *)btnRollback {
    [self cancelButtonPressed:btnRollback];
}

- (void)onButtonCloseClicked:(UIButton *)btnClose {
    [self cancelButtonPressed:btnClose];
}



@end
