//
//  ThankYouForm.h
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ThankYouForm;

@protocol ThankYouFormDelegate <NSObject>

- (void)messageDismissThankYouForm:(ThankYouForm *)thankYouForm;
- (void)messageDismissThankYouFormOnTouchOutSide:(ThankYouForm *)contact;
@end

@interface ThankYouForm : UIView

@property (nonatomic, strong) id<ThankYouFormDelegate> delegate;

- (id)initWithHeaderTitle:(NSString *)headerTitle withMessage:(NSString *)message;
- (void)setupSubViews;

@end
