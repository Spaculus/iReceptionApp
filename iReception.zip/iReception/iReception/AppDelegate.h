//
//  AppDelegate.h
//  iReception
//
//  Created by spaculus on 7/5/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UINavigationController *navController;

@property (strong, nonatomic) NSMutableArray *aryLevels;
@property (nonatomic, assign) NSInteger levelCount;

@property (nonatomic, assign) NSInteger resetForChild;
@property (nonatomic, assign) NSInteger resetForAlert;
@property (nonatomic, assign) NSInteger resetAfterAlert;

@end

