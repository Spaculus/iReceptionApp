//
//  FlowDetailCell.m
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "FlowDetailCell.h"

@implementation FlowDetailCell

- (void)awakeFromNib {
    // Initialization code
    
    self.contentView.backgroundColor = [UIColor clearColor];
    self.backgroundColor = [UIColor clearColor];
    [self setBorders];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

- (void) setBorders {
   //self.btnChoose.layer.cornerRadius = 5.0;
   // self.btnChoose.layer.masksToBounds = YES;
}

@end
