//
//  FlowDetailCell.h
//  iReception
//
//  Created by spaculus on 7/18/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowDetailCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblBG;
@property (strong, nonatomic) IBOutlet UILabel *lblLine;
@property (strong, nonatomic) IBOutlet UILabel *lblFlowName;
@property (strong, nonatomic) IBOutlet UIButton *btnChoose;
@property (strong, nonatomic) IBOutlet UILabel *lblLineBottom;

@end
