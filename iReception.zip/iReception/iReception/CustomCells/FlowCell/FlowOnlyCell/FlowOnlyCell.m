//
//  FlowOnlyCell.m
//  iReception
//
//  Created by spaculus on 7/7/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "FlowOnlyCell.h"

@implementation FlowOnlyCell

- (void)awakeFromNib {
    // Initialization code
    self.contentView.backgroundColor = [UIColor clearColor];
    self.backgroundColor = [UIColor clearColor];
    [self setBorders];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



-(void)setBorders {
    self.lblFlowNumber.layer.cornerRadius = 14.5;
    self.lblFlowNumber.layer.masksToBounds = YES;
    
    self.btnStartReception.layer.cornerRadius = 5.0;
    self.btnStartReception.layer.masksToBounds = YES;
    

}

@end
