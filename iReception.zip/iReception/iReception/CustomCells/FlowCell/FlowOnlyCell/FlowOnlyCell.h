//
//  FlowOnlyCell.h
//  iReception
//
//  Created by spaculus on 7/7/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowOnlyCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblBG;
@property (strong, nonatomic) IBOutlet UILabel *lblLine;
@property (strong, nonatomic) IBOutlet UILabel *lblFlowName;
@property (strong, nonatomic) IBOutlet TTTAttributedLabel *lblDesc;
@property (strong, nonatomic) IBOutlet UILabel *lblFlowNumber;
@property (strong, nonatomic) IBOutlet UILabel *lblLineBottom;

@property (strong, nonatomic) IBOutlet UIView *viewNumberOfFlow;


@property (strong, nonatomic) IBOutlet UIButton *btnStartReception;
@end
