//
//  LoginCell.h
//  iReception
//
//  Created by spaculus on 7/7/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LoginCell;
@protocol LoginCellDelegate<NSObject>
@optional
- (void)didFinishEditingWithLoginCell:(LoginCell *)cell text:(NSString *)aText;

@end

@interface LoginCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblLoginTitle;

@property (strong, nonatomic) IBOutlet UITextField *txtPassword;

@property (strong, nonatomic) IBOutlet UILabel *lbl1;
@property (strong, nonatomic) IBOutlet UILabel *lbl2;
@property (strong, nonatomic) IBOutlet UILabel *lbl3;
@property (strong, nonatomic) IBOutlet UILabel *lbl4;
@property (strong, nonatomic) IBOutlet UILabel *lbl5;

@property (strong, nonatomic) IBOutlet UIImageView *img1;
@property (strong, nonatomic) IBOutlet UIImageView *img2;
@property (strong, nonatomic) IBOutlet UIImageView *img3;
@property (strong, nonatomic) IBOutlet UIImageView *img4;
@property (strong, nonatomic) IBOutlet UIImageView *img5;

@property (strong, nonatomic) IBOutlet UIView *loginViewBG;

@property (strong, nonatomic) IBOutlet UIView *passcodeView;

@property (strong, nonatomic) IBOutlet UIButton *btnSignIn;

@property (strong, nonatomic) id<LoginCellDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIButton *btnSignUp;

@end
