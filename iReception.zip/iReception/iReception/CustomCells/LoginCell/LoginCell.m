//
//  LoginCell.m
//  iReception
//
//  Created by spaculus on 7/7/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "LoginCell.h"
@interface LoginCell () <UITextFieldDelegate>
{
    NSString * password;
    NSArray * aryLabels;
    NSArray * aryImages;
}

@end

@implementation LoginCell
- (void)awakeFromNib {
    // Initialization code
    self.contentView.backgroundColor = [UIColor clearColor];
    self.backgroundColor = [UIColor clearColor];
    
    if ([CommonUtils isEnglishLanguage]) {
        [self.btnSignIn setTitle:@"Sign in" forState:UIControlStateNormal]; //[CommonUtils getNotNullString:NSLocalizedString(@"Sign in", nil)]
        self.lblLoginTitle.text = @"Please enter your password";//[CommonUtils getNotNullString:NSLocalizedString(@"Please enter your password", nil)];
    }
    else {
        [self.btnSignIn setTitle:@"Log ind" forState:UIControlStateNormal]; //[CommonUtils getNotNullString:NSLocalizedString(@"Sign in", nil)]
        self.lblLoginTitle.text = @"Indtast venligst din adgangskode";;//[CommonUtils getNotNullString:NSLocalizedString(@"Please enter your password", nil)];
    }
    
    [self configPasscodeView];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


#pragma mark Passcode View

-(void)configPasscodeView {
    aryLabels = @[self.lbl1,self.lbl2,self.lbl3,self.lbl4,self.lbl5];
    aryImages = @[self.img1,self.img2,self.img3,self.img4,self.img5];
    
    [self.txtPassword addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.txtPassword setTextColor:[UIColor clearColor]];
    [self.txtPassword becomeFirstResponder];
    [self setBorders];
    
    self.img1.backgroundColor = [UIColor whiteColor];
    self.img2.backgroundColor = [UIColor whiteColor];
    self.img3.backgroundColor = [UIColor whiteColor];
    self.img4.backgroundColor = [UIColor whiteColor];
    self.img5.backgroundColor = [UIColor whiteColor];
    
}

-(void)setBorders {
    self.loginViewBG.layer.cornerRadius = 5.0;
    self.loginViewBG.layer.masksToBounds = YES;
    
    self.lbl1.layer.cornerRadius = 5.0;
    self.lbl1.layer.masksToBounds = YES;
    
    self.lbl2.layer.cornerRadius = 5.0;
    self.lbl2.layer.masksToBounds = YES;
    
    self.lbl3.layer.cornerRadius = 5.0;
    self.lbl3.layer.masksToBounds = YES;
    
    self.lbl4.layer.cornerRadius = 5.0;
    self.lbl4.layer.masksToBounds = YES;
    
    self.lbl5.layer.cornerRadius = 5.0;
    self.lbl5.layer.masksToBounds = YES;
    
    self.img1.layer.cornerRadius = 5.0;
    self.img1.layer.masksToBounds = YES;
    
    self.img2.layer.cornerRadius = 5.0;
    self.img2.layer.masksToBounds = YES;
    
    self.img3.layer.cornerRadius = 5.0;
    self.img3.layer.masksToBounds = YES;
    
    self.img4.layer.cornerRadius = 5.0;
    self.img4.layer.masksToBounds = YES;
    
    self.img5.layer.cornerRadius = 5.0;
    self.img5.layer.masksToBounds = YES;
    
    self.loginViewBG.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.loginViewBG.layer.borderWidth = 0.5;
    
    self.lbl1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.lbl1.layer.borderWidth = 0.5;
    
    self.lbl2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.lbl2.layer.borderWidth = 0.5;
    
    self.lbl3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.lbl3.layer.borderWidth = 0.5;
    
    self.lbl4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.lbl4.layer.borderWidth = 0.5;
    
    self.lbl5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.lbl5.layer.borderWidth = 0.5;
    
//    self.img1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
//    self.img1.layer.borderWidth = 0.5;
//    
//    self.img2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
//    self.img2.layer.borderWidth = 0.5;
//    
//    self.img3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
//    self.img3.layer.borderWidth = 0.5;
//
//    self.img4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
//    self.img4.layer.borderWidth = 0.5;
//
//    self.img5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
//    self.img5.layer.borderWidth = 0.5;
    
    self.btnSignIn.layer.cornerRadius = 5.0;
    self.btnSignIn.layer.masksToBounds = YES;
    
    
}

- (void)updateLabels
{
    NSString *numberText = self.txtPassword.text;
    NSLog(@"%@",numberText);
    NSInteger minLength = MIN(numberText.length, 5);
    for(int i=0; i<5; i++){
        UILabel *label = [aryLabels objectAtIndex:i];
        if (i<minLength) {
            label.text = [[numberText substringWithRange:NSMakeRange(i, 1)] uppercaseString];
            //label.text = @"●";
        } else {
            label.text = nil;
        }
    }
    [self highlightImage:minLength-1];
}

#pragma mark - textfield delegate

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (newString.length>5) {
        newString = [newString substringToIndex:[newString length]-1];
        password = newString;
    }
    else {
        password = newString;
    }
    
    return YES;
}


- (void)textFieldDidChange:(UITextField *)textField
{
    if (textField.text.length > 5) {
        textField.text = password;
        if ([[self delegate] respondsToSelector:@selector(didFinishEditingWithLoginCell:text:)]) {
            [[self delegate] didFinishEditingWithLoginCell:self text:textField.text];
        }
        //[textField resignFirstResponder];
        return;
    }
    [self updateLabels];
    if (textField.text.length == 5) {
        NSLog(@"%@",textField.text);
        if ([[self delegate] respondsToSelector:@selector(didFinishEditingWithLoginCell:text:)]) {
            [[self delegate] didFinishEditingWithLoginCell:self text:textField.text];
        }
        return;
    }
    if ([textField.text length] == 0) {
        if ([[self delegate] respondsToSelector:@selector(didFinishEditingWithLoginCell:text:)]) {
            [[self delegate] didFinishEditingWithLoginCell:self text:textField.text];
        }
    }
}

#pragma mark - Config Images 
-(void)highlightImage:(int)imgNum{
    switch (imgNum) {
        case 0:
            self.img1.backgroundColor = [UIColor whiteColor];
            self.img2.backgroundColor = [UIColor whiteColor];
            self.img3.backgroundColor = [UIColor whiteColor];
            self.img4.backgroundColor = [UIColor whiteColor];
            self.img5.backgroundColor = [UIColor whiteColor];
            self.img2.image = [UIImage new];
            self.img3.image = [UIImage new];
            self.img4.image = [UIImage new];
            self.img5.image = [UIImage new];
            
            self.img1.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            self.img1.layer.borderWidth = 1.8;
            self.img2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img2.layer.borderWidth = 1.0;
            self.img3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img3.layer.borderWidth = 1.0;
            self.img4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img4.layer.borderWidth = 1.0;
            self.img5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img5.layer.borderWidth = 1.0;
            
            break;

        case 1:
            self.img1.backgroundColor = [UIColor whiteColor];
            self.img2.backgroundColor = [UIColor whiteColor];
            self.img3.backgroundColor = [UIColor whiteColor];
            self.img4.backgroundColor = [UIColor whiteColor];
            self.img5.backgroundColor = [UIColor whiteColor];
            self.img1.image = [UIImage new];
            self.img3.image = [UIImage new];
            self.img4.image = [UIImage new];
            self.img5.image = [UIImage new];
            self.img1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img1.layer.borderWidth = 1.0;
            self.img2.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            self.img2.layer.borderWidth = 1.8;
            self.img3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img3.layer.borderWidth = 1.0;
            self.img4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img4.layer.borderWidth = 1.0;
            self.img5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img5.layer.borderWidth = 1.0;

            break;

        case 2:
            self.img1.backgroundColor = [UIColor whiteColor];
            self.img2.backgroundColor = [UIColor whiteColor];
            self.img3.backgroundColor = [UIColor whiteColor];;
            self.img4.backgroundColor = [UIColor whiteColor];
            self.img5.backgroundColor = [UIColor whiteColor];
            self.img2.image = [UIImage new];
            self.img1.image = [UIImage new];
            self.img4.image = [UIImage new];
            self.img5.image = [UIImage new];
            self.img1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img1.layer.borderWidth = 1.0;
            self.img2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img2.layer.borderWidth = 1.0;
            self.img3.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            self.img3.layer.borderWidth = 1.8;
            self.img4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img4.layer.borderWidth = 1.0;
            self.img5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img5.layer.borderWidth = 1.0;


            break;

        case 3:
            self.img1.backgroundColor = [UIColor whiteColor];
            self.img2.backgroundColor = [UIColor whiteColor];
            self.img3.backgroundColor = [UIColor whiteColor];
            self.img4.backgroundColor = [UIColor whiteColor];;
            self.img5.backgroundColor = [UIColor whiteColor];
            self.img2.image = [UIImage new];
            self.img3.image = [UIImage new];
            self.img1.image = [UIImage new];
            self.img5.image = [UIImage new];
            self.img1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img1.layer.borderWidth = 1.0;
            self.img2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img2.layer.borderWidth = 1.0;
            self.img3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img3.layer.borderWidth = 1.0;
            self.img4.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            self.img4.layer.borderWidth = 1.8;
            self.img5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img5.layer.borderWidth = 1.0;

            break;

        case 4:
            self.img1.backgroundColor = [UIColor whiteColor];
            self.img2.backgroundColor = [UIColor whiteColor];
            self.img3.backgroundColor = [UIColor whiteColor];
            self.img4.backgroundColor = [UIColor whiteColor];
            self.img5.backgroundColor = [UIColor whiteColor];;
            self.img2.image = [UIImage new];
            self.img3.image = [UIImage new];
            self.img4.image = [UIImage new];
            self.img1.image = [UIImage new];
            self.img1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img1.layer.borderWidth = 1.0;
            self.img2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img2.layer.borderWidth = 1.0;
            self.img3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img3.layer.borderWidth = 1.0;
            self.img4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img4.layer.borderWidth = 1.0;
            self.img5.layer.borderColor = [[UIColor colorWithRed:82.0/255.0 green:168.0/255.0 blue:236.0/255.0 alpha:1.0] CGColor];
            self.img5.layer.borderWidth = 1.8;

            break;

        default:
            self.img1.backgroundColor = [UIColor whiteColor];
            self.img2.backgroundColor = [UIColor whiteColor];
            self.img3.backgroundColor = [UIColor whiteColor];
            self.img4.backgroundColor = [UIColor whiteColor];
            self.img5.backgroundColor = [UIColor whiteColor];
            self.img1.image = [UIImage new];
            self.img2.image = [UIImage new];
            self.img3.image = [UIImage new];
            self.img4.image = [UIImage new];
            self.img5.image = [UIImage new];
            self.img1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img1.layer.borderWidth = 1.0;
            self.img2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img2.layer.borderWidth = 1.0;
            self.img3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img3.layer.borderWidth = 1.0;
            self.img4.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img4.layer.borderWidth = 1.0;
            self.img5.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            self.img5.layer.borderWidth = 1.0;

            break;
    }
}
@end
