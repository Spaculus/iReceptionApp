//
//  StandardFormCell.m
//  iReception
//
//  Created by spaculus on 7/26/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "StandardFormCell.h"

@implementation StandardFormCell

- (void)awakeFromNib {
    // Initialization code
    if ([CommonUtils isEnglishLanguage]) {
        self.lblName.text = @"Name :";
        self.lblMobileNo.text = @"Mobile No :";
    }
    else {
        self.lblName.text = @"Navn :";
        self.lblMobileNo.text = @"Mobilnr :";
    }
    
    [self configureCellTextInputs];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)configureCellTextInputs
{
   
    
    [self.txtName setTextColor:[UIColor blackColor]];
    [self.txtMobileNo setTextColor:[UIColor blackColor]];
}

@end
