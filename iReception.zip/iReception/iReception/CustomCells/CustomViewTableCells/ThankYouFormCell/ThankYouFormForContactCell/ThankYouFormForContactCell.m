//
//  ThankYouFormForContactCell.m
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "ThankYouFormForContactCell.h"

@implementation ThankYouFormForContactCell

- (void)awakeFromNib {
    // Initialization code
    //Send besked send message
    
    //Din formular er afsendt! Your form has been sent !
    
    //Tak for dit besøg Thanks for your visit
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
