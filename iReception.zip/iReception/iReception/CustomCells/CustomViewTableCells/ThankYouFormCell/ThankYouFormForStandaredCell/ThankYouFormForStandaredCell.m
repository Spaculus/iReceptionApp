//
//  ThankYouFormForStandaredCell.m
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "ThankYouFormForStandaredCell.h"

@implementation ThankYouFormForStandaredCell

- (void)awakeFromNib {
    // Initialization code
    
    // Header Message
    // Din ankomst til Spaculus er enmeldt. Your arrival at Spaculus is reported .
    
    // Middle Message
    // Vent venligst her ved iReception. Please wait here by iReception.
    
    // Bottom
    // OK
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
