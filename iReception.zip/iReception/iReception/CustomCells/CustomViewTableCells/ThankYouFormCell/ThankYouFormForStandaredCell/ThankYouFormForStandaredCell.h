//
//  ThankYouFormForStandaredCell.h
//  iReception
//
//  Created by spaculus on 8/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThankYouFormForStandaredCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imgSuceess;
@property (strong, nonatomic) IBOutlet UILabel *lblMsg;

@end
