//
//  ThankYouFormForSignUpCell.m
//  iReception
//
//  Created by spaculus on 8/19/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "ThankYouFormForSignUpCell.h"

@implementation ThankYouFormForSignUpCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
