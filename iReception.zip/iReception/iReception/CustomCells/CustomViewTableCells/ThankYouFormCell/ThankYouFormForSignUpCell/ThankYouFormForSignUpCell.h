//
//  ThankYouFormForSignUpCell.h
//  iReception
//
//  Created by spaculus on 8/19/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThankYouFormForSignUpCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imgSuceess;
@property (strong, nonatomic) IBOutlet UILabel *lblMsg;
@property (strong, nonatomic) IBOutlet UILabel *lblSubMsg;

@end
