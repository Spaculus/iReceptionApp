//
//  MessageFormCell.m
//  iReception
//
//  Created by spaculus on 7/27/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "MessageFormCell.h"

@implementation MessageFormCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
