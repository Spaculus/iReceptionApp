//
//  MessageFormCell.h
//  iReception
//
//  Created by spaculus on 7/27/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageFormCell : UITableViewCell
@property (strong, nonatomic) IBOutlet TTTAttributedLabel *lblMessasge;

@end
