//
//  ContactFormCell.m
//  iReception
//
//  Created by spaculus on 7/26/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "ContactFormCell.h"

@implementation ContactFormCell

- (void)awakeFromNib {
    // Initialization code
    if ([CommonUtils isEnglishLanguage]) {
        self.lblName.text = @"Name :";
        self.lblMobileNo.text = @"Mobile No :";
        self.lblEmail.text = @"Email Address :";
        self.lblMessage.text = @"Message :";
    }
    else {
        self.lblName.text = @"Navn :";
        self.lblMobileNo.text = @"Mobil nr. :";
        self.lblEmail.text = @"Email-adresse :";
        self.lblMessage.text = @"Besked :";
    }
    
    [self configureCellTextInputs];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)configureCellTextInputs
{
    
    UITextInputAssistantItem* itemTxtName = [self.txtName inputAssistantItem];
    itemTxtName.leadingBarButtonGroups = @[];
    itemTxtName.trailingBarButtonGroups = @[];
    
    UITextInputAssistantItem* itemTxtMobileNo = [self.txtMobileNo inputAssistantItem];
    itemTxtMobileNo.leadingBarButtonGroups = @[];
    itemTxtMobileNo.trailingBarButtonGroups = @[];
    
    UITextInputAssistantItem* itemTxtEmail = [self.txtEmail inputAssistantItem];
    itemTxtEmail.leadingBarButtonGroups = @[];
    itemTxtEmail.trailingBarButtonGroups = @[];
    
    UITextInputAssistantItem* itemTxtMessage = [self.txtMessage inputAssistantItem];
    itemTxtMessage.leadingBarButtonGroups = @[];
    itemTxtMessage.trailingBarButtonGroups = @[];
    
    
    
    [self.txtName setTextColor:[UIColor blackColor]];
    [self.txtEmail setTextColor:[UIColor blackColor]];
    [self.txtMobileNo setTextColor:[UIColor blackColor]];

    [self.txtMessage setContentInset:UIEdgeInsetsMake(-2, 0, 0, 0)];
    [self setBorderAndCornerRadius_WhileNoEditing];
}

-(void)setBorderAndCornerRadius_WhileNoEditing {
    self.txtMessage.layer.borderWidth = 0.8;
    self.txtMessage.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.txtMessage.layer.cornerRadius = 5;
    self.txtMessage.layer.masksToBounds = YES;
}


@end
