//
//  GridCell.m
//  iReception
//
//  Created by spaculus on 7/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import "GridCell.h"

@implementation GridCell

- (void)awakeFromNib {
    // Initialization code
    self.backgroundColor = [UIColor clearColor];
    [self setBorder];
}

- (void)setBorder {
    self.btnElement.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.btnElement.layer.borderWidth = 0.8f;
    
    self.btnElement.layer.cornerRadius = 5.0f;
    self.btnElement.layer.masksToBounds = YES;
    
    if (!self.viewGrid.hidden) {
        self.imgBG.layer.borderColor = [UIColor lightGrayColor].CGColor;
        self.imgBG.layer.borderWidth = 0.8f;
        
        self.imgBG.layer.cornerRadius = 5.0f;
        self.imgBG.layer.masksToBounds = YES;
    }
}

@end
