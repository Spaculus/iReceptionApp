//
//  GridCell.h
//  iReception
//
//  Created by spaculus on 7/8/16.
//  Copyright © 2016 spaculus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GridCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imgBG;
@property (strong, nonatomic) IBOutlet UILabel *lblElementName;
@property (strong, nonatomic) IBOutlet UIButton *btnElement;
@property (strong, nonatomic) IBOutlet UIImageView *imgElement;



@property (strong, nonatomic) IBOutlet UIView *viewGrid;
@end
